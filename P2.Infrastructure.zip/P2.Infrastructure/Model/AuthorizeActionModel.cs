﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Model
{
    public class AuthorizeActionModel
    {
        public string Id { set; get; }
        public string UrlAddress { set; get; }
    }
}
