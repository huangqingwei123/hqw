﻿using FastReport;
using FastReport.Export.Pdf;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure
{
    public static class ToPdf
    {
        /// <summary>
        /// 生成PDF
        /// </summary>
        /// <param name="ds">数据源</param>
        /// <param name="templatePath">模板路径</param>
        public static bool PrintCode(DataSet ds, string templatePath, string fileName)
        {
            try
            {
                Report report = new Report();
                report.Load(templatePath);
                // register the dataset
                report.RegisterData(ds);
                report.Prepare();
                // create export instance
                PDFExport export = new PDFExport();
                Stream streamResult = new MemoryStream();
                report.Export(export, streamResult);
                report.Export(export, fileName);
                if (streamResult != null)
                {
                    streamResult.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// 通过传参生成PDF
        /// </summary>
        /// <param name="dicParam">参数集合，包含模板中参数名与对应值</param>
        /// <param name="templatePath">模板路径</param>
        /// <param name="fileName">pdf文件名</param>
        /// <returns></returns>
        public static bool PrintCode(Dictionary<string, string> dicParam, string templatePath, string fileName)
        {
            try
            {
                FastReport.Report report = new FastReport.Report();
                PDFExport export = new PDFExport();
                report.Load(templatePath);
                foreach (string key in dicParam.Keys)
                {
                    report.SetParameterValue(key, dicParam[key]);
                }
                report.Prepare();
                Stream streamResult = new MemoryStream();

                report.Export(export, streamResult);
                report.Export(export, fileName);
                if (streamResult != null)
                {
                    streamResult.Close();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private static byte[] StreamToBytes(Stream stream)
        {
            // 设置当前流的位置为流的开始
            stream.Seek(0, SeekOrigin.Begin);
            byte[] bytes = new byte[stream.Length];
            stream.Read(bytes, 0, bytes.Length);

            return bytes;
        }

    }
}

