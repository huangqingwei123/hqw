﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P2.Infrastructure.Extensions
{
    /// <summary>
    /// 自定义属性
    /// </summary>
    public class CustomAttribute : Attribute
    {
        protected bool _IsSkip = false;
        public CustomAttribute()
        {
        }

        public CustomAttribute(bool IsSkip)
        {
            this._IsSkip = IsSkip;
        }

        public bool IsSkip
        {
            get
            {
                return _IsSkip;
            }
        }
    }
}
