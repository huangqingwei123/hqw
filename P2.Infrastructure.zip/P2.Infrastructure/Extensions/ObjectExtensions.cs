﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;


namespace P2.Infrastructure.Extensions
{
    /// <summary>
    /// 通用类型扩展方法类
    /// </summary>
    public static class ObjectExtensions
    {
        /// <summary>
        /// 把对象类型转化为指定类型，转化失败时返回该类型默认值
        /// </summary>
        /// <typeparam name="T"> 动态类型 </typeparam>
        /// <param name="value"> 要转化的源对象 </param>
        /// <returns> 转化后的指定类型的对象，转化失败返回类型的默认值 </returns>
        public static T CastTo<T>(this object value)
        {
            object result;
            Type type = typeof(T);
            try
            {
                if (type.IsEnum)
                {
                    result = Enum.Parse(type, value.ToString());
                }
                else if (type == typeof(Guid))
                {
                    result = Guid.Parse(value.ToString());
                }
                else
                {
                    result = Convert.ChangeType(value, type);
                }
            }
            catch
            {
                result = default(T);
            }

            return (T)result;
        }

        /// <summary>
        ///     把对象类型转化为指定类型，转化失败时返回指定的默认值
        /// </summary>
        /// <typeparam name="T"> 动态类型 </typeparam>
        /// <param name="value"> 要转化的源对象 </param>
        /// <param name="defaultValue"> 转化失败返回的指定默认值 </param>
        /// <returns> 转化后的指定类型对象，转化失败时返回指定的默认值 </returns>
        public static T CastTo<T>(this object value, T defaultValue, bool isNotNull = false)
        {
            object result;
            Type type = typeof(T);
            try
            {
                result = type.IsEnum ? Enum.Parse(type, value.ToString()) : Convert.ChangeType(value, type);
                if (result == null && isNotNull)
                {
                    result = defaultValue;
                }
            }
            catch
            {
                result = defaultValue;
            }
            return (T)result;
        }

        public static T CastTo<T>(this object value, out bool isError)
        {
            object result;
            Type type = typeof(T);
            try
            {
                if (type.IsEnum)
                {
                    result = Enum.Parse(type, value.ToString());
                }
                else if (type == typeof(Guid))
                {
                    result = Guid.Parse(value.ToString());
                }
                else
                {
                    result = Convert.ChangeType(value, type);
                }
                isError = false;
            }
            catch
            {
                result = default(T);
                isError = true;
            }

            return (T)result;
        }

        public static T CastTo<T>(this object value, T defaultValue, out bool isError)
        {
            object result;
            Type type = typeof(T);
            try
            {
                result = type.IsEnum ? Enum.Parse(type, value.ToString()) : Convert.ChangeType(value, type);
                isError = false;
            }
            catch
            {
                result = defaultValue;
                isError = true;
            }
            return (T)result;
        }

        #region 字符串转成List

        public static List<T> StringToList<T>(this string str)
        {
            if (!String.IsNullOrEmpty(str))
            {
                var data = new List<T>();
                var strArr = str.Split(new char[] { ',' });
                foreach (var e in strArr)
                {
                    data.Add(e.CastTo<T>());
                }
                return data;
            }
            return null;
        }
        #endregion

        #region 判断中文字符
        /// <summary >
        /// 判断是否有中文
        /// </summary >
        /// <param name="str" ></param >
        /// <returns ></returns >
        public static bool IsIncludeChinese(this string str)
        {
            Regex regex = new Regex("[\u4e00-\u9fa5]");
            Match m = regex.Match(str);
            return m.Success;
        }
        #endregion

        public static DateTime TimeParseExact(this string value, string formatStr = "yyyyMMdd")
        {
            try
            {
                return DateTime.ParseExact(value, formatStr, System.Globalization.CultureInfo.CurrentCulture);
            }
            catch
            {
                return DateTime.Now;
            }
        }

        public static decimal PositiveNumber(this decimal value)
        {
            if (value < 0)
            {
                return 0;
            }
            return value;
        }

        public static void CastPropertyNull<T>(this T input)
        {
            foreach (PropertyInfo pi in typeof(T).GetProperties())
            {
                Type columnType = pi.PropertyType;
                if (pi.PropertyType.IsGenericType && pi.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                {
                    columnType = pi.PropertyType.GetGenericArguments()[0];
                }
                if (columnType == typeof(string))
                {
                    var piValue = pi.GetValue(input, null);
                    if (piValue == null)
                    {
                        pi.SetValue(input, "");
                    }
                }
                else if (columnType == typeof(decimal))
                {
                    var piValue = pi.GetValue(input, null);
                    if (piValue == null)
                    {
                        pi.SetValue(input, 0M);
                    }
                }
            }
        }
        /// <summary>
        /// 四舍五入
        /// </summary>
        /// <param name="input">输入值</param>
        /// <param name="reservedNumber">保留小数位数(默认2位)</param>
        /// <param name="midpointRoundingEnum">默认是四舍六入五成双</param>
        /// <returns></returns>
        public static decimal MathRound(this decimal input, int reservedNumber = 2, MidpointRounding midpointRoundingEnum = MidpointRounding.AwayFromZero)
        {
            reservedNumber = (reservedNumber < 0 ? 2 : reservedNumber);
            return Math.Round(input, reservedNumber, midpointRoundingEnum);
        }
        /// <summary>
        /// 日期格式化
        /// </summary>
        /// <param name="input"></param>
        /// <param name="shortDatePattern">格式化字符串（yyyy/MM/dd）</param>
        /// <returns></returns>
        public static string DateTimeFormat(this DateTime input, string shortDatePattern)
        {
            System.Globalization.DateTimeFormatInfo dtFormat = new System.Globalization.DateTimeFormatInfo();
            dtFormat.ShortDatePattern = shortDatePattern;
            return DateTime.Now.ToString(shortDatePattern, dtFormat);
        }
        /// <summary>
        /// 检查枚举Key是否正确
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="input"></param>
        /// <returns></returns>
        public static bool IsEnumsKey<T>(this T input)
        {
            var validateDic = Enums.EnumOperate.enumToDictionary<T>();
            return validateDic.Keys.Contains(input.CastTo<int>());
        }
        /// <summary>
        /// 检查枚举值是否正确
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="input"></param>
        /// <returns></returns>
        public static bool IsEnumsValue<T>(this string input)
        {
            var validateDic = Enums.EnumOperate.enumToDictionary<T>();
            return validateDic.Values.Contains(input);
        }
    }
}