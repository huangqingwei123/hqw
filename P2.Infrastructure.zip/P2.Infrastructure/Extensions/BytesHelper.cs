﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace P2.Infrastructure.Extensions
{
    /// <summary>
    /// 字节帮助类
    /// </summary>
    public static class BytesHelper
    {
        /// <summary>
        /// 获取中英文混排字符串的实际长度(字节数)
        /// </summary>
        /// <param name="str">要获取长度的字符串</param>
        /// <returns>字符串的实际长度值（字节数）</returns>
        public static int GetStringLength(this string str)
        {
            if (str.Equals(string.Empty))
                return 0;
            int strlen = 0;
            ASCIIEncoding strData = new ASCIIEncoding();
            //将字符串转换为ASCII编码的字节数字
            byte[] strBytes = strData.GetBytes(str);
            for (int i = 0; i <= strBytes.Length - 1; i++)
            {
                if (strBytes[i] == 63)  //中文都将编码为ASCII编码63,即"?"号
                    strlen++;
                strlen++;
            }
            return strlen;
        }

        /// <summary>
        /// 按字节数截取字符串
        /// </summary>
        /// <param name="str">要截取的字符串</param>
        /// <param name="length">要截取的字节长度</param>
        /// <returns></returns>
        public static string CutSubstring(this string str, int length)
        {
            byte[] bytes = System.Text.Encoding.Unicode.GetBytes(str);
            int n = 0;  //表示当前的字节数
            int i = 0;  //要截取的字节数
            for (; i < bytes.GetLength(0) && n < length; i++)
            {
                if (i % 2 == 0)//偶数位置，如0、2、4等，为UCS2编码中两个字节的第一个字节
                {
                    n++;//在UCS2第一个字节时n加1
                }
                else
                {
                    if (bytes[i] > 0)//当UCS2编码的第二个字节大于0时，该UCS2字符为汉字，一个汉字算两个字节
                    {
                        n++;
                    }
                }
            }
            //如果i为奇数时,处理成偶数
            if (i % 2 == 1)
            {
                if (bytes[i] > 0)//该UCS2字符是汉字时，去掉这个截一半的汉字
                    i = i - 1;
                else//该UCS2字符是字母或数字，则保留该字符
                    i = i + 1;
            }
            return System.Text.Encoding.Unicode.GetString(bytes, 0, i);
        }
    }
}
