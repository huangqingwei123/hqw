﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using P2.Infrastructure.Extensions;

namespace P2.Infrastructure.Extensions
{
    public class MyMinLengthAttribute : MinLengthAttribute
    {
        public MyMinLengthAttribute(int length) : base(length) { }

        public override string FormatErrorMessage(string name)
        {
            return string.Format("{0}的长度应该不少于{1}！", name, Length);
        }
    }
}