﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using P2.Infrastructure.Extensions;

namespace P2.Infrastructure.Extensions
{
    public class MinByteLengthAttribute : ValidationAttribute
    {
        public MinByteLengthAttribute(int length)
        {
            this._length = length;
            ErrorMessage = "{0}的字节数应该不少于" + length.ToString() + "！";
        }

        private int _length { get; set; }
        public int Length { get { return this._length; } }

        public override bool IsValid(object value)
        {
            string strValue = value as string;
            if (strValue != null)
                return strValue.GetStringLength() >= _length;
            return true;
        }
    }
}