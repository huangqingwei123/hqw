﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using P2.Infrastructure.Extensions;

namespace P2.Infrastructure.Extensions
{
    public class MyMaxLengthAttribute : MaxLengthAttribute
    {
        public MyMaxLengthAttribute(int length)
            : base(length) { }

        public override string FormatErrorMessage(string name)
        {
            return string.Format("{0}的长度应该不超过{1}！", name, Length);
        }
    }
}