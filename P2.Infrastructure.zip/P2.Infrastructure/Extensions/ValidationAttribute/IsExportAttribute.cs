﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace P2.Infrastructure
{
    [System.AttributeUsage(System.AttributeTargets.Property)]
    public class IsExportAttribute : Attribute
    {
        private bool isExport;

        public IsExportAttribute(bool _isExport)
        {
            this.isExport = _isExport;            
        }
    }
}