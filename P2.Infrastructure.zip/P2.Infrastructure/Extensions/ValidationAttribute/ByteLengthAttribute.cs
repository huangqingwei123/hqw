﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using P2.Infrastructure.Extensions;

namespace P2.Infrastructure.Extensions
{
    public class ByteLengthAttribute : ValidationAttribute
    {
        public ByteLengthAttribute(int minLength, int maxLength)
        {
            this._minLength = minLength;
            this._maxlength = maxLength;
            ErrorMessage = "{0}" + string.Format("的字节数需在{0}-{1}之间！", minLength, maxLength);
        }

        private int _minLength { get; set; }        
        public int MaxLength
        {
            get
            {
                return this._maxlength;
            }
        }
        private int _maxlength { get; set; }
        public int MinLength
        {
            get
            {
                return this._minLength;
            }
        }

        public override bool IsValid(object value)
        {
            string strValue = value as string;
            if (strValue != null)
            {
                var byteLength = strValue.GetStringLength();
                return (byteLength >= MinLength && byteLength <= MaxLength);
            }
            return true;            
        }
    }
}