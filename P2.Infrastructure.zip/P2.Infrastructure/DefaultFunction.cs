﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace P2.Infrastructure
{
    public class DefaultFunction
    {/// <summary>
        /// 获取无短线“-”的Guid值，系统所有的Gudi值由此获得，格式统一。

        /// </summary>
        /// <returns></returns>
        public static string GetGuid()
        {
            return GetGuid("N");
        }

        /// <summary>
        /// 获取有格式的Guid值。

        /// </summary>
        /// <param name="format"></param>
        /// <returns></returns>
        public static string GetGuid(string format)
        {
            return System.Guid.NewGuid().ToString(format);
        }

        /// <summary>
        /// 给列集合设置默认值。

        /// </summary>
        /// <param name="dcolObj">列集合。</param>
        public static void SetDefaultValueInDataColumn(DataColumnCollection dcolObj)
        {
            foreach (DataColumn item in dcolObj)
            {
                if (item.DataType == Type.GetType("System.Guid"))
                {
                    item.DefaultValue = new Guid();
                }
                else if (item.DataType == Type.GetType("System.String") || item.DataType == Type.GetType("System.Char"))
                {
                    item.DefaultValue = string.Empty;
                }
                else if (item.DataType == Type.GetType("System.Int16") || item.DataType == Type.GetType("System.Int32") || item.DataType == Type.GetType("System.Int64") || item.DataType == Type.GetType("System.Decimal") || item.DataType == Type.GetType("System.Double"))
                {
                    if (!item.AutoIncrement)
                    {
                        item.DefaultValue = 0;
                    }
                }
                else if (item.DataType == Type.GetType("System.DateTime"))
                {
                    item.DefaultValue = Convert.ToDateTime("1900-1-1");
                }
                else if (item.DataType == Type.GetType("System.Boolean"))
                {
                    item.DefaultValue = false;
                }
            }
        }

        /// <summary>
        /// 设置本系统的日期显示格式。

        /// </summary>
        /// <param name="date">原日期值。</param>
        /// <param name="format">显示格式[例如：yyyy-MM-dd]</param>
        /// <returns></returns>
        public static string SetLocalDataFormat(object date, string format)
        {
            if (date != null && date != System.DBNull.Value && Convert.ToDateTime(date).ToString("yyyy-MM-dd") != "1900-01-01")
            {
                return Convert.ToDateTime(date).ToString(format);
            }
            else
            {
                return string.Empty;
            }
        }


        /// <summary>
        /// 设置本系统的日期显示格式。
        /// </summary>
        /// <param name="date">原日期值。</param>
        /// <param name="format">显示格式[例如：yyyy-MM-dd]</param>
        /// <param name="defaultValue">数据错误时返回的值</param>
        /// <returns></returns>
        public static string SetLocalDataFormat(object date, string format, string defaultValue)
        {
            try
            {
                if (date != null && date != System.DBNull.Value && Convert.ToDateTime(date).ToString("yyyy-MM-dd") != "1900-01-01")
                {
                    return Convert.ToDateTime(date).ToString(format);
                }
                else
                {
                    return string.Empty;
                }
            }
            catch
            {
                return defaultValue;
            }
        }

        /// <summary>
        /// 设置本系统的数字显示格式。

        /// </summary>
        /// <param name="numeric">原日数字。</param>
        /// <param name="format">显示格式[例如：xx.xx]</param>
        /// <returns></returns>
        public static string SetLocalNumericFormat(object numeric, string format)
        {
            if (numeric != null && numeric != System.DBNull.Value)
            {
                return Convert.ToDecimal(numeric).ToString(format);
            }
            else
            {
                return Convert.ToDecimal(0).ToString(format);
            }
        }

        #region 数字转换为汉字


        /// <summary>
        /// 将数字字符串转化为汉字字符串（小写）。

        /// </summary>
        /// <param name="input">输入字符串。</param>
        /// <returns></returns>
        public static string DigitToChinese(string input)
        {
            if (input == null) return null;

            string returns = string.Empty;

            //循环每一个数字字符并转换
            char[] arrDigit = input.ToCharArray();
            for (int i = 0; i < arrDigit.Length; i++)
            {
                switch (arrDigit[i])
                {
                    case '0':
                        returns += "〇";
                        break;
                    case '1':
                        returns += "一";
                        break;
                    case '2':
                        returns += "二";
                        break;
                    case '3':
                        returns += "三";
                        break;
                    case '4':
                        returns += "四";
                        break;
                    case '5':
                        returns += "五";
                        break;
                    case '6':
                        returns += "六";
                        break;
                    case '7':
                        returns += "七";
                        break;
                    case '8':
                        returns += "八";
                        break;
                    case '9':
                        returns += "九";
                        break;
                    default:
                        break;
                }
            }

            return returns;
        }

        /// <summary>
        /// 将日期数据转化为汉语数字（小写）带年月日的字符串。

        /// </summary>
        /// <param name="input">输入日期。</param>
        /// <returns>汉语数字（小写）带年月日的字符串。</returns>
        public static string DateToChinese(DateTime input)
        {
            return YearToChinese(input.Year) + "年" + MonthToChinese(input.Month) + "月" + DayToChinese(input.Day) + "日";
        }

        /// <summary>
        /// 将日期数据转化为汉语数字（小写）。

        /// </summary>
        /// <param name="input">输入天数。</param>
        /// <returns>汉语数字（小写）。</returns>
        public static string DayToChinese(int input)
        {
            string returns = string.Empty;

            if (input > 0 && input < 10)
            {
                returns = DigitToChinese(input.ToString());
            }
            else if (input == 10)
            {
                returns = "十";
            }
            else if (input > 10 && input < 20)
            {
                returns = "十" + DigitToChinese(input.ToString().Substring(1, 1));
            }
            else if (input == 20)
            {
                returns = "廿";
            }
            else if (input > 20 && input < 30)
            {
                returns = "廿" + DigitToChinese(input.ToString().Substring(1, 1));
            }
            else if (input == 30)
            {
                returns = "卅";
            }
            else if (input == 31)
            {
                returns = "卅一";
            }

            return returns;
        }

        /// <summary>
        /// 将日期数据转化为汉语数字（小写）。

        /// </summary>
        /// <param name="input">输入月数。</param>
        /// <returns>汉语数字（小写）。</returns>
        public static string MonthToChinese(int input)
        {
            string returns = string.Empty;

            if (input > 0 && input < 10)
            {
                returns = DigitToChinese(input.ToString());
            }
            else if (input == 10)
            {
                returns = "十";
            }
            else if (input == 11)
            {
                returns = "十一";
            }
            else if (input == 12)
            {
                returns = "十二";
            }

            return returns;
        }

        /// <summary>
        /// 将日期数据转化为汉语数字（小写）。

        /// </summary>
        /// <param name="input">输入年数。</param>
        /// <returns>汉语数字（小写）。</returns>
        public static string YearToChinese(int input)
        {
            return DigitToChinese(input.ToString());
        }

        #endregion 数字转换为汉字


        /// <summary>
        /// DES加密。

        /// </summary>
        /// <param name="pToEncrypt"></param>
        /// <param name="sKey"></param>
        /// <returns></returns>
        public static string DESEncrypt(string encryptString, string key)
        {
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            byte[] inputByteArray = Encoding.Default.GetBytes(encryptString);
            des.Key = ASCIIEncoding.ASCII.GetBytes(key);
            des.IV = ASCIIEncoding.ASCII.GetBytes(key);
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            StringBuilder ret = new StringBuilder();
            foreach (byte b in ms.ToArray())
            {
                ret.AppendFormat("{0:X2}", b);
            }
            ret.ToString();
            return ret.ToString();
        }

        /// <summary>
        /// DES解密。

        /// </summary>
        /// <param name="pToDecrypt"></param>
        /// <param name="sKey"></param>
        /// <returns></returns>
        public static string DESDecrypt(string decryptString, string key)
        {
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();

            byte[] inputByteArray = new byte[decryptString.Length / 2];
            for (int x = 0; x < decryptString.Length / 2; x++)
            {
                int i = (Convert.ToInt32(decryptString.Substring(x * 2, 2), 16));
                inputByteArray[x] = (byte)i;
            }

            des.Key = ASCIIEncoding.ASCII.GetBytes(key);
            des.IV = ASCIIEncoding.ASCII.GetBytes(key);
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();

            StringBuilder ret = new StringBuilder();

            return System.Text.Encoding.Default.GetString(ms.ToArray());
        }

        /// <summary>
        /// 代码数据里的特殊排序
        /// </summary>
        /// <param name="orgObj">数据对象。</param>
        /// <param name="speSortCodeColumn">排序字段。</param>
        /// <param name="spcSortCodeColl">
        /// 特殊排序代码数据集合。

        /// 注意：此处根据数据代码的先后顺序重排。

        /// 范例：490A|436A|434Q</param>
        /// <returns></returns>
        public static DataTable SpecialSortInCodeData(DataTable orgObj, string speSortCodeColumn, string spcSortCodeColl)
        {
            string[] arrSortCode = spcSortCodeColl.Split("|".ToCharArray());
            DataRow[] arrDataRow = null;
            object[] tempObj = null;
            DataRow copyRow = null;
            for (int i = arrSortCode.Length; i > 0; i--)
            {
                arrDataRow = orgObj.Select(speSortCodeColumn + " = '" + arrSortCode[i - 1] + "'");
                for (int j = 0; j < arrDataRow.Length; j++)
                {
                    tempObj = new object[2];
                    arrDataRow[j].ItemArray.CopyTo(tempObj, 0);
                    copyRow = orgObj.NewRow();
                    copyRow.ItemArray = tempObj;
                    orgObj.Rows.Remove(arrDataRow[0]);
                    orgObj.Rows.InsertAt(copyRow, 0);
                }
            }

            return orgObj;
        }
        /// < summary>  
        /// 分析用户请求是否正常  
        /// < /summary>  
        /// < param name="Str">传入用户提交数据< /param>  
        /// < returns>返回是否含有SQL注入式攻击代码< /returns>  
        public static bool ProcessSqlStr(string Str, int type)
        {
            string SqlStr;

            if (type == 1)
                SqlStr = "exec |insert |select |delete |update |count |chr |mid |master |truncate |char |declare ";
            else
                SqlStr = "'|and|exec|insert|select|delete|update|count|*|chr|mid|master|truncate|char|declare";

            bool ReturnValue = true;
            try
            {
                if (Str != "")
                {
                    string[] anySqlStr = SqlStr.Split('|');
                    foreach (string ss in anySqlStr)
                    {
                        if (Str.IndexOf(ss) >= 0)
                        {
                            ReturnValue = false;
                        }
                    }
                }
            }
            catch
            {
                ReturnValue = false;
            }
            return ReturnValue;
        }

        /// <summary>
        /// 过滤字符串：防SQL注入、过滤掉JS和HTML。适合于属性类字段，如title,name等

        /// </summary>
        /// <param name="Val"></param>
        /// <returns></returns>
        public static string FilterVal(string Val)
        {
            string value = Val;
            //防SQL注入
            value = value.Replace("'", "");
            value = value.Replace("--", "");
            value = value.Replace(";", "；");
            value = value.Replace(";--", "");
            value = value.Replace("=", "");
            value = value.Replace("==", "");
            value = value.Replace("&", "");
            value = value.Replace("*", "");
            value = value.Replace("%", "");
            value = value.Replace("@@", "");
            value = value.Replace("+", "");
            value = value.Replace("^", "");
            value = value.Replace("?", "");
            value = value.Replace("(", "");
            value = value.Replace(")", "");
            value = value.Replace("[", "");
            value = value.Replace("]", "");
            value = value.Replace("{", "");
            value = value.Replace("}", "");
            value = value.Replace("/", "");
            value = value.Replace("\\", "");
            value = value.Replace(":", "");

            //过滤JS和HTML
            value = value.Replace("&", "&amp;");
            value = value.Replace("<", "&lt;");
            value = value.Replace(">", "&gt;");
            return value;
        }

        /// <summary>
        /// 格式化eBaySelling表中ListingType字段
        /// </summary>
        /// <param name="duration"></param>
        /// <returns></returns>
        public static string FormateBaySellingListingType(string listingtype)
        {
            string strlistingtype = string.Empty;
            if (listingtype == "Chinese")
            {
                strlistingtype = "AUC";
            }
            else
            {
                strlistingtype = "FIXED";
            }
            return strlistingtype;
        }
        /// <summary>
        /// 格式化eBaySelling表中TimeLeft字段
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public static string getEbayTime(string time)
        {
            if (time != "")
            {
                string strtime = time.Substring(1);
                string converttime = string.Empty;

                if (strtime.IndexOf("D") == -1 && strtime.IndexOf("H") == -1 && strtime.IndexOf("M") == -1)//PT46S
                {
                    string trimstr = strtime.Replace("T", "");
                    return trimstr.ToLower();
                }
                else if (strtime.IndexOf("H") == -1 && strtime.IndexOf("M") == -1 && strtime.IndexOf("S") == -1)//PT12D
                {
                    string trimstr = strtime.Replace("T", "");
                    return trimstr.ToLower();
                }
                else if (strtime.IndexOf("D") == -1 && strtime.IndexOf("H") == -1 && strtime.IndexOf("S") == -1)//PT12M
                {
                    string trimstr = strtime.Replace("T", "");
                    return trimstr.ToLower();
                }
                else if (strtime.IndexOf("D") == -1 && strtime.IndexOf("M") == -1 && strtime.IndexOf("S") == -1)//PT12H
                {
                    string trimstr = strtime.Replace("T", "");
                    return trimstr.ToLower();
                }
                else if (strtime.IndexOf("D") == -1 && strtime.IndexOf("M") == -1)//PT19H46S
                {
                    string trimsec = strtime.Replace("T", "").Substring(0, strtime.IndexOf("H"));
                    return trimsec.ToLower();
                }
                else if (strtime.IndexOf("M") == -1 && strtime.IndexOf("S") == -1)//PT19D20H
                {
                    string trimsec = strtime.Replace("T", "").Substring(0);
                    return trimsec.ToLower();
                }
                else if (strtime.IndexOf("D") == -1 && strtime.IndexOf("H") == -1)//PT20M20S
                {
                    string trimsec = strtime.Replace("T", "").Substring(0, strtime.IndexOf("M"));
                    return trimsec.ToLower();
                }
                else if (strtime.IndexOf("D") == -1 && strtime.IndexOf("S") == -1)//PT12H20M
                {
                    string trimsec = strtime.Replace("T", "").Substring(0);
                    return trimsec.ToLower();
                }
                else if (strtime.IndexOf("H") == -1 && strtime.IndexOf("M") == -1)//PT12D12S
                {
                    string trimsec = strtime.Replace("T", "").Substring(0, strtime.IndexOf("D"));
                    return trimsec.ToLower();
                }
                else if (strtime.IndexOf("H") == -1 && strtime.IndexOf("S") == -1)//PT12D12M
                {
                    string trimsec = strtime.Replace("T", "").Substring(0);
                    return trimsec.ToLower();
                }
                else if (strtime.IndexOf("D") == -1)//没有D的字符串T1H18M26S
                {

                    string trimt = strtime.Replace("T", "");
                    string trimsec = trimt.Substring(0, trimt.IndexOf("M") + 1);
                    converttime = trimsec.ToLower();
                }
                else if (strtime.IndexOf("H") == -1) //没有H的字符串P2DT18M26S
                {
                    string trimt = strtime.Replace("T", "");
                    string trimsec = trimt.Substring(0, trimt.IndexOf("M") + 1);
                    converttime = trimsec.ToLower();
                }
                else if (strtime.IndexOf("M") == -1) //没有M的字符字符串P2DT20H26S
                {
                    string trimt = strtime.Replace("T", "");
                    string trimsec = trimt.Substring(0, strtime.IndexOf("H"));
                    converttime = trimsec.ToLower();

                }
                else if (strtime.IndexOf("S") == -1)//没有S的字符串P2DT22h10m
                {
                    string trimt = strtime.Replace("T", "");
                    converttime = trimt.ToLower();
                }

                else //字符串P2DT22h10m20S
                {
                    string dayhour = strtime.Substring(0, strtime.IndexOf("M") + 1);

                    return dayhour.Replace("T", "").ToLower();
                }
                return converttime;

            }
            else
            {
                return "";
            }

        }
    }
}
