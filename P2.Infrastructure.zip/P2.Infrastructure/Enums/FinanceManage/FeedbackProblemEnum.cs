﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Enums.FinanceManage
{
    public class FeedbackProblemEnum
    {
        public enum ProblemTypeEnum
        {
            无 = 0
        }

        public enum ProcessingResultStatusEnum
        {
            无 = 0,
            奖励 = 1,
            惩罚 = 2
        }
    }
}
