﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Enums.SystemManage
{
    public class RoleEnum
    {
        /// <summary>
        /// 角色类型
        /// </summary>
        public enum RoleType
        {
            系统角色 = 1,
            业务角色 = 2,
            其他角色 = 3,
        }
    }
}
