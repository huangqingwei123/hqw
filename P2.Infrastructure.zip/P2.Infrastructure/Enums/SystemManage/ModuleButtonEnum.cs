﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Enums.SystemManage
{
    public class ModuleButtonEnum
    {
        public enum InitGroupEnum
        {
            导入导出 = 1,
            其他操作 = 2
        }
    }
}
