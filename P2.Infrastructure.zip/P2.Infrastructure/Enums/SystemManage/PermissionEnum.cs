﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Enums.SystemManage
{
    public class PermissionEnum
    {
        /// <summary>
        /// 对象分类
        /// </summary>
        public enum ObjectTypeEnum
        {
            角色 = 1,
            用户 = 2,
            部门 = 3
        }

        /// <summary>
        /// 项目类型
        /// </summary>
        public enum ItemTypeEnum
        {
            模块 = 1,
            按钮 = 2,
            列表 = 3
        }
    }
}
