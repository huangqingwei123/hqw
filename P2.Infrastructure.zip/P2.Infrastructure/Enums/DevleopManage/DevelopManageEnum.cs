﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Enums.DevelopManage
{
    /// <summary>
    /// 开发管理公共枚举
    /// </summary>
    public class DevelopManageEnum
    {
        /// <summary>
        /// 产品部考核类型
        /// </summary>
        public enum SourceTypeEnum
        {
            总绩效提成汇总 = 0,
            项目绩效提成 = 1,
            月度考核 = 2
        }

        /// <summary>
        /// 项目类型
        /// </summary>
        public enum ProjectTypeEnum
        {
            一般项目 = 0,
            重点项目 = 1,
            自产项目 = 2,
            自产Combo项目 = 3,
        }
    }
}
