﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Enums.DevelopManage
{
    public class DevelopBonusEnum
    {
        /// <summary>
        /// 销售国家
        /// </summary>
        public enum SalesCountryEnum
        {
            /// <summary>
            /// 英国
            /// </summary>
            UK,
            /// <summary>
            /// 德国
            /// </summary>
            DE,
            /// <summary>
            /// 西班牙
            /// </summary>
            ES,
            /// <summary>
            /// 法国
            /// </summary>
            FR,
            /// <summary>
            /// 意大利
            /// </summary>
            IT,
            /// <summary>
            /// 美国
            /// </summary>
            US,
            /// <summary>
            /// 加拿大
            /// </summary>
            CA,
            /// <summary>
            /// 墨西哥
            /// </summary>
            MX,
            /// <summary>
            /// 日本
            /// </summary>
            JP,
            /// <summary>
            /// 澳大利亚
            /// </summary>
            AU,
        }

        /// <summary>
        /// 提成方案
        /// </summary>
        public enum BonusSchemeEnum
        {
            /// <summary>
            /// AO_Half_Year
            /// 深仓到货6个月内
            /// </summary>
            空运_深仓到货6个月内 = 1,
            /// <summary>
            /// AO_Year
            /// 深仓到货7~12个月内
            /// </summary>
            空运_深仓到货7至12个月内 = 2,
            /// <summary>
            /// 非空运
            /// 深仓到货8个月内
            /// </summary>
            非空运_深仓到货8个月内 = 3,
            /// <summary>
            /// 非空运
            /// 深仓到货9~14个月内
            /// </summary>
            非空运_深仓到货9至14个月 = 4,
        }

        /// <summary>
        /// 提成类型
        /// </summary>
        public enum BonusTypeEnum
        {
            /// <summary>
            /// 空运
            /// </summary>
            AO = 1,
            /// <summary>
            /// 非空运
            /// </summary>
            NAO = 2
        }

        /// <summary>
        /// 产品默认运输方式
        /// </summary>
        public enum ShippingWayEnum
        {
            PREFER_AIR,
            PREFER_SEA,
            AIR_ONLY,
            SEA_ONLY,
            SFK_ONLY,
            FORBID_AIR,
        }

        /// <summary>
        /// 状态
        /// </summary>
        public enum BonusStatusEnum
        {
            /// <summary>
            /// 临时状态
            /// 程序使用
            /// </summary>
            默认状态 = 0,
            /// <summary>
            /// 最后用来汇总绩效用的数据
            /// </summary>
            已计入绩效 = 1,
            /// <summary>
            /// 产品相关
            /// 第一次深仓到以及FBA第一次倒仓时间
            /// </summary>
            未获取到产品第一次到仓时间 = 2,
            /// <summary>
            /// 产品相关
            /// </summary>
            未匹配到提成方案 = 3,
            /// <summary>
            /// 产品，国家相关
            /// </summary>
            低利润不计算绩效 = 4,
            /// <summary>
            /// 产品，国家相关
            /// </summary>
            未获取到产品在区域的成本价 = 5,
            /// <summary>
            /// 订单相关
            /// </summary>
            未获取到国家信息 = 6,
            /// <summary>
            /// 产品，国家相关
            /// </summary>
            营销推广后无利润 = 7
        }

        /// <summary>
        /// 项目岗位角色
        /// 1.	提项提项人员、跟进人员、审核委员、取【项目汇总】模块中的提项人、跟进人、评审人
        /// 2.	自定义岗位人员取本模块中的“岗位人员管理”
        /// </summary>
        public enum ProjectJobRoleEnum
        {
            /// <summary>
            /// Proposer            
            /// </summary>
            项目提项人员 = 1,
            /// <summary>
            /// Reviewer
            /// </summary>
            项目审核人员 = 2,
            /// <summary>
            /// FollowPeople
            /// </summary>
            项目跟进人员 = 3,
            /// <summary>
            /// 自定义岗位
            /// </summary>
            自定义岗位 = 4
        }

        /// <summary>
        /// 绩效订单来源
        /// </summary>
        public enum BonusOrderSourceEnum
        {
            /// <summary>
            /// 订单跟踪Amazon分销商数据
            /// </summary>
            FBA订单 = 0,
            /// <summary>
            /// Amazon Vendor-Invoice中MarketPlace为Amazon.com
            /// </summary>
            Vendor订单 = 1
        }

    }
}
