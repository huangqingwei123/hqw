﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Enums.LogisticsManage
{
    public class LOGProviderStatementEnum
    {
        public enum StatusEnum
        {
            /// <summary>
            /// 待确认
            /// </summary>
            待确认 = 0,
            /// <summary>
            /// 财务已确认
            /// </summary>
            财务已确认 = 1,
            /// <summary>
            /// 暂未使用
            /// </summary>
            物流商已确认 = 2,
        }

        public enum SourceEnum
        {
            /// <summary>
            /// 物流订单
            /// </summary>
            物流订单 = 0,
            /// <summary>
            /// 索赔单
            /// </summary>
            索赔单 = 1
        }
    }
}
