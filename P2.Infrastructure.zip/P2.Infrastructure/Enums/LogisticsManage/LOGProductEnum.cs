﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Enums.LogisticsManage
{
    /// <summary>
    /// 物流产品公共枚举
    /// </summary>
    public class LOGProductEnum
    {
        /// <summary>
        /// 产品部考核类型
        /// </summary>
        public enum WeightUnitEnum
        {
            /// <summary>
            /// 千克
            /// </summary>
            Kg = 0,
        }

    }
}
