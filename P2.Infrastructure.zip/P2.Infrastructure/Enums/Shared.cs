﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Enums
{
    /// <summary>
    /// 公共枚举
    /// </summary>
    public class Shared
    {
        public enum ValidType
        {
            禁用 = 0,
            启用 = 1
        }

        /// <summary>
        /// 排序类型
        /// </summary>
        public enum SortOrder
        {
            UnSpecified = -1,
            Ascending = 0,
            Descending = 1
        }
        /// <summary>
        /// 操作
        /// </summary>
        public enum Operate
        {
            Create,
            Modify,
            Remove,
        }

        /// <summary>
        /// 字典编码枚举
        /// </summary>
        public enum ItemsEnum
        {
            /// <summary>
            /// 费用报销用途
            /// </summary>
            ReimbursementUse = 1,
        }
    }
}
