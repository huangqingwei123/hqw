﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Enums.StoreManage
{
    public class FBAInventoryEnum
    {
        public enum FBAInventoryQuerySiteEnum
        {
            US = 1,
            CA = 2,
            JP = 3,
            EU = 4,
            MX = 5,
            AU = 6,
            RU = 7,
            IN = 8,
            UAE = 9,
            KSA = 10
        }
    }
}
