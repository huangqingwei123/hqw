﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using P2.Infrastructure.Extensions;
using System.Reflection;
using System.ComponentModel;

namespace P2.Infrastructure.Enums
{
    public class EnumOperate
    {
        /// <summary>
        /// 将enum 转成Dictionary(int,string) 
        /// </summary>
        /// <returns></returns>
        public static Dictionary<int, string> enumToDictionary<T>(bool getDescription = false, int descriptionIndex = 0)
        {
            Type userType = typeof(T);
            Dictionary<int, string> dictionary = new Dictionary<int, string>();
            foreach (string value in Enum.GetNames(userType))
            {
                var thisEnum = Enum.Parse(userType, value) as Enum;
                var enumKey = int.Parse(Enum.Format(userType, thisEnum, "D"));
                dictionary.Add(enumKey, GetEnumDescription(thisEnum, getDescription, descriptionIndex));
            }
            return dictionary;
        }

        /// <summary>
        /// 将枚举转化为字典
        /// </summary>
        /// <typeparam name="T">枚举类型</typeparam>
        /// <param name="isMatch">是否匹配后面的参数得到相应的结果，反之就排除</param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public static Dictionary<int, string> enumToDictionary<T>(bool isMatch, bool getDescription = false, int descriptionIndex = 0, params T[] parameters)
        {
            Type userType = typeof(T);
            Dictionary<int, string> dictionary = new Dictionary<int, string>();
            foreach (var value in Enum.GetNames(userType))
            {
                var isSkip = isMatch;
                var thisEnum = Enum.Parse(userType, value) as Enum;
                var enumKey = int.Parse(Enum.Format(userType, thisEnum, "D"));
                if (parameters != null && parameters.Length > 0)
                {
                    for (var i = 0; i < parameters.Length; i++)
                    {
                        var isError = false;
                        var excludeProperty = parameters[i].CastTo<int>(out isError);
                        if (!isError)
                        {
                            if (excludeProperty == enumKey)
                            {
                                isSkip = !isMatch;
                                break;
                            }
                        }
                    }
                }
                if (!isSkip)
                {
                    dictionary.Add(enumKey, GetEnumDescription(thisEnum, getDescription, descriptionIndex));
                }
            }
            return dictionary;
        }

        /// <summary>
        /// 获取枚举的描述
        /// </summary>
        /// <param name="enumValue">枚举值</param>
        /// <param name="getDescription">字典值是否获取枚举的描述，默认取枚举值</param>
        /// <param name="descriptionIndex">枚举描述的索引，getDescription=true时有效</param>        
        /// <returns></returns>
        public static string GetEnumDescription(Enum enumValue, bool getDescription = false, int descriptionIndex = 0)
        {
            string value = enumValue.ToString();
            FieldInfo field = enumValue.GetType().GetField(value);
            if (getDescription)
            {
                object[] objs = field.GetCustomAttributes(typeof(DescriptionAttribute), false);//获取描述属性                
                if (objs == null || objs.Length == 0)    //当描述属性没有时，直接返回名称
                    return value;
                if (descriptionIndex > objs.Length - 1)
                    throw new Exception("Index out of array range");
                return ((DescriptionAttribute)objs[descriptionIndex]).Description;
            }
            return value;
        }
    }
}
