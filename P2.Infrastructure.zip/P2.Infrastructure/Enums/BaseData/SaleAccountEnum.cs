﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Enums
{
    public class SaleAccountEnum
    {
        public enum AccountGrade
        {
            主账号 = 1,
            次账号 = 2,
            维持账号 = 3,
            小账号 = 4,
        }

        public enum SellerType
        {
            Amazon,
            eBay,
            BuyCom,
            General,
            NEWEGG,
        }

    }

}
