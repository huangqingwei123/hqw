﻿namespace P2.Infrastructure.Enums
{
    public enum BizProductItemState
    {
        正式 = 0,
        非正式 = 1,
    }

    public enum BizProductItemApproveState
    {
        安检通过 = 0,
        销售部建CODE = 1,
        质检通过 = 2,
        质检不通过 = 3,
        销售部通过 = 4,
        销售部不通过 = 5,
        安检不通过 = 6,
    }

    public enum PlugSpec
    {
        无规格 = 0,
        英规 = 1,
        欧规 = 2,
        欧英规 = 3,
        美加规 = 4,
        美欧规 = 5,
        澳规 = 6,
        日规 = 7,
        美加日规 = 8,

    }

    public enum ComplainType
    {
        QualityIssue = 1,
        MissingParts = 2,
        NotAsDescribed = 3,
        WrongShippping = 4,
        FBAShipment = 5,
        Other = 9,
    }
}