﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace P2.Infrastructure
{
    public sealed class P2LogManager
    {
        /// <summary>
        /// 错误日志文件名
        /// </summary>
        private const string ERROR_LOG_FILE_NAME = "ErrorLog.txt";
        /// <summary>
        /// 操作系统系统路径
        /// </summary>
        private static readonly string m_OSRootDir = HttpContext.Current.Request.PhysicalApplicationPath;

        /// <summary>
        /// 用于锁定写日志的虚对象
        /// </summary>
        private static object m_writeLock = new object();

        /// <summary>
        /// 用于锁定写Rmi日志的虚对象
        /// </summary>
        private static object m_writeRmiLock = new object();

        /// <summary>
        /// 构造器
        /// </summary>
        private P2LogManager()
        {
        }

        /// <summary>
        /// 写组件的错误日志
        /// </summary>
        /// <param name="logMessage">错误消息</param>
        public static void WriteErrorLog(string logMessage)
        {
            string errLogFile = m_OSRootDir + Path.DirectorySeparatorChar.ToString() + ERROR_LOG_FILE_NAME;

            string path = Path.GetDirectoryName(errLogFile);
            if (!Directory.Exists(path)) { Directory.CreateDirectory(path); }

            //检查文件的大小，如果超过5M，就需要备份
            bool isExceeding = false;
            if (File.Exists(errLogFile))
            {
                FileStream fileStream = File.OpenRead(errLogFile);
                if (fileStream.Length > 5000000)
                    isExceeding = true;
                fileStream.Close();
            }

            if (isExceeding)
            {
                string newLogFile = "";
                for (long i = 1; ; i++)
                {
                    newLogFile = Path.GetFileNameWithoutExtension(errLogFile) + "_Backup_" + i.ToString() + ".txt";
                    newLogFile = Path.Combine(Path.GetDirectoryName(errLogFile), newLogFile);
                    if (!File.Exists(newLogFile))
                        break;
                }

                File.Move(errLogFile, newLogFile);
            }

            //改变写文件的方式,允许写共享		邓宗文		2005-09-04
            /*
            StreamWriter sw = new StreamWriter(errLogFile,true);
		
            sw.WriteLine(logMessage);

            sw.Close();
            */
            lock (m_writeLock)
            {
                try
                {
                    FileStream fs = File.Open(errLogFile, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
                    byte[] data = Encoding.Default.GetBytes(logMessage);
                    fs.Write(data, 0, data.Length);
                    fs.Flush();
                    fs.Close();
                    data = null;
                    fs = null;
                }
                catch (Exception ex)
                {
                    EventLog.WriteEntry("P2", "写日志文件时出错：" + ex.Message);
                }
            }
        }

        /// <summary>
        /// 写远程调用的日志
        /// </summary>
        /// <param name="logFileName">日志文件名</param>
        /// <param name="logMessage">日志消息</param>
        public static void WriteRmiLog(string logFileName, string logMessage)
        {
            string errLogFile = m_OSRootDir + Path.DirectorySeparatorChar.ToString() + ERROR_LOG_FILE_NAME;
           
            string path = Path.GetDirectoryName(errLogFile);
            if (!Directory.Exists(path)) { Directory.CreateDirectory(path); }

            //检查文件的大小，如果超过5M，就需要备份
            bool isExceeding = false;
            if (File.Exists(errLogFile))
            {
                FileStream fileStream = File.OpenRead(errLogFile);
                if (fileStream.Length > 5000000)
                    isExceeding = true;
                fileStream.Close();
            }

            if (isExceeding)
            {
                string newLogFile = "";
                for (long i = 1; ; i++)
                {
                    newLogFile = Path.GetFileNameWithoutExtension(errLogFile) + "_Backup_" + i.ToString() + ".txt";
                    newLogFile = Path.Combine(Path.GetDirectoryName(errLogFile), newLogFile);
                    if (!File.Exists(newLogFile))
                        break;
                }

                File.Move(errLogFile, newLogFile);
            }


            //改变写文件的方式,允许写共享	
            /*
            StreamWriter sw = new StreamWriter(errLogFile,true);

            sw.WriteLine(logMessage);

            sw.Close();
            */


            lock (m_writeRmiLock)
            {
                try
                {
                    FileStream fs = File.Open(errLogFile, FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
                    byte[] data = Encoding.Default.GetBytes(logMessage);
                    fs.Write(data, 0, data.Length);
                    fs.Flush();
                    fs.Close();
                    data = null;
                    fs = null;
                }
                catch (Exception ex)
                {
                    EventLog.WriteEntry("P2", "写日志文件时出错：" + ex.Message);
                }
            }
        }
    }
}
