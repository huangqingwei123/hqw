﻿using ICSharpCode.SharpZipLib.Zip;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace P2.Infrastructure
{
    public class FileCompression
    {
        public FileCompression()
        {
            //
            // TODO: 在此处添加构造函数逻辑
            //
        }
        #region 加密、压缩文件

        /// <summary>   
        /// 压缩文件   
        /// </summary>   
        /// <param name="fileNames">要打包的文件列表</param>   
        /// <param name="GzipFileName">目标文件名</param>   
        /// <param name="CompressionLevel">压缩品质级别（0~9）</param>   
        /// <param name="SleepTimer">休眠时间（单位毫秒）</param>        
        public static void Compress(List<FileInfo> fileNames, string GzipFileName, int CompressionLevel, int SleepTimer)
        {
            ZipOutputStream s = new ZipOutputStream(System.IO.File.Create(GzipFileName));
            try
            {
                s.SetLevel(CompressionLevel);   //0 - store only to 9 - means best compression   
                foreach (FileInfo file in fileNames)
                {
                    FileStream fs = null;
                    try
                    {
                        fs = file.Open(FileMode.Open, FileAccess.ReadWrite);
                    }
                    catch
                    { continue; }
                    //  方法二，将文件分批读入缓冲区   
                    byte[] data = new byte[2048];
                    int size = 2048;
                    ZipEntry entry = new ZipEntry(Path.GetFileName(file.Name));
                    entry.DateTime = (file.CreationTime > file.LastWriteTime ? file.LastWriteTime : file.CreationTime);
                    s.PutNextEntry(entry);
                    while (true)
                    {
                        size = fs.Read(data, 0, size);
                        if (size <= 0) break;
                        s.Write(data, 0, size);
                    }
                    fs.Close();
                    file.Delete();
                    Thread.Sleep(SleepTimer);
                }
            }
            finally
            {
                s.Finish();
                s.Close();
            }
        }

        /// <summary>   
        /// 压缩文件   
        /// </summary>   
        /// <param name="fileNames">要打包的文件列表</param>   
        /// <param name="GzipFileName">目标文件名</param>   
        /// <param name="CompressionLevel">压缩品质级别（0~9）</param>   
        /// <param name="SleepTimer">休眠时间（单位毫秒）</param>        
        public static void CompressUnFileDelete(List<FileInfo> fileNames, string GzipFileName, int CompressionLevel, int SleepTimer)
        {
            ZipOutputStream s = new ZipOutputStream(System.IO.File.Create(GzipFileName));
            try
            {

                s.SetLevel(CompressionLevel);   //0 - store only to 9 - means best compression   
                foreach (FileInfo file in fileNames)
                {

                    FileStream fs = null;
                    try
                    {
                        fs = file.Open(FileMode.Open, FileAccess.ReadWrite);

                    }
                    catch
                    { continue; }

                    BufferedStream bs = new BufferedStream(fs);
                    //  方法二，将文件分批读入缓冲区   
                    byte[] data = new byte[2048];
                    int size = 2048;
                    ZipEntry entry = new ZipEntry(Path.GetFileName(file.Name));
                    entry.DateTime = (file.CreationTime > file.LastWriteTime ? file.LastWriteTime : file.CreationTime);
                    s.PutNextEntry(entry);
                    while (true)
                    {
                        size = fs.Read(data, 0, size);
                        if (size <= 0) break;
                        s.Write(data, 0, size);
                    }
                    bs.Close();
                    fs.Close();
                    //file.Delete();
                    Thread.Sleep(SleepTimer);
                }
            }
            finally
            {
                s.Finish();
                s.Close();
            }
        }

        /// <summary>   
        /// 压缩文件(带文件夹) 
        /// </summary>   
        /// <param name="fileNames">要打包的文件列表</param>   
        /// <param name="GzipFileName">目标文件名</param>   
        /// <param name="CompressionLevel">压缩品质级别（0~9）</param>   
        /// <param name="SleepTimer">休眠时间（单位毫秒）</param>        
        public static void CompressContainFolder(List<FileInfo> fileNames, string GzipFileName, int CompressionLevel, int SleepTimer)
        {
            ZipOutputStream s = new ZipOutputStream(System.IO.File.Create(GzipFileName));
            try
            {

                s.SetLevel(CompressionLevel);   //0 - store only to 9 - means best compression   
                foreach (FileInfo file in fileNames)
                {


                    if (file.Attributes == FileAttributes.Directory)//如果是文件夹，遍历文件夹内容,目前只有单层文件夹遍历，要遍历子文件夹需要改成递归
                    {
                        DirectoryInfo folder = new DirectoryInfo(file.FullName);
                        foreach (FileInfo NextFile in folder.GetFiles())
                        {
                            FileStream fs = null;
                            try
                            {
                                fs = NextFile.Open(FileMode.Open, FileAccess.ReadWrite);

                            }
                            catch
                            { continue; }

                            BufferedStream bs = new BufferedStream(fs);
                            //  方法二，将文件分批读入缓冲区   
                            byte[] data = new byte[2048];
                            int size = 2048;
                            ZipEntry entry = new ZipEntry(folder.Name + "\\" + NextFile.Name);
                            entry.DateTime = (file.CreationTime > file.LastWriteTime ? file.LastWriteTime : file.CreationTime);
                            s.PutNextEntry(entry);
                            while (true)
                            {
                                size = fs.Read(data, 0, size);
                                if (size <= 0) break;
                                s.Write(data, 0, size);
                            }
                            bs.Close();
                            fs.Close();
                            //file.Delete();
                            Thread.Sleep(SleepTimer);
                        }
                    }
                    else
                    {
                        FileStream fs = null;
                        try
                        {
                            fs = file.Open(FileMode.Open, FileAccess.ReadWrite);
                        }
                        catch
                        { continue; }

                        BufferedStream bs = new BufferedStream(fs);
                        //  方法二，将文件分批读入缓冲区   
                        byte[] data = new byte[2048];
                        int size = 2048;
                        ZipEntry entry = new ZipEntry(file.Name);
                        entry.DateTime = (file.CreationTime > file.LastWriteTime ? file.LastWriteTime : file.CreationTime);
                        s.PutNextEntry(entry);
                        while (true)
                        {
                            size = fs.Read(data, 0, size);
                            if (size <= 0) break;
                            s.Write(data, 0, size);
                        }
                        bs.Close();
                        fs.Close();
                        //file.Delete();
                        Thread.Sleep(SleepTimer);
                    }
                }
            }
            finally
            {
                s.Finish();
                s.Close();
            }
        }
        #endregion

        #region 解密、解压缩文件
        /// <summary>   
        /// 解压缩文件   
        /// </summary>   
        /// <param name="GzipFile">压缩包文件名</param>   
        /// <param name="targetPath">解压缩目标路径</param>          
        public static void Decompress(string GzipFile, string targetPath)
        {
            //string directoryName = Path.GetDirectoryName(targetPath + "\\") + "\\";   
            string directoryName = targetPath;
            if (!Directory.Exists(directoryName)) Directory.CreateDirectory(directoryName);//生成解压目录   
            string CurrentDirectory = directoryName;
            byte[] data = new byte[2048];
            int size = 2048;
            ZipEntry theEntry = null;
            using (ZipInputStream s = new ZipInputStream(System.IO.File.OpenRead(GzipFile)))
            {
                while ((theEntry = s.GetNextEntry()) != null)
                {
                    if (theEntry.IsDirectory)
                    {// 该结点是目录   
                        if (!Directory.Exists(CurrentDirectory + theEntry.Name)) Directory.CreateDirectory(CurrentDirectory + theEntry.Name);
                    }
                    else
                    {
                        if (theEntry.Name != String.Empty)
                        {
                            //解压文件到指定的目录   
                            using (FileStream streamWriter = System.IO.File.Create(CurrentDirectory + theEntry.Name))
                            {
                                while (true)
                                {
                                    size = s.Read(data, 0, data.Length);
                                    if (size <= 0) break;

                                    streamWriter.Write(data, 0, size);
                                }
                                streamWriter.Close();
                            }
                        }
                    }
                }
                s.Close();
            }
        }
        #endregion
    }
}
