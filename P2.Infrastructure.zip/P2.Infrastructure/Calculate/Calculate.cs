﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure.Calculate
{
    public class Calculate
    {
        /// <summary>
        /// 平均年限法
        /// </summary>
        /// <param name="ExpectedNetResidualRate">预计净残值率</param>
        /// <param name="ExpectedMonth">预计使用月份</param>
        /// <param name="Price">原始原值</param>
        /// <param name="MonthlyDepreciationRate">月折旧率</param>
        /// <param name="MonthlyDepreciation">月折旧额</param>
        /// <returns></returns>
        public static bool AvgAgeMethod(decimal ExpectedNetResidualRate, int ExpectedMonth, decimal Price, out decimal MonthlyDepreciationRate, out decimal MonthlyDepreciation)
        {
            MonthlyDepreciationRate = 0M;
            MonthlyDepreciation = 0M;
            try
            {
                MonthlyDepreciationRate = Math.Round((1 - ExpectedNetResidualRate) / (ExpectedMonth * 1M), 2, MidpointRounding.AwayFromZero);
                MonthlyDepreciation = Math.Round(Price * (1 - ExpectedNetResidualRate) / (ExpectedMonth * 1M), 2, MidpointRounding.AwayFromZero);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// 平均年限法（二）
        /// </summary>
        /// <param name="ExpectedNetPrice">净残值</param>
        /// <param name="ExpectedMonth">预计使用月份</param>
        /// <param name="Price">原值</param>
        /// <param name="CountedMonth">累计月份</param>
        /// <param name="DepreciationAmount">累计折旧</param>
        /// <param name="MonthlyDepreciationRate">月折旧率</param>
        /// <param name="MonthlyDepreciation">月折旧额</param>
        /// <returns></returns>
        public static bool AvgAgeMethod2(decimal ExpectedNetPrice, int ExpectedMonth, decimal Price, int CountedMonth, decimal DepreciationAmount, out decimal MonthlyDepreciationRate, out decimal MonthlyDepreciation)
        {
            MonthlyDepreciationRate = 0M;
            MonthlyDepreciation = 0M;
            try
            {
                MonthlyDepreciation = Math.Round((Price - ExpectedNetPrice - DepreciationAmount) / ((ExpectedMonth - CountedMonth) * 1M), 2, MidpointRounding.AwayFromZero);
                MonthlyDepreciationRate = Math.Round(MonthlyDepreciation / (Price - ExpectedNetPrice), 2, MidpointRounding.AwayFromZero);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
