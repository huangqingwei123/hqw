﻿using Aspose.Cells;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using P2.Infrastructure.Extensions;

namespace P2.Infrastructure.Aspose
{
    public class AsposeExcelHelper
    {
        /// <summary>
        /// 数据处理
        /// </summary>
        /// <param name="dtMainList">关键字数据集，不同sheet的数据表名需对应模板sheet名否则默认第一个sheet</param>
        /// <param name="dsDataList">整个模板的列表数据集</param>
        /// <param name="tempPath">模板路径</param>
        /// <param name="filePath">输出路径</param>
        /// <returns></returns>
        public static bool DealData(List<DataTable> dtMainList, DataSet dsDataList, string tempPath, string filePath)
        {
            try
            {
                Workbook workbook = new Workbook(tempPath);
                WorksheetCollection wc = workbook.Worksheets;
                foreach (DataTable dt in dtMainList)
                {
                    string sheetName = dt.TableName;//要处理的sheet名
                    if (wc[sheetName] == null)
                    {
                        sheetName = wc[0].Name;//excel中找不到对应的sheet则默认在第一个sheet处理;
                    }
                    DealDataBySheet(dt, sheetName, ref workbook);
                }
                if (dsDataList != null)
                {
                    WorkbookDesigner wd = new WorkbookDesigner(workbook);
                    wd.SetDataSource(dsDataList);//设置多个列表的数据源
                    wd.Process();
                }
                string suffix = filePath.Substring(filePath.LastIndexOf(".")+1).ToLower();
                if (suffix == "pdf")
                {
                    PdfSaveOptions saveOption = new PdfSaveOptions();
                    saveOption.SecurityOptions = new global::Aspose.Cells.Rendering.PdfSecurity.PdfSecurityOptions();
                    //saveOption.SecurityOptions.OwnerPassword = "NEEWER!#%135";
                    saveOption.SecurityOptions.ExtractContentPermission = false;
                    saveOption.SecurityOptions.PrintPermission = true;
                    workbook.Save(filePath, saveOption);
                }
                else 
                {
                    workbook.Save(filePath);
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        /// <summary>
        /// 按sheet处理数据
        /// </summary>
        /// <param name="dtDataMain">关键字数据集</param>
        /// <param name="sheetName">sheet名</param>
        /// <param name="workbook"></param>
        /// <returns></returns>
        public static string DealDataBySheet(DataTable dtDataMain, string sheetName, ref Workbook workbook)
        {
            try
            {
                Worksheet sheet = workbook.Worksheets[sheetName];
                Cells cells = sheet.Cells;
                int maxRow = cells.MaxDataRow;//包含数据的最大行数
                int maxCol = cells.MaxDataColumn;//包含数据的最大列数
                //设定遍历范围area
                CellArea area = CellArea.CreateCellArea(0, 0, maxRow, maxCol);
                FindOptions opts = new FindOptions();
                opts.CaseSensitive = true;
                opts.LookInType = LookInType.Values;
                opts.LookAtType = LookAtType.Contains;
                opts.SetRange(area);
                foreach (DataRow dr in dtDataMain.Rows)
                {
                    string key = dr["Key"].ToString();
                    string val = dr["Val"].ToString();
                    ReplaceText(opts, key, val, ref sheet);
                }
                return "Success";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 关键字替换
        /// </summary>
        /// <param name="option"></param>
        /// <param name="keyText">关键字</param>
        /// <param name="replaceText">数据值</param>
        /// <param name="sheet">sheet</param>
        public static void ReplaceText(FindOptions option, string keyText, string replaceText, ref Worksheet sheet)
        {
            Cell cell = null;
            do
            {
                cell = sheet.Cells.Find(keyText, cell, option);
                if (cell == null)
                {
                    break;
                }
                cell.PutValue(cell.Value.ToString().Replace(keyText, replaceText));
            }
            while (true);
        }

        /// <summary>
        /// 根据实体转Main表
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="model"></param>
        /// <returns></returns>
        public static DataTable ToMainTable<T>(T model)
        {
            DataTable dtMain = new DataTable();
            dtMain.Columns.Add("Key");
            dtMain.Columns.Add("Val");

            var type = typeof(T);
            var properties = type.GetProperties();
            foreach (var proty in properties)
            {
                DataRow dr_Main = dtMain.NewRow();
                dr_Main["Key"] = "{" + proty.Name + "}";
                dr_Main["Val"] = proty.GetValue(model, null);
                dtMain.Rows.Add(dr_Main);
            }
            return dtMain;
        }
    }
}
