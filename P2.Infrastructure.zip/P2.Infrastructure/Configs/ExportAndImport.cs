﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure
{
    public class ExportAndImport
    {
        /// <summary>
        /// 导出文件存放目录相对路径
        /// </summary>
        public static string ExportFileRelativePath
        {
            get
            {
                return "~\\Uploads\\";
            }
        }

        /// <summary>
        /// 导出文件存放目录绝对路径
        /// </summary>
        public static string ExportFileAbsolutePath
        {
            get
            {
                return FileHelper.MapPath(ExportFileRelativePath);
            }
        }

        /// <summary>
        /// 图片上传保存目录相对路径
        /// </summary>
        public static string UploadImageRelativePath
        {
            get
            {
                return "~\\UploadImages\\";
            }
        }

        /// <summary>
        /// 图片保存目录绝对路径
        /// </summary>
        public static string UploadImageAbsolutePath
        {
            get
            {
                return FileHelper.MapPath(UploadImageRelativePath);
            }
        }

        /// <summary>
        /// 物流商文件保存目录相对路径
        /// </summary>
        public static string UploadLOGFileRelativePath
        {
            get
            {
                return "~\\Areas\\LogisticsManage\\Uploads\\";
            }
        }

        /// <summary>
        /// 物流商文件保存目录绝对路径
        /// </summary>
        public static string UploadLOGFileAbsolutePath
        {
            get
            {
                return FileHelper.MapPath(UploadLOGFileRelativePath);
            }
        }

        /// <summary>
        /// 退货和销毁订单文件保存目录相对路径
        /// </summary>
        public static string UploadReturnAndDisposeOrderFileRelativePath
        {
            get
            {
                return "~\\Areas\\AmazonRemovalManage\\Uploads\\";
            }
        }

        /// <summary>
        /// 退货和销毁订单文件保存目录绝对路径
        /// </summary>
        public static string UploadReturnAndDisposeOrderFileAbsolutePath
        {
            get
            {
                return FileHelper.MapPath(UploadReturnAndDisposeOrderFileRelativePath);
            }
        }

        /// <summary>
        /// 培训视频文件保存目录相对路径
        /// </summary>
        public static string UploadTrainingVideoFileRelativePath
        {
            get
            {
                return "~\\Areas\\BusinessManagement\\Uploads\\";
            }
        }

        /// <summary>
        /// 培训视频文件保存目录绝对路径
        /// </summary>
        public static string UploadTrainingVideoFileAbsolutePath
        {
            get
            {
                return FileHelper.MapPath(UploadTrainingVideoFileRelativePath);
            }
        }

        /// <summary>
        /// 表格拼接文件保存路径
        /// </summary>
        public static string UploadTableJointFilePath
        {
            get
            {
                return "~\\Areas\\BusinessManagement\\TableJointTemp\\";
            }
        }

        /// <summary>
        /// 表格拼接文件保存目录绝对路径
        /// </summary>
        public static string UploadUploadTableJointFileAbsolutePath
        {
            get
            {
                return FileHelper.MapPath(UploadTableJointFilePath);
            }
        }

        /// <summary>
        /// 产品认证文件保存路径
        /// </summary>
        public static string UploadProductCertificationFilePath
        {
            get
            {
                return "~\\Areas\\BaseData\\Uploads\\Certification\\";
            }
        }

        /// <summary>
        /// 产品认证文件保存目录绝对路径
        /// </summary>
        public static string UploadProductCertificationFileAbsolutePath
        {
            get
            {
                return FileHelper.MapPath(UploadProductCertificationFilePath);
            }
        }
        /// <summary>
        /// 转TXT分割文件保存路径
        /// </summary>
        public static string TurnTXTSplitTableFilePath
        {
            get
            {
                return "~\\Areas\\BusinessManagement\\TurnTXTSplitTableTemp\\" + OperatorProvider.Provider.GetCurrent().RealName + "\\";
            }
        }

        /// <summary>
        /// 转TXT分割文件保存目录绝对路径
        /// </summary>
        public static string TurnTXTSplitTableFileAbsolutePath
        {
            get
            {
                return FileHelper.MapPath(TurnTXTSplitTableFilePath);
            }
        }

        #region txt to csv
        /// <summary>
        /// 表格拼接文件保存路径
        /// </summary>
        public static string UploadTxtToCsvFilePath
        {
            get
            {
                return "~\\Areas\\BusinessManagement\\TxtToCsvFile\\";
            }
        }

        /// <summary>
        /// 表格拼接文件保存目录绝对路径
        /// </summary>
        public static string UploadTxtToCsvAbsolutePath
        {
            get
            {
                return FileHelper.MapPath(UploadTxtToCsvFilePath);
            }
        }
        #endregion
    }
}
