﻿
using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace P2.Infrastructure.Excel
{
    public class CSVHelper
    {
        #region 通过oledb方式从csv文件里读取数据
        public static DataSet CSVToDataSet(string path, string name)
        {

            if (string.IsNullOrWhiteSpace(path) || string.IsNullOrWhiteSpace(name) || !File.Exists(path + name))
                return null;

            // 读取excel 
            string connstring = string.Empty;
            string strSql = string.Empty;
            if (name.EndsWith(".csv"))
            {
                connstring = "Provider=Microsoft.ACE.OLEDB.4.0;Data Source=" + path + ";Extended Properties='text;HDR=YES;FMT=Delimited';";
                strSql = "select * from " + name;
            }
            else
            {
                return null;
            }
            DataSet ds = null;
            OleDbConnection conn = null;
            try
            {
                conn = new OleDbConnection(connstring);
                conn.Open();
                OleDbDataAdapter myCommand = null;

                myCommand = new OleDbDataAdapter(strSql, connstring);
                ds = new DataSet();
                myCommand.Fill(ds, "table1");
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                conn.Close();
            }
            return ds;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pathname">目录</param>
        /// <param name="fileName">文件名包含后缀</param>
        /// <param name="isUTF">是否utf-8</param>
        /// <returns></returns>
        public static DataTable GetDataTableCSV(string pathname, string fileName, string characterSet = "65001")
        {
            string strConn;
            DataTable dt = new DataTable();
            try
            {
                string strCharacterSet = "";
                if (!string.IsNullOrEmpty(characterSet))
                {
                    ChangeEncoding(pathname + fileName);
                    strCharacterSet = "CharacterSet=" + characterSet + ";";
                }
                //text指的是文本文件
                //HDR=Yes的意思文件中带有标题行
                //FMT=Delimited的意思是自定义分隔符 
                strConn = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathname + ";Extended Properties='Text;HDR=Yes;FMT=Delimited;IMEX=1;MaxScanRows=19;" + strCharacterSet + "';";
                using (OleDbConnection conn = new OleDbConnection(strConn))
                {
                    conn.Open();
                    OleDbDataAdapter myCommand = new OleDbDataAdapter("SELECT * FROM [" + fileName + "]", strConn);
                    myCommand.Fill(dt);
                    conn.Close();
                }
                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
            }
        }

        public static void ChangeEncoding(string fullFileName)
        {
            //以UTF-8带BOM格式读取文件内容
            Encoding end = new UTF8Encoding(true);
            string str = string.Empty;
            using (StreamReader sr = new StreamReader(fullFileName, end))
            {
                str = sr.ReadToEnd();
            }
            //以UTF-8不带BOM格式重新写入文件
            end = new UTF8Encoding(false);
            using (StreamWriter sw = new StreamWriter(fullFileName, false, end))
            {
                sw.Write(str);
            }
        }
        #endregion

        #region 普通方式读取CSV文件
        /// <summary>
        /// 打开CSV 文件
        /// </summary>
        /// <param name="fileName">文件全名</param>
        /// <param name="firstRow">开始行</param>
        /// <param name="firstColumn">开始列</param>
        /// <param name="getRows">获取多少行</param>
        /// <param name="getColumns">获取多少列</param>
        /// <param name="haveTitleRow">是有标题行</param>
        /// <returns>DataTable</returns>
        public static DataTable CSVToDataTable(string fullFileName, Int16 firstRow = 0, Int16 firstColumn = 0, Int16 getRows = 0, Int16 getColumns = 0, bool haveTitleRow = true)
        {
            DataTable dt = new DataTable();
            FileStream fs = new FileStream(fullFileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            Encoding encoding = GetType(fullFileName);
            StreamReader sr = new StreamReader(fs, encoding);
            //记录每次读取的一行记录
            string strLine = "";
            //记录每行记录中的各字段内容
            string[] aryLine;
            //标示列数
            int columnCount = 0;
            //是否已建立了表的字段
            bool bCreateTableColumns = false;
            //第几行
            int iRow = 1;

            //去除无用行
            if (firstRow > 0)
            {
                for (int i = 1; i < firstRow; i++)
                {
                    sr.ReadLine();
                }
            }

            string[] separators = { "," };
            //逐行读取CSV中的数据
            while ((strLine = sr.ReadLine()) != null)
            {
                strLine = strLine.Trim();
                //aryLine = strLine.Split(separators, System.StringSplitOptions.None);
                if (strLine.StartsWith("\""))
                {
                    strLine = "\"\"," + strLine;
                }
                MatchCollection col = Regex.Matches(strLine, "(?<=^|,)[^\"]*?(?=,|$)|(?<=^|,\")(?:(\"\")?[^\"]*?)*(?=\",?|$)", RegexOptions.ExplicitCapture);
                IEnumerator ie = col.GetEnumerator();
                int arrCount = col.Count;
                if (strLine.StartsWith("\""))
                {
                    arrCount = col.Count - 1;
                }
                aryLine = new string[arrCount];
                bool isFistColumn = true;
                int curIndex = 0;
                while (ie.MoveNext())
                {
                    if (strLine.StartsWith("\""))
                    {
                        if (isFistColumn)
                        {
                            isFistColumn = false;
                            continue;
                        }
                    }

                    if (ie.Current.ToString() == "," && aryLine[curIndex - 1].EndsWith("\","))
                    {
                        aryLine[curIndex - 1] = aryLine[curIndex - 1].Substring(0, aryLine[curIndex - 1].Length - 2) + ",";
                        continue;
                    }

                    aryLine[curIndex] = ie.Current.ToString();
                    curIndex++;
                }

                if (bCreateTableColumns == false)
                {
                    bCreateTableColumns = true;
                    columnCount = aryLine.Length;
                    //创建列
                    for (int i = firstColumn; i < (getColumns == 0 ? columnCount : firstColumn + getColumns); i++)
                    {
                        DataColumn dc
                            = new DataColumn(haveTitleRow == true ? aryLine[i] : "COL" + i.ToString());
                        dt.Columns.Add(dc);
                    }

                    bCreateTableColumns = true;

                    if (haveTitleRow == true)
                    {
                        continue;
                    }
                }


                DataRow dr = dt.NewRow();
                for (int j = firstColumn; j < dt.Columns.Count; j++)
                {
                    dr[j - firstColumn] = aryLine[j];
                }
                dt.Rows.Add(dr);

                iRow = iRow + 1;
                if (getRows > 0)
                {
                    if (iRow > getRows)
                    {
                        break;
                    }
                }

            }

            sr.Close();
            fs.Close();
            return dt;
        }

        /// 给定文件的路径，读取文件的二进制数据，判断文件的编码类型
        /// <param name="FILE_NAME">文件路径</param>
        /// <returns>文件的编码类型</returns>
        public static System.Text.Encoding GetType(string FILE_NAME)
        {
            System.IO.FileStream fs = new System.IO.FileStream(FILE_NAME, System.IO.FileMode.Open,
                System.IO.FileAccess.Read);
            System.Text.Encoding r = GetType(fs);
            fs.Close();
            return r;
        }

        /// 通过给定的文件流，判断文件的编码类型
        /// <param name="fs">文件流</param>
        /// <returns>文件的编码类型</returns>
        public static System.Text.Encoding GetType(System.IO.FileStream fs)
        {
            byte[] Unicode = new byte[] { 0xFF, 0xFE, 0x41 };
            byte[] UnicodeBIG = new byte[] { 0xFE, 0xFF, 0x00 };
            byte[] UTF8 = new byte[] { 0xEF, 0xBB, 0xBF }; //带BOM
            System.Text.Encoding reVal = System.Text.Encoding.Default;

            System.IO.BinaryReader r = new System.IO.BinaryReader(fs, System.Text.Encoding.Default);
            int i;
            int.TryParse(fs.Length.ToString(), out i);
            byte[] ss = r.ReadBytes(i);
            if (IsUTF8Bytes(ss) || (ss[0] == 0xEF && ss[1] == 0xBB && ss[2] == 0xBF))
            {
                reVal = System.Text.Encoding.UTF8;
            }
            else if (ss[0] == 0xFE && ss[1] == 0xFF && ss[2] == 0x00)
            {
                reVal = System.Text.Encoding.BigEndianUnicode;
            }
            else if (ss[0] == 0xFF && ss[1] == 0xFE && ss[2] == 0x41)
            {
                reVal = System.Text.Encoding.Unicode;
            }
            r.Close();
            return reVal;
        }

        /// 判断是否是不带 BOM 的 UTF8 格式
        /// <param name="data"></param>
        /// <returns></returns>
        private static bool IsUTF8Bytes(byte[] data)
        {
            int charByteCounter = 1;　 //计算当前正分析的字符应还有的字节数
            byte curByte; //当前分析的字节.
            for (int i = 0; i < data.Length; i++)
            {
                curByte = data[i];
                if (charByteCounter == 1)
                {
                    if (curByte >= 0x80)
                    {
                        //判断当前
                        while (((curByte <<= 1) & 0x80) != 0)
                        {
                            charByteCounter++;
                        }
                        //标记位首位若为非0 则至少以2个1开始 如:110XXXXX...........1111110X　
                        if (charByteCounter == 1 || charByteCounter > 6)
                        {
                            return false;
                        }
                    }
                }
                else
                {
                    //若是UTF-8 此时第一位必须为1
                    if ((curByte & 0xC0) != 0x80)
                    {
                        return false;
                    }
                    charByteCounter--;
                }
            }
            if (charByteCounter > 1)
            {
                throw new Exception("非预期的byte格式");
            }
            return true;
        }

        #endregion
    }
}
