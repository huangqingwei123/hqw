﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Reflection;
using System.ComponentModel;
using P2.Infrastructure.Extensions;
using System.Text;

namespace P2.Infrastructure.Excel
{
    public class NPOIExcel
    {
        private string _title;
        private string _sheetName;
        private string _filePath;

        public NPOIExcel()
        {

        }

        public NPOIExcel(string title, string sheetName, string filePath)
        {
            this._title = title;
            this._sheetName = sheetName;
            this._filePath = filePath;
        }

        /// <summary>
        /// 导出到Excel
        /// </summary>
        /// <typeparam name="T">泛型</typeparam>
        /// <param name="dataList">数据集</param>
        /// <param name="showTitle">设置True时显示标题,默认为False</param>
        /// <param name="isAlloSkip">将属性设为跳过的移除掉，属于为：Custom(true)</param>
        /// <param name="showTableTitle">是否显示列名，默认是显示列名</param>
        /// <returns></returns>
        public bool ToExcel<T>(List<T> dataList, bool showTitle = false, bool isAlloSkip = false, bool showTableTitle = true)
        {
            FileStream fs = new FileStream(this._filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            IWorkbook workBook = null;
            // 2007版本
            if (_filePath.IndexOf(".xlsx") > 0)
                workBook = new XSSFWorkbook();
            // 2003版本
            else if (_filePath.IndexOf(".xls") > 0)
                workBook = new HSSFWorkbook();
            //IWorkbook workBook = new HSSFWorkbook();
            //IWorkbook workBook = new XSSFWorkbook();
            this._sheetName = this._sheetName.IsEmpty() ? "sheet1" : this._sheetName;
            ISheet sheet = workBook.CreateSheet(this._sheetName);
            Type type = typeof(T);
            PropertyInfo[] propertys = type.GetProperties();
            //将属性设为跳过的移除掉
            if (isAlloSkip)
            {
                List<PropertyInfo> propertyList = new List<PropertyInfo>();
                foreach (PropertyInfo pi in propertys)
                {
                    bool IsSkip = false;
                    var cusAttrs = pi.GetCustomAttributes(typeof(CustomAttribute), false);
                    if (cusAttrs.Length > 0)
                    {
                        foreach (CustomAttribute record in cusAttrs)
                        {
                            IsSkip = record.IsSkip;
                        }
                        if (IsSkip)
                        {
                            continue;
                        }
                    }

                    propertyList.Add(pi);
                }
                propertys = propertyList.ToArray();
            }
            int pisLen = propertys.Length;
            int rowIndex = 0;
            int piIndex = 0;
            IRow row;

            #region 处理表格标题=======================

            if (showTitle)
            {
                if (String.IsNullOrEmpty(this._title)) throw new Exception("报表的标题不能为空！");
                row = sheet.CreateRow(0);
                rowIndex++;//创建完行后累加
                row.CreateCell(0).SetCellValue(this._title);
                sheet.AddMergedRegion(new CellRangeAddress(0, 0, 0, pisLen - 1));
                row.Height = 500;

                ICellStyle cellStyle = workBook.CreateCellStyle();
                IFont font = workBook.CreateFont();
                font.FontName = "微软雅黑";
                font.FontHeightInPoints = 17;
                cellStyle.SetFont(font);
                cellStyle.VerticalAlignment = VerticalAlignment.Center;
                cellStyle.Alignment = HorizontalAlignment.Center;
                row.Cells[0].CellStyle = cellStyle;
            }
            #endregion

            if (showTableTitle)
            {
                //处理表格列头
                row = sheet.CreateRow(rowIndex);
                rowIndex++;//创建完行后累加

                foreach (PropertyInfo pi in propertys)
                {
                    string heardName = pi.Name;//默认是属性名
                    var decAttrs = pi.GetCustomAttributes(typeof(DescriptionAttribute), false);//描述
                    if (decAttrs.Length > 0)//优先取属性描述
                    {
                        foreach (DescriptionAttribute record in decAttrs)
                        {
                            heardName = record.Description;
                        }
                    }
                    row.CreateCell(piIndex).SetCellValue(heardName);
                    row.Height = 350;
                    sheet.AutoSizeColumn(piIndex);
                    piIndex++;
                }
                sheet.CreateFreezePane(0, rowIndex, 0, rowIndex);//冻结列头行
            }

            //处理数据内容
            foreach (var data in dataList)
            {
                piIndex = 0;
                row = sheet.CreateRow(rowIndex);
                rowIndex++;//创建完行后累加
                row.Height = 250;
                foreach (PropertyInfo pi in propertys)
                {
                    try
                    {
                        row.CreateCell(piIndex).SetCellValue(pi.GetValue(data, null).ToString());
                    }
                    catch (Exception)
                    {
                        row.CreateCell(piIndex).SetCellValue("");
                    }
                    sheet.SetColumnWidth(piIndex, 256 * 15);
                    piIndex++;
                }
            }

            //写入数据流
            workBook.Write(fs);
            //fs.Flush();
            fs.Close();

            return true;
        }

        /// <summary>
        /// 导出到Excel
        /// 主要处理需要合并单元格的表头
        /// 先复制多行相同的单元格
        /// 然后按用户传进来的处理逻辑处理相关合并的操作
        /// </summary>
        /// <typeparam name="T">泛型</typeparam>
        /// <param name="dataList">待导出的数据</param>
        /// <param name="rowSpan">表头行数</param>
        /// <param name="dealWithFun">处理合并单元格等操作的逻辑，无返回值</param>
        /// <param name="showTitle">是否显示标题</param>
        /// <param name="isAlloSkip">是否跳过相关已标记元素</param>
        /// <returns></returns>
        public bool ToExcel<T>(List<T> dataList, int rowSpan, Action<ISheet> dealWithFun, bool showTitle = false, bool isAlloSkip = false)
        {
            FileStream fs = new FileStream(this._filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            IWorkbook workBook = new HSSFWorkbook();
            this._sheetName = this._sheetName.IsEmpty() ? "sheet1" : this._sheetName;
            ISheet sheet = workBook.CreateSheet(this._sheetName);
            ICellStyle centerStyle = workBook.CreateCellStyle();
            centerStyle.Alignment = HorizontalAlignment.Center;//设置单元格的样式：水平对齐居中

            int rowIndex = 0;
            int piIndex = 0;
            int tempVariable = 0;//临时变量，使用前重置
            Type type = typeof(T);
            PropertyInfo[] propertys = type.GetProperties();
            int pisLen = propertys.Length;//列元素个数
            IRow row;

            //将属性设为跳过的移除掉
            if (isAlloSkip)
            {
                List<PropertyInfo> propertyList = new List<PropertyInfo>();
                foreach (PropertyInfo pi in propertys)
                {
                    bool IsSkip = false;
                    var cusAttrs = pi.GetCustomAttributes(typeof(CustomAttribute), false);
                    if (cusAttrs.Length > 0)
                    {
                        foreach (CustomAttribute record in cusAttrs)
                        {
                            IsSkip = record.IsSkip;
                        }
                        if (IsSkip)
                        {
                            continue;
                        }
                    }

                    propertyList.Add(pi);
                }
                propertys = propertyList.ToArray();
            }

            #region 处理表格标题=======================

            if (showTitle)
            {
                if (String.IsNullOrEmpty(this._title)) throw new Exception("报表的标题不能为空！");
                row = sheet.CreateRow(0);
                rowIndex++;//创建完行后累加
                row.CreateCell(0).SetCellValue(this._title);
                sheet.AddMergedRegion(new CellRangeAddress(0, 0, 0, pisLen - 1));
                row.Height = 500;

                ICellStyle cellStyle = workBook.CreateCellStyle();
                IFont font = workBook.CreateFont();
                font.FontName = "微软雅黑";
                font.FontHeightInPoints = 17;
                cellStyle.SetFont(font);
                cellStyle.VerticalAlignment = VerticalAlignment.Center;
                cellStyle.Alignment = HorizontalAlignment.Center;
                row.Cells[0].CellStyle = cellStyle;
            }
            #endregion

            tempVariable = 0;
            while (tempVariable < rowSpan)
            {
                piIndex = 0;
                row = sheet.CreateRow(rowIndex);
                rowIndex++;//创建完行后累加
                sheet.CreateFreezePane(0, rowIndex, 0, rowIndex);//冻结列头行
                foreach (PropertyInfo pi in propertys)
                {
                    string heardName = pi.Name;
                    var decAttrs = pi.GetCustomAttributes(typeof(DescriptionAttribute), false);
                    if (decAttrs.Length > 0)
                    {
                        foreach (DescriptionAttribute record in decAttrs)
                        {
                            heardName = record.Description;
                        }
                    }
                    row.CreateCell(piIndex).SetCellValue(heardName);
                    row.Cells[piIndex].CellStyle = centerStyle;
                    row.Height = 350;
                    sheet.AutoSizeColumn(piIndex);
                    piIndex++;
                }
                tempVariable++;
            };

            if (dealWithFun != null) dealWithFun(sheet);//合并逻辑

            //处理数据内容
            foreach (var data in dataList)
            {
                piIndex = 0;
                row = sheet.CreateRow(rowIndex);
                rowIndex++;//创建完行后累加
                row.Height = 250;
                foreach (PropertyInfo pi in propertys)
                {
                    try
                    {
                        row.CreateCell(piIndex).SetCellValue(pi.GetValue(data, null).ToString());
                    }
                    catch (Exception)
                    {
                        row.CreateCell(piIndex).SetCellValue("");
                    }
                    sheet.SetColumnWidth(piIndex, 256 * 15);
                    piIndex++;
                }
            }

            //写入数据流
            workBook.Write(fs);
            fs.Flush();
            fs.Close();
            return true;
        }

        #region DataTable转Excel

        /// <summary>
        /// 导出到Excel
        /// </summary>
        /// <typeparam name="T">泛型</typeparam>
        /// <param name="dataTable">数据集</param>
        /// <param name="showTitle">设置True时显示标题,默认为False</param>
        /// <param name="isAlloSkip">将属性设为跳过的移除掉，属于为：Custom(true)</param>
        /// <param name="showTableTitle">是否显示列名，默认是显示列名</param>
        /// <returns></returns>
        public bool ToExcel(DataTable dataTable, bool showTitle = false, bool showTableTitle = true)
        {
            FileStream fs = new FileStream(this._filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
            IWorkbook workBook = null;
            // 2007版本
            if (_filePath.IndexOf(".xlsx") > 0)
                workBook = new XSSFWorkbook();
            // 2003版本
            else if (_filePath.IndexOf(".xls") > 0)
                workBook = new HSSFWorkbook();
            
            this._sheetName = this._sheetName.IsEmpty() ? "sheet1" : this._sheetName;
            ISheet sheet = workBook.CreateSheet(this._sheetName);
            int pisLen = dataTable.Columns.Count;
            int rowIndex = 0;
            int piIndex = 0;
            IRow row;

            #region 处理表格标题=======================

            if (showTitle)
            {
                if (String.IsNullOrEmpty(this._title)) throw new Exception("报表的标题不能为空！");
                row = sheet.CreateRow(0);
                rowIndex++;//创建完行后累加
                row.CreateCell(0).SetCellValue(this._title);
                sheet.AddMergedRegion(new CellRangeAddress(0, 0, 0, pisLen - 1));
                row.Height = 500;

                ICellStyle cellStyle = workBook.CreateCellStyle();
                IFont font = workBook.CreateFont();
                font.FontName = "微软雅黑";
                font.FontHeightInPoints = 17;
                cellStyle.SetFont(font);
                cellStyle.VerticalAlignment = VerticalAlignment.Center;
                cellStyle.Alignment = HorizontalAlignment.Center;
                row.Cells[0].CellStyle = cellStyle;
            }
            #endregion

            if (showTableTitle)
            {
                //处理表格列头
                row = sheet.CreateRow(rowIndex);
                rowIndex++;//创建完行后累加

                foreach (var pi in dataTable.Columns)
                {                    
                    row.CreateCell(piIndex).SetCellValue(pi.ToString());
                    row.Height = 350;
                    sheet.AutoSizeColumn(piIndex);
                    piIndex++;
                }
                sheet.CreateFreezePane(0, rowIndex, 0, rowIndex);//冻结列头行
            }
            //处理数据内容
            foreach (DataRow dataRow in dataTable.Rows)
            {
                piIndex = 0;
                row = sheet.CreateRow(rowIndex);
                rowIndex++;//创建完行后累加
                row.Height = 250;
                foreach (var pi in dataTable.Columns)
                {
                    try
                    {
                        row.CreateCell(piIndex).SetCellValue(dataRow[pi.ToString()].ToString());
                    }
                    catch (Exception)
                    {
                        row.CreateCell(piIndex).SetCellValue("");
                    }
                    sheet.SetColumnWidth(piIndex, 256 * 15);
                    piIndex++;
                }
            }
            //写入数据流
            workBook.Write(fs);
            //fs.Flush();
            fs.Close();
            return true;
        }
        #endregion

        #region excel to datatable
        /// <summary>
        /// 将excel导入到datatable
        /// </summary>
        /// <param name="filePath">excel路径</param>
        /// <param name="isColumnName">第一行是否是列名</param>
        /// <returns>返回datatable</returns>
        public static DataTable ExcelToDataTable(string filePath, bool isColumnName, bool isGetActiveSheet = false)
        {
            DataTable dataTable = null;
            FileStream fs = null;
            DataColumn column = null;
            DataRow dataRow = null;
            IWorkbook workbook = null;
            ISheet sheet = null;
            IRow row = null;
            ICell cell = null;
            int startRow = 0;
            try
            {
                using (fs = File.OpenRead(filePath))
                {
                    // 2007版本
                    if (filePath.IndexOf(".xlsx") > 0)
                        workbook = new XSSFWorkbook(fs);
                    // 2003版本
                    else if (filePath.IndexOf(".xls") > 0)
                        workbook = new HSSFWorkbook(fs);

                    if (workbook != null)
                    {
                        int sheetIndex = 0;
                        if (isGetActiveSheet)
                        {
                            sheetIndex = workbook.ActiveSheetIndex;
                        }
                        sheet = workbook.GetSheetAt(sheetIndex);//读取第一个sheet，当然也可以循环读取每个sheet
                        dataTable = new DataTable();
                        if (sheet != null)
                        {
                            int rowCount = sheet.PhysicalNumberOfRows;//总行数
                            if (rowCount > 0)
                            {
                                IRow firstRow = sheet.GetRow(0);//第一行
                                int cellCount = firstRow.LastCellNum;//列数

                                //构建datatable的列
                                if (isColumnName)
                                {
                                    startRow = 1;//如果第一行是列名，则从第二行开始读取
                                    for (int i = firstRow.FirstCellNum; i < cellCount; ++i)
                                    {
                                        cell = firstRow.GetCell(i);
                                        if (cell != null)
                                        {
                                            if (cell.StringCellValue != null)
                                            {
                                                column = new DataColumn(cell.StringCellValue.Trim(' '));
                                                dataTable.Columns.Add(column);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    for (int i = firstRow.FirstCellNum; i < cellCount; ++i)
                                    {
                                        column = new DataColumn("column" + (i + 1));
                                        dataTable.Columns.Add(column);
                                    }
                                }

                                //填充行
                                for (int i = startRow; i <= rowCount; ++i)
                                {
                                    row = sheet.GetRow(i);
                                    if (row == null || row.FirstCellNum <= -1) continue;

                                    dataRow = dataTable.NewRow();
                                    for (int j = row.FirstCellNum; j < cellCount; ++j)
                                    {
                                        cell = row.GetCell(j);
                                        if (cell == null)
                                        {
                                            dataRow[j] = "";
                                        }
                                        else
                                        {
                                            //CellType(Unknown = -1,Numeric = 0,String = 1,Formula = 2,Blank = 3,Boolean = 4,Error = 5,)
                                            switch (cell.CellType)
                                            {
                                                case CellType.Blank:
                                                    dataRow[j] = "";
                                                    break;
                                                case CellType.Numeric:
                                                    short format = cell.CellStyle.DataFormat;
                                                    //对时间格式（2015.12.5、2015/12/5、2015-12-5等）的处理
                                                    //if (format == 14 || format == 31 || format == 57 || format == 58)
                                                    if (DateUtil.IsCellDateFormatted(cell))
                                                        dataRow[j] = cell.DateCellValue;
                                                    else
                                                        dataRow[j] = cell.NumericCellValue;
                                                    break;
                                                case CellType.String:
                                                    dataRow[j] = cell.StringCellValue;
                                                    break;
                                                case CellType.Formula:
                                                    try
                                                    {
                                                        var evaluator = new HSSFFormulaEvaluator(workbook);
                                                        cell = evaluator.EvaluateInCell(cell);
                                                        if (cell.CellType == CellType.Numeric)
                                                        {
                                                            if (DateUtil.IsCellDateFormatted(cell))
                                                                dataRow[j] = cell.DateCellValue;
                                                            else
                                                                dataRow[j] = cell.NumericCellValue;
                                                        }
                                                        if (cell.CellType == CellType.Numeric)
                                                        {
                                                            dataRow[j] = cell.StringCellValue;
                                                        }
                                                        if (cell.CellType == CellType.Blank)
                                                        {
                                                            dataRow[j] = "";
                                                        }
                                                    }
                                                    catch
                                                    {
                                                    }
                                                    break;
                                            }
                                        }
                                    }
                                    dataTable.Rows.Add(dataRow);
                                }
                            }
                        }
                    }
                }
                return dataTable;
            }
            catch (Exception)
            {
                if (fs != null)
                {
                    fs.Close();
                }
                return null;
            }
        }

        /// 将excel导入到datatable
        /// </summary>
        /// <param name="filePath">excel路径</param>
        /// <param name="isColumnName">第一行是否是列名</param>
        /// <param name="startRowIndex"></param>
        /// <param name="endRowIndex"></param>
        /// <param name="startCellIndex"></param>
        /// <param name="endCellIndex"></param>
        /// <returns></returns>
        public static DataTable ExcelToDataTable(string filePath, bool isColumnName, int startRowIndex, int endRowIndex, int startCellIndex, int endCellIndex)
        {
            DataTable dataTable = null;
            FileStream fs = null;
            DataColumn column = null;
            DataRow dataRow = null;
            IWorkbook workbook = null;
            ISheet sheet = null;
            IRow row = null;
            ICell cell = null;
            int startRow = 0;
            try
            {
                using (fs = File.OpenRead(filePath))
                {
                    // 2007版本
                    if (filePath.IndexOf(".xlsx") > 0)
                        workbook = new XSSFWorkbook(fs);
                    // 2003版本
                    else if (filePath.IndexOf(".xls") > 0)
                        workbook = new HSSFWorkbook(fs);

                    if (workbook != null)
                    {
                        sheet = workbook.GetSheetAt(0);//读取第一个sheet，当然也可以循环读取每个sheet
                        dataTable = new DataTable();
                        if (sheet != null)
                        {
                            int rowCount = endRowIndex - (startRowIndex - 1);//总行数
                            if (rowCount > 0)
                            {
                                IRow firstRow = sheet.GetRow(startRowIndex);//第一行
                                int cellCount = endCellIndex - (startCellIndex - 1);//列数

                                //构建datatable的列
                                if (isColumnName)
                                {
                                    startRow = startRowIndex;//如果第一行是列名，则从第二行开始读取
                                    for (int i = startCellIndex; i < cellCount; ++i)
                                    {
                                        cell = firstRow.GetCell(i);
                                        if (cell != null)
                                        {
                                            if (cell.StringCellValue != null)
                                            {
                                                column = new DataColumn(cell.StringCellValue);
                                                dataTable.Columns.Add(column);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    for (int i = startCellIndex; i < cellCount; ++i)
                                    {
                                        column = new DataColumn("column" + (i + 1));
                                        dataTable.Columns.Add(column);
                                    }
                                }

                                //填充行
                                for (int i = startRow; i <= rowCount; ++i)
                                {
                                    row = sheet.GetRow(i);
                                    if (row == null || row.FirstCellNum <= -1) continue;

                                    dataRow = dataTable.NewRow();
                                    for (int j = row.FirstCellNum; j < cellCount; ++j)
                                    {
                                        cell = row.GetCell(j);
                                        if (cell == null)
                                        {
                                            dataRow[j] = "";
                                        }
                                        else
                                        {
                                            //CellType(Unknown = -1,Numeric = 0,String = 1,Formula = 2,Blank = 3,Boolean = 4,Error = 5,)
                                            switch (cell.CellType)
                                            {
                                                case CellType.Blank:
                                                    dataRow[j] = "";
                                                    break;
                                                case CellType.Numeric:
                                                    short format = cell.CellStyle.DataFormat;
                                                    //对时间格式（2015.12.5、2015/12/5、2015-12-5等）的处理
                                                    //if (format == 14 || format == 31 || format == 57 || format == 58)
                                                    if (DateUtil.IsCellDateFormatted(cell))
                                                        dataRow[j] = cell.DateCellValue;
                                                    else
                                                        dataRow[j] = cell.NumericCellValue;
                                                    break;
                                                case CellType.String:
                                                    dataRow[j] = cell.StringCellValue;
                                                    break;
                                                case CellType.Formula:
                                                    try
                                                    {
                                                        var evaluator = new HSSFFormulaEvaluator(workbook);
                                                        cell = evaluator.EvaluateInCell(cell);
                                                        if (cell.CellType == CellType.Numeric)
                                                        {
                                                            if (DateUtil.IsCellDateFormatted(cell))
                                                                dataRow[j] = cell.DateCellValue;
                                                            else
                                                                dataRow[j] = cell.NumericCellValue;
                                                        }
                                                        if (cell.CellType == CellType.Numeric)
                                                        {
                                                            dataRow[j] = cell.StringCellValue;
                                                        }
                                                        if (cell.CellType == CellType.Blank)
                                                        {
                                                            dataRow[j] = "";
                                                        }
                                                    }
                                                    catch
                                                    {
                                                    }
                                                    break;
                                            }
                                        }
                                    }
                                    dataTable.Rows.Add(dataRow);
                                }
                            }
                        }
                    }
                }
                return dataTable;
            }
            catch (Exception)
            {
                if (fs != null)
                {
                    fs.Close();
                }
                return null;
            }
        }
        #endregion

        #region 将DataTable中数据写入到CSV文件中
        /// <summary>
        /// 将DataTable中数据写入到CSV文件中
        /// </summary>
        /// <param name="dt">提供保存数据的DataTable</param>
        /// <param name="fileName">CSV的文件路径</param>
        public bool SaveCSV(DataTable dt, string fileName)
        {
            Encoding utf8 = new UTF8Encoding(false);
            FileStream fs = new FileStream(fileName, System.IO.FileMode.Create, System.IO.FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs, utf8);

            string data = "";
            string strTemp = "";
            //写出列名称
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                data += dt.Columns[i].ColumnName.ToString().Trim();
                if (i < dt.Columns.Count - 1)
                {
                    data += ",";
                }
            }
            sw.WriteLine(data);

            //写出各行数据
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                data = "";
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    strTemp = dt.Rows[i][j].ToString().Replace(",", "，");
                    //特殊字符引号处理
                    if (strTemp.IndexOf("\"") != -1 || strTemp.IndexOf(",") != -1)
                    {
                        strTemp = "\"" + strTemp.Replace("\"", "\"\"") + "\"";
                    }
                    data += strTemp.Trim();
                    if (j < dt.Columns.Count - 1)
                    {
                        data += ",";
                    }
                }
                sw.WriteLine(data);
            }

            sw.Close();
            fs.Close();
            return true;
        }
        #endregion

        #region csv to datatable
        /// <summary>
        /// 打开CSV 文件
        /// </summary>
        /// <param name="fileName">文件全名</param>
        /// <param name="firstRow">开始行</param>
        /// <param name="firstColumn">开始列</param>
        /// <param name="getRows">获取多少行</param>
        /// <param name="getColumns">获取多少列</param>
        /// <param name="haveTitleRow">是有标题行</param>
        /// <returns>DataTable</returns>
        public static DataTable CSVToDataTable(string fullFileName, Int16 firstRow = 0, Int16 firstColumn = 0, Int16 getRows = 0, Int16 getColumns = 0, bool haveTitleRow = true)
        {
            DataTable dt = new DataTable();
            FileStream fs = new FileStream(fullFileName, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            StreamReader sr = new StreamReader(fs, System.Text.Encoding.Default);
            //记录每次读取的一行记录
            string strLine = "";
            //记录每行记录中的各字段内容
            string[] aryLine;
            //标示列数
            int columnCount = 0;
            //是否已建立了表的字段
            bool bCreateTableColumns = false;
            //第几行
            int iRow = 1;

            //去除无用行
            if (firstRow > 0)
            {
                for (int i = 1; i < firstRow; i++)
                {
                    sr.ReadLine();
                }
            }

            string[] separators = { "," };
            //逐行读取CSV中的数据
            while ((strLine = sr.ReadLine()) != null)
            {
                strLine = strLine.Trim();
                aryLine = strLine.Split(separators, System.StringSplitOptions.None);

                if (bCreateTableColumns == false)
                {
                    bCreateTableColumns = true;
                    columnCount = aryLine.Length;
                    //创建列
                    for (int i = firstColumn; i < (getColumns == 0 ? columnCount : firstColumn + getColumns); i++)
                    {
                        DataColumn dc
                            = new DataColumn(haveTitleRow == true ? aryLine[i] : "COL" + i.ToString());
                        dt.Columns.Add(dc);
                    }

                    bCreateTableColumns = true;

                    if (haveTitleRow == true)
                    {
                        continue;
                    }
                }


                DataRow dr = dt.NewRow();
                for (int j = firstColumn; j < aryLine.Length; j++)
                {
                    dr[j - firstColumn] = aryLine[j];
                }
                dt.Rows.Add(dr);

                iRow = iRow + 1;
                if (getRows > 0)
                {
                    if (iRow > getRows)
                    {
                        break;
                    }
                }

            }

            sr.Close();
            fs.Close();
            return dt;
        }
        #endregion

    }

}
