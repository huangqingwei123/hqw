﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure
{
    /// <summary>
    /// 公共查询参数
    /// </summary>
    public class BaseQueryDto
    {
        /// <summary>
        /// 分页参数
        /// </summary>
        public Pagination Pagination { get; set; }
        /// <summary>
        /// 不分页
        /// </summary>
        public bool IsGetAll { get; set; }
        /// <summary>
        /// 关键词
        /// </summary>
        public string Keyword { get; set; }
        /// <summary>
        /// 开始时间
        /// </summary>
        public DateTime StartTime { get; set; }
        /// <summary>
        /// 结束时间
        /// </summary>
        public DateTime EndTime { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int Status { get; set; }
        /// <summary>
        /// 时间
        /// </summary>
        public int TimeType { get; set; }
        /// <summary>
        /// 部门ID
        /// </summary>
        public string DepartmentId { get; set; }
        /// <summary>
        /// 币种
        /// </summary>
        public string Currency { get; set; }
        public string OrderNumber { get; set; }
        public string SellerId { get; set; }
        public string Sku { get; set; }
        public string Fnsku { get; set; }
        public string Asin { get; set; }
        public string ContryAccount { get; set; }
        public string SellerType { get; set; }
        public int Type { get; set; }
    }
}
