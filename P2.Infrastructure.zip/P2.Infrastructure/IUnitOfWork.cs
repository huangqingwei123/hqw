﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Infrastructure
{
    /// <summary>
    /// 工作单元基类接口
    /// </summary>
    public interface IUnitOfWork
    {
        //bool IsCommitted { get; set; }
        ///// <summary>
        ///// 提交当前 Unit of Work的事务
        ///// </summary>
        ///// <returns></returns>
        bool Commit();
        ///// <summary>
        ///// 回滚当前Unit Of Work事务
        ///// </summary>
        //void RollBack();
    }
}
