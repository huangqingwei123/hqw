﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using P2.Infrastructure.Extensions;

namespace P2.Infrastructure
{
    public class DateConverter : DateTimeConverterBase
    {
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (reader.TokenType != JsonToken.Integer)
            {
                throw new Exception(String.Format("日期格式错误,got {0}.", reader.TokenType));
            }
            var ticks = reader.Value;
            var date = ticks.CastTo<DateTime>();
            return date;
        }
        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            string result;
            if (value is DateTime)
            {
                result = ((DateTime)value).ToString("yyyy-MM-dd");
            }
            else
            {
                throw new Exception("时间格式错误.2");
            }
            writer.WriteValue(result);
        }
    }
}
