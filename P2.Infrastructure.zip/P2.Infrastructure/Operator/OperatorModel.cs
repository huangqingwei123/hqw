﻿using System;
using System.Collections.Generic;

namespace P2.Infrastructure
{
    public class OperatorModel
    {
        /// <summary>
        /// 用户主键
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 用户编号
        /// </summary>
        public string Account { get; set; }
        /// <summary>
        /// 用户名称
        /// </summary>
        public string RealName { get; set; }
        /// <summary>
        /// 部门ID
        /// </summary>
        public string DepartmentId { get; set; }
        /// <summary>
        /// 部门名称
        /// </summary>
        public string DepartmentName { get; set; }
        /// <summary>
        /// 角色ID
        /// </summary>
        public string RoleId { get; set; }
        /// <summary>
        /// 角色集合
        /// </summary>
        public List<string> RoleList { get; set; }
        /// <summary>
        /// 登录IP地址
        /// </summary>
        public string LoginIPAddress { get; set; }
        /// <summary>
        /// 登录IP地址具体信息
        /// </summary>
        public string LoginIPAddressName
        {
            get
            {
                return Net.GetLocation(this.LoginIPAddress);
            }
        }
        /// <summary>
        /// 登录Token
        /// </summary>
        public string LoginToken { get; set; }
        /// <summary>
        /// 登录时间
        /// </summary>
        public DateTime LoginTime { get; set; }
        /// <summary>
        /// 是否为超级管理员
        /// </summary>
        public bool IsSystem
        {
            get
            {
                return this.Account != null && this.Account.ToLower() == "sysadmin";
            }
        }
    }
}
