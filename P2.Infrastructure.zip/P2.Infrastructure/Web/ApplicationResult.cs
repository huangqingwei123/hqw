﻿namespace P2.Infrastructure
{
    /// <summary>
    /// 操作结果返回类
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ApplicationResult<T>
    {
        /// <summary>
        /// 操作结果类型
        /// </summary>
        public ResultCode status { get; set; }
        /// <summary>
        /// 获取消息内容
        /// </summary>
        public string message { get; set; }
        /// <summary>
        /// 获取 返回数据
        /// </summary>
        public T data { get; set; }
    }

    public enum ResultCode
    {        
        /// <summary>
        /// 成功结果类型
        /// </summary>
        success = 200,        
        /// <summary>
        /// 内部服务器错误
        /// </summary>
        error = 500,
        /// <summary>
        /// 请求无效
        /// </summary>
        invalid = 400,
        /// <summary>
        /// 禁止访问
        /// </summary>
        forbidden = 403
    }
}
