﻿using P2.Domain.Models;
using System.Data.Entity.ModelConfiguration;

namespace P2.Domain.Repositories.EntityFramework.Mapping
{
    public class SysLogMap : EntityTypeConfiguration<LogEntity>
    {
        public SysLogMap()
        {
            this.ToTable("Sys_Log");
            this.HasKey(t => t.Id);
        }
    }
}
