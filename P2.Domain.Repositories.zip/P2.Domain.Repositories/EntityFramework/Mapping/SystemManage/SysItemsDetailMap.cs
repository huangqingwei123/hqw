﻿using P2.Domain.Models;
using System.Data.Entity.ModelConfiguration;

namespace P2.Domain.Repositories.EntityFramework.Mapping
{
    public class SysItemsDetailMap : EntityTypeConfiguration<SysItemsDetailEntity>
    {
        public SysItemsDetailMap()
        {
            this.ToTable("Sys_ItemsDetail");
            this.HasKey(t => t.Id);
        }
    }
}
