﻿using P2.Domain.Models;
using System.Data.Entity.ModelConfiguration;

namespace P2.Domain.Repositories.EntityFramework.Mapping
{
    public class SysRoleMap : EntityTypeConfiguration<SysRoleEntity>
    {
        public SysRoleMap()
        {
            this.ToTable("Sys_Role");
            this.HasKey(t => t.Id);
        }
    }
}
