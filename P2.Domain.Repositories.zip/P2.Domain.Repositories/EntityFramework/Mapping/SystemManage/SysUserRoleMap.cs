﻿using P2.Domain.Models;
using System.Data.Entity.ModelConfiguration;

namespace P2.Domain.Repositories.EntityFramework.Mapping
{
    public class SysUserRoleMap : EntityTypeConfiguration<SysUserRoleEntity>
    {
        public SysUserRoleMap()
        {
            this.ToTable("Sys_UserRole");
            this.HasKey(t => t.Id);
        }
    }
}
