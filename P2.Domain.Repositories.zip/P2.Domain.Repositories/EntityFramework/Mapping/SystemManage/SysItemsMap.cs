﻿using P2.Domain.Models;
using System.Data.Entity.ModelConfiguration;

namespace P2.Domain.Repositories.EntityFramework.Mapping
{
    public class SysItemsMap : EntityTypeConfiguration<SysItemsEntity>
    {
        public SysItemsMap()
        {
            this.ToTable("Sys_Items");
            this.HasKey(t => t.Id).HasMany(t => t.Details).WithOptional(t => t.Items).HasForeignKey(p => p.ItemId);
        }
    }
}
