﻿using P2.Domain.Models;
using System.Data.Entity.ModelConfiguration;

namespace P2.Domain.Repositories.EntityFramework.Mapping
{
    public class SysOrganizeManagersMap : EntityTypeConfiguration<SysOrganizeManagersEntity>
    {
        public SysOrganizeManagersMap()
        {
            this.ToTable("Sys_OrganizeManagers");
            this.HasKey(t => t.Id);
        }
    }
}
