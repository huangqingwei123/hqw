﻿using P2.Domain.Models;
using System.Data.Entity.ModelConfiguration;

namespace P2.Domain.Repositories.EntityFramework.Mapping
{
    public class SysUserMap : EntityTypeConfiguration<SysUserEntity>
    {
        public SysUserMap()
        {
            this.ToTable("Sys_User");
            this.HasKey(p => p.Id);
            this.HasMany(p => p.RoleList).WithRequired(p => p.User).HasForeignKey(p => p.UserId);
        }
    }
}
