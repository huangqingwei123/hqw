﻿using P2.Domain.Models;
using System.Data.Entity.ModelConfiguration;

namespace P2.Domain.Repositories.EntityFramework.Mapping
{
    public class SysModuleButtonMap : EntityTypeConfiguration<SysModuleButtonEntity>
    {
        public SysModuleButtonMap()
        {
            this.ToTable("Sys_ModuleButton");
            this.HasKey(t => t.Id);
        }
    }
}
