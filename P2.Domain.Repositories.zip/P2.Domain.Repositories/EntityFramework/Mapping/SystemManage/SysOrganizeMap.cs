﻿using P2.Domain.Models;
using System.Data.Entity.ModelConfiguration;

namespace P2.Domain.Repositories.EntityFramework.Mapping
{
    public class SysOrganizeMap : EntityTypeConfiguration<SysOrganizeEntity>
    {
        public SysOrganizeMap()
        {
            this.ToTable("Sys_Organize");
            this.HasKey(t => t.Id);
            this.HasMany(p => p.Managers).WithRequired(p => p.Organize).HasForeignKey(p => p.OrganizeId);
        }
    }
}
