﻿using P2.Domain.Models;
using System.Data.Entity.ModelConfiguration;

namespace P2.Domain.Repositories.EntityFramework.Mapping
{
    public class SysPermissionMap : EntityTypeConfiguration<SysPermissionEntity>
    {
        public SysPermissionMap()
        {
            this.ToTable("Sys_Permission");
            this.HasKey(t => t.Id);
        }
    }
}
