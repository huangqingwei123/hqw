﻿using P2.Domain.Models;
using System.Data.Entity.ModelConfiguration;

namespace P2.Domain.Repositories.EntityFramework.Mapping
{
    public class SysModuleMap : EntityTypeConfiguration<SysModuleEntity>
    {
        public SysModuleMap()
        {
            this.ToTable("Sys_Module");
            this.HasKey(t => t.Id);
        }
    }
}
