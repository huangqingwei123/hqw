﻿using System;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Reflection;
using P2.Domain.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration.Conventions;
using P2.Domain;
using P2.Domain.Repositories.EntityFramework.Extensions;

namespace P2.Domain.Repositories.EntityFramework
{
    public class P2DbContext : DbContext
    {
        public P2DbContext()
            : base("P2DbContext")
        {
            this.Configuration.LazyLoadingEnabled = true;
            this.Configuration.AutoDetectChangesEnabled = true;
            Database.SetInitializer<P2DbContext>(null);
        }

        #region 系统管理

        public DbSet<SysModuleButtonEntity> ModuleButton { get; set; }
        public DbSet<SysModuleEntity> Module { get; set; }
        public DbSet<SysPermissionEntity> Permission { get; set; }
        public DbSet<SysOrganizeEntity> Organize { get; set; }
        public DbSet<SysOrganizeManagersEntity> OrganizeManagers { get; set; }
        public DbSet<SysUserEntity> User { get; set; }
        public DbSet<SysRoleEntity> Role { get; set; }
        #endregion


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            #region 利用反射动态追加Mapping
            string assembleFileName = Assembly.GetExecutingAssembly().CodeBase.Replace("file:///", "");
            Assembly asm = Assembly.LoadFile(assembleFileName);
            var typesToRegister = asm.GetTypes()
            .Where(type => !String.IsNullOrEmpty(type.Namespace))
            .Where(type => type.BaseType != null && type.BaseType.IsGenericType && type.BaseType.GetGenericTypeDefinition() == typeof(EntityTypeConfiguration<>));
            foreach (var type in typesToRegister)
            {
                dynamic configurationInstance = Activator.CreateInstance(type);
                modelBuilder.Configurations.Add(configurationInstance);
            }
            // modelBuilder.Entity<PDApickingtaskEntity>().Property(p => p.ID)
            //.HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);
            base.OnModelCreating(modelBuilder);
            #endregion

            modelBuilder.Conventions.Add(new DecimalPrecisionAttributeConvention());
            base.OnModelCreating(modelBuilder);
        }
    }
}
