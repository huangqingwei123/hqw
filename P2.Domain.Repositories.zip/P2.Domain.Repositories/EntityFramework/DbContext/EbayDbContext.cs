﻿using System.Data.Entity;
using P2.Domain.Repositories.EntityFramework.Extensions;

namespace P2.Domain.Repositories.EntityFramework
{
    public class EbayDbContext : DbContext
    {
        public EbayDbContext()
            : base("EbayDbContext")
        {
            this.Configuration.LazyLoadingEnabled = true;
            this.Configuration.AutoDetectChangesEnabled = true;
            Database.SetInitializer<EbayDbContext>(null);
        }


        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Add(new DecimalPrecisionAttributeConvention());
            base.OnModelCreating(modelBuilder);
        }
    }
}