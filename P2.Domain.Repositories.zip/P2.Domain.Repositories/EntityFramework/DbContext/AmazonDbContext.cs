﻿using System;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Reflection;
using P2.Domain.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration.Conventions;
using P2.Domain;
using P2.Domain.Repositories.EntityFramework.Extensions;

namespace P2.Domain.Repositories.EntityFramework
{
    /// <summary>
    /// 亚马逊数据库上下文
    /// </summary>
    public class AmazonDbContext : DbContext
    {
        public AmazonDbContext()
            : base("AmazonDbContext")
        {
            this.Configuration.LazyLoadingEnabled = true;
            this.Configuration.AutoDetectChangesEnabled = true;
            Database.SetInitializer<AmazonDbContext>(null);
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Add(new DecimalPrecisionAttributeConvention());
            base.OnModelCreating(modelBuilder);
        }
    }
}
