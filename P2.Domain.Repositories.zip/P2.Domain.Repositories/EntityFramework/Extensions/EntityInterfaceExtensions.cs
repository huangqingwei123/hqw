﻿namespace P2.Domain.Repositories.EntityFramework.Extensions
{
    /// <summary>
    /// 实体接口相关扩展
    /// </summary>
    public static class EntityInterfaceExtensions
    {
        
    }
}
