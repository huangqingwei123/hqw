﻿using P2.Domain.Models;
using P2.Domain.IRepositories;
using System.Collections.Generic;

namespace P2.Domain.Repositories.EntityFramework
{
    public class ModuleRepository : EntityFrameworkRepository<SysModuleEntity>, IModuleRepository
    {
        public ModuleRepository(IRepositoryContext context)
            : base(context)
        {
        }
    }
}
