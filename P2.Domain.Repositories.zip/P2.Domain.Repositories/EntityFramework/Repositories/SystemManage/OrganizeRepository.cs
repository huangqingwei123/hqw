﻿using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories.EntityFramework;

namespace P2.Domain.Repositories.EntityFramework
{
    public class OrganizeRepository : EntityFrameworkRepository<SysOrganizeEntity>, IOrganizeRepository
    {
        public OrganizeRepository(IRepositoryContext context)
            : base(context)
        {
        }
    }
}
