﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using System;
using System.Linq;
using System.Collections.Generic;
using P2.Infrastructure.Enums.SystemManage;
using System.Data.Entity;
using P2.Domain.Repositories.EntityFramework;

namespace P2.Domain.Repositories.EntityFramework
{
    public class UserRepository : EntityFrameworkRepository<SysUserEntity>, IUserRepository
    {
        public UserRepository(IRepositoryContext context)
            : base(context)
        {

        }

        /// <summary>
        /// 检测是否有相同名字的用户
        /// </summary>
        /// <param name="userCode"></param>
        /// <param name="isAdd"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool CheckSamName(string userCode, bool isAdd, string id = "")
        {
            if (isAdd)
            {
                return this.FindEntity(p => p.Account == userCode) == null ? true : false;
            }
            else
            {
                return this.FindEntity(p => p.Account == userCode && p.Id != id) == null ? true : false;
            }
        }
        /// <summary>
        /// 移除权限缓存
        /// </summary>
        /// <param name="roleId">角色ID</param>
        /// <param name="userId">用户ID</param>
        public void RemoveUserAuthorizeCache(string roleId = "", string userId = "")
        {
            var expression = ExtLinq.True<SysUserEntity>();
            expression = expression.And(p => !p.DeleteMark);
            if (!String.IsNullOrEmpty(roleId))
            {
                expression = expression.And(p => p.RoleList.Any(t => t.RoleId == roleId));
            }
            if (!String.IsNullOrEmpty(userId))
            {
                expression = expression.And(p => p.Id == userId);
            }
            var userList = GetAll(expression, p => p.RoleList).ToList();
            userList.ForEach(p => CacheFactory.Cache().RemoveCache("authorizeurldata_" + p.Id));
        }
    }
}
