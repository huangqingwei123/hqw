﻿using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories.EntityFramework;

namespace P2.Domain.Repositories.EntityFramework
{
    public class PermissionRepository : EntityFrameworkRepository<SysPermissionEntity>, IPermissionRepository
    {
        public PermissionRepository(IRepositoryContext context)
            : base(context)
        {
        }
    }
}
