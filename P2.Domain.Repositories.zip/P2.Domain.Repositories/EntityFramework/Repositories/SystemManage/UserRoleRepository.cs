﻿using P2.Domain.Models;
using P2.Domain.IRepositories;

namespace P2.Domain.Repositories.EntityFramework
{
    public class UserRoleRepository : EntityFrameworkRepository<SysUserRoleEntity>, IUserRoleRepository
    {
        public UserRoleRepository(IRepositoryContext context)
            : base(context)
        {
        }
    }
}
