﻿using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories.EntityFramework;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Text;
using System.Linq;

namespace P2.Domain.Repositories.EntityFramework
{
    public class ItemsDetailRepository : EntityFrameworkRepository<SysItemsDetailEntity>, IItemsDetailRepository
    {
        public ItemsDetailRepository(IRepositoryContext context)
            : base(context)
        {
        }

        public List<SysItemsDetailEntity> GetItemList(string enCode)
        {
            var strSql = new StringBuilder();
            strSql.Append(@"SELECT  d.*
                            FROM    Sys_ItemsDetail d
                                    INNER  JOIN Sys_Items i ON i.Id = d.ItemId
                            WHERE   1 = 1
                                    AND i.EnCode = @enCode
                                    AND d.EnabledMark = 1
                                    AND d.DeleteMark = 0
                            ORDER BY d.SortCode ASC");
            DbParameter[] parameter = 
            {
                 new SqlParameter("@enCode",enCode)
            };
            return _efContext.DbContex.Database.SqlQuery<SysItemsDetailEntity>(strSql.ToString(), parameter).ToList();
        }
    }
}
