﻿using P2.Domain.Models;
using P2.Domain.IRepositories;
using System.Collections.Generic;

namespace P2.Domain.Repositories.EntityFramework
{
    public class ModuleButtonRepository : EntityFrameworkRepository<SysModuleButtonEntity>, IModuleButtonRepository
    {
        public ModuleButtonRepository(IRepositoryContext context)
            : base(context)
        {
        }
    }
}
