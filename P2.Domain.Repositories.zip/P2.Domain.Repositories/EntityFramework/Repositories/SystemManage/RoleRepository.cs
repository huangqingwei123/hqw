﻿using P2.Domain.Models;
using P2.Domain.IRepositories;
using System.Collections.Generic;
using P2.Domain.Repositories.EntityFramework;

namespace P2.Domain.Repositories.EntityFramework
{
    public class RoleRepository : EntityFrameworkRepository<SysRoleEntity>, IRoleRepository
    {
        public RoleRepository(IRepositoryContext context)
            : base(context)
        {
        }

        //public void DeleteForm(string keyValue)
        //{
        //    using (var db = new RepositoryBase().BeginTrans())
        //    {
        //        db.Delete<SysRoleEntity>(t => t.Id == keyValue);
        //        db.Delete<SysPermissionEntity>(t => t.ObjectId == keyValue);
        //        db.Commit();
        //    }
        //}
    }
}
