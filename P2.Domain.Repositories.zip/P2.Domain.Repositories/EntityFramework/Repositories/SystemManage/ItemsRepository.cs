﻿using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories.EntityFramework;

namespace P2.Domain.Repositories.EntityFramework
{
    public class ItemsRepository : EntityFrameworkRepository<SysItemsEntity>, IItemsRepository
    {
        public ItemsRepository(IRepositoryContext context)
            : base(context)
        {
        }
    }
}
