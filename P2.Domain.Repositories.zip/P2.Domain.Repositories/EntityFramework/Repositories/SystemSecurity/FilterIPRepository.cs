﻿using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories.EntityFramework;

namespace P2.Domain.Repositories.EntityFramework
{
    public class FilterIPRepository : EntityFrameworkRepository<SysFilterIPEntity>, IFilterIPRepository
    {
        public FilterIPRepository(IRepositoryContext context)
            : base(context)
        {
        }
    }
}
