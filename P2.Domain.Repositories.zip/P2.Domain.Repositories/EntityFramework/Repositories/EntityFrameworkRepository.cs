﻿using P2.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.RegularExpressions;
using P2.Domain.IRepositories;
using P2.Infrastructure.Enums;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Data.Entity.Infrastructure;
using P2.Domain;
using P2.Domain.BaseModel;

namespace P2.Domain.Repositories.EntityFramework
{
    /// <summary>
    /// 仓储实现
    /// </summary>
    /// <typeparam name="TAggregateRoot"></typeparam>
    public class EntityFrameworkRepository<TAggregateRoot> : IRepository<TAggregateRoot> where TAggregateRoot : class, IAggregateRoot
    {
        protected readonly IEntityFrameworkRepositoryContext _efContext;

        protected EntityFrameworkRepository(IRepositoryContext context)
        {
            var efContext = context as IEntityFrameworkRepositoryContext;
            if (efContext != null)
                this._efContext = efContext;
        }
        public void Insert(TAggregateRoot aggregateRoot)
        {
            _efContext.RegisterNew(aggregateRoot);
        }
        public void Update(TAggregateRoot aggregateRoot)
        {
            _efContext.RegisterModified(aggregateRoot);
        }
        public void Remove(TAggregateRoot aggregateRoot)
        {
            _efContext.RegisterDeleted(aggregateRoot);            
        }
        public void Remove(Expression<Func<TAggregateRoot, bool>> predicate)
        {
            var aggregateRoots = _efContext.DbContex.Set<TAggregateRoot>().Where(predicate).ToList();
            foreach (var aggregateRoot in aggregateRoots)
            {
                _efContext.RegisterDeleted(aggregateRoot);
            }
        }
        public TAggregateRoot FindEntity(object keyValue)
        {
            return _efContext.DbContex.Set<TAggregateRoot>().Find(keyValue);
        }
        public TAggregateRoot FindEntity(Expression<Func<TAggregateRoot, bool>> predicate)
        {
            return _efContext.DbContex.Set<TAggregateRoot>().FirstOrDefault(predicate);
        }
        public IQueryable<TAggregateRoot> IQueryable()
        {
            return _efContext.DbContex.Set<TAggregateRoot>();
        }
        public IQueryable<TAggregateRoot> IQueryable(Expression<Func<TAggregateRoot, bool>> predicate)
        {
            return _efContext.DbContex.Set<TAggregateRoot>().Where(predicate);
        }
        public List<TAggregateRoot> FindList(Expression<Func<TAggregateRoot, bool>> predicate, Pagination pagination)
        {
            bool isAsc = pagination.sord.ToLower() == "asc" ? true : false;
            string[] _order = pagination.sidx.Split(',');
            MethodCallExpression resultExp = null;
            var tempData = _efContext.DbContex.Set<TAggregateRoot>().Where(predicate);
            foreach (string item in _order)
            {
                string _orderPart = item;
                _orderPart = Regex.Replace(_orderPart, @"\s+", " ");
                string[] _orderArry = _orderPart.Split(' ');
                string _orderField = _orderArry[0];
                bool sort = isAsc;
                if (_orderArry.Length == 2)
                {
                    isAsc = _orderArry[1].ToUpper() == "ASC" ? true : false;
                }
                var parameter = Expression.Parameter(typeof(TAggregateRoot), "t");
                var property = typeof(TAggregateRoot).GetProperty(_orderField);
                var propertyAccess = Expression.MakeMemberAccess(parameter, property);
                var orderByExp = Expression.Lambda(propertyAccess, parameter);
                resultExp = Expression.Call(typeof(Queryable), isAsc ? "OrderBy" : "OrderByDescending", new Type[] { typeof(TAggregateRoot), property.PropertyType }, tempData.Expression, Expression.Quote(orderByExp));
            }
            tempData = tempData.Provider.CreateQuery<TAggregateRoot>(resultExp);
            pagination.records = tempData.Count();
            tempData = tempData.Skip<TAggregateRoot>(pagination.rows * (pagination.page - 1)).Take<TAggregateRoot>(pagination.rows).AsQueryable();
            return tempData.ToList();
        }
        public IEnumerable<TAggregateRoot> GetAll(Expression<Func<TAggregateRoot, bool>> predicate, Expression<Func<TAggregateRoot, dynamic>> sortPredicate, Shared.SortOrder sortOrder)
        {
            var query = _efContext.DbContex.Set<TAggregateRoot>().Where(predicate);
            if (sortPredicate != null)
            {
                switch (sortOrder)
                {
                    case Shared.SortOrder.Ascending:
                        return query.SortBy(sortPredicate);
                    case Shared.SortOrder.Descending:
                        return query.SortByDescending(sortPredicate);
                    default:
                        break;
                }
            }
            return query;
        }
        public IEnumerable<TAggregateRoot> GetAll(Expression<Func<TAggregateRoot, bool>> predicate, params Expression<Func<TAggregateRoot, dynamic>>[] eagerLoadingProperties)
        {
            var dbset = _efContext.DbContex.Set<TAggregateRoot>();
            IQueryable<TAggregateRoot> queryable = null;
            if (eagerLoadingProperties != null &&
                eagerLoadingProperties.Length > 0)
            {
                var eagerLoadingProperty = eagerLoadingProperties[0];
                var eagerLoadingPath = this.GetEagerLoadingPath(eagerLoadingProperty);
                var dbquery = dbset.Include(eagerLoadingPath);
                for (var i = 1; i < eagerLoadingProperties.Length; i++)
                {
                    eagerLoadingProperty = eagerLoadingProperties[i];
                    eagerLoadingPath = this.GetEagerLoadingPath(eagerLoadingProperty);
                    dbquery = dbquery.Include(eagerLoadingPath);
                }
                queryable = dbquery.Where(predicate);
            }
            else
                queryable = dbset.Where(predicate);

            return queryable;
        }
        public IEnumerable<TAggregateRoot> GetAll(Expression<Func<TAggregateRoot, bool>> predicate, Expression<Func<TAggregateRoot, dynamic>> sortPredicate,
            Shared.SortOrder sortOrder, params Expression<Func<TAggregateRoot, dynamic>>[] eagerLoadingProperties)
        {
            var dbset = _efContext.DbContex.Set<TAggregateRoot>();
            IQueryable<TAggregateRoot> queryable = null;
            if (eagerLoadingProperties != null &&
                eagerLoadingProperties.Length > 0)
            {
                var eagerLoadingProperty = eagerLoadingProperties[0];
                var eagerLoadingPath = this.GetEagerLoadingPath(eagerLoadingProperty);
                var dbquery = dbset.Include(eagerLoadingPath);
                for (var i = 1; i < eagerLoadingProperties.Length; i++)
                {
                    eagerLoadingProperty = eagerLoadingProperties[i];
                    eagerLoadingPath = this.GetEagerLoadingPath(eagerLoadingProperty);
                    dbquery = dbquery.Include(eagerLoadingPath);
                }
                queryable = dbquery.Where(predicate);
            }
            else
                queryable = dbset.Where(predicate);

            if (sortPredicate != null)
            {
                switch (sortOrder)
                {
                    case Infrastructure.Enums.Shared.SortOrder.Ascending:
                        return queryable.SortBy(sortPredicate);
                    case Infrastructure.Enums.Shared.SortOrder.Descending:
                        return queryable.SortByDescending(sortPredicate);
                    default:
                        break;
                }
            }
            return queryable;
        }
        public IEnumerable<TAggregateRoot> GetAll(Expression<Func<TAggregateRoot, bool>> predicate, Pagination pagination, Expression<Func<TAggregateRoot, dynamic>> sortPredicate,
            Shared.SortOrder sortOrder, params Expression<Func<TAggregateRoot, dynamic>>[] eagerLoadingProperties)
        {
            var dbset = _efContext.DbContex.Set<TAggregateRoot>();
            IQueryable<TAggregateRoot> queryable = null;
            if (eagerLoadingProperties != null &&
                eagerLoadingProperties.Length > 0)
            {
                var eagerLoadingProperty = eagerLoadingProperties[0];
                var eagerLoadingPath = this.GetEagerLoadingPath(eagerLoadingProperty);
                var dbquery = dbset.Include(eagerLoadingPath);
                for (var i = 1; i < eagerLoadingProperties.Length; i++)
                {
                    eagerLoadingProperty = eagerLoadingProperties[i];
                    eagerLoadingPath = this.GetEagerLoadingPath(eagerLoadingProperty);
                    dbquery = dbquery.Include(eagerLoadingPath);
                }
                queryable = dbquery.Where(predicate);
            }
            else
                queryable = dbset.Where(predicate);

            pagination.records = queryable.Count();
            if (sortPredicate != null)
            {
                switch (sortOrder)
                {
                    case Infrastructure.Enums.Shared.SortOrder.Ascending:
                        queryable = queryable.SortBy(sortPredicate).Skip<TAggregateRoot>(pagination.rows * (pagination.page - 1)).Take<TAggregateRoot>(pagination.rows).AsQueryable();
                        break;
                    case Infrastructure.Enums.Shared.SortOrder.Descending:
                        queryable = queryable.SortByDescending(sortPredicate).Skip<TAggregateRoot>(pagination.rows * (pagination.page - 1)).Take<TAggregateRoot>(pagination.rows).AsQueryable();
                        break;
                    default:
                        break;
                }
            }
            return queryable;
        }

        #region 辅助方法

        private string GetEagerLoadingPath(Expression<Func<TAggregateRoot, dynamic>> eagerLoadingProperty)
        {
            var memberExpression = this.GetMemberInfo(eagerLoadingProperty);
            var parameterName = eagerLoadingProperty.Parameters.First().Name;
            var memberExpressionStr = memberExpression.ToString();
            var path = memberExpressionStr.Replace(parameterName + ".", "");
            return path;
        }

        private MemberExpression GetMemberInfo(LambdaExpression lambda)
        {
            if (lambda == null)
                throw new ArgumentNullException("lambda");
            MemberExpression memberExpr = null;

            switch (lambda.Body.NodeType)
            {
                case ExpressionType.Convert:
                    memberExpr =
                        ((UnaryExpression)lambda.Body).Operand as MemberExpression;
                    break;
                case ExpressionType.MemberAccess:
                    memberExpr = lambda.Body as MemberExpression;
                    break;
            }
            if (memberExpr == null)
                throw new ArgumentException("method");
            return memberExpr;
        }

        /// <summary>
        /// 用于监测Context中的Entity是否存在，如果存在，将其Detach，防止出现问题
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        private bool RemoveHoldingEntityInContext(TAggregateRoot entity)
        {
            var objContext = ((IObjectContextAdapter)_efContext.DbContex).ObjectContext;
            var objSet = objContext.CreateObjectSet<TAggregateRoot>();
            var entityKey = objContext.CreateEntityKey(objSet.EntitySet.Name, entity);

            Object foundEntity;
            var exists = objContext.TryGetObjectByKey(entityKey, out foundEntity);//是否有对象副本

            if (exists)
            {
                objContext.Detach(foundEntity);
            }
            return (exists);
        }
        #endregion
    }
}
