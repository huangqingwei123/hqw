﻿using ERPQ7.Infrastructure;
using ERPQ7.Domain.Entity;
using ERPQ7.Domain.IRepositories;
using ERPQ7.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using ERPQ7.Application.DTO.Output;
using AutoMapper;
using ERPQ7.Infrastructure.Extensions;
using ERPQ7.Infrastructure.Enums;
using ERPQ7.Infrastructure.Enums.SystemManage;
using ERPQ7.Application.IAppService;
using ERPQ7.Application.DTO.Input;

namespace ERPQ7.Application.AppService
{
    public class ModuleButtonAppService : ApplicationService, IModuleButtonAppService
    {
        private IModuleButtonRepository moduleButtonRepository;
        private IUserRepository userRepository;

        public ModuleButtonAppService(IRepositoryContext _repositoryContext, IModuleButtonRepository _moduleButtonRepository, IUserRepository _userRepository)
            : base(_repositoryContext)
        {
            moduleButtonRepository = _moduleButtonRepository;
            userRepository = _userRepository;
        }

        public List<ModuleButtonDTO> GetList(string keyword, string moduleId = "", bool showDisable = true)
        {
            var expression = ExtLinq.True<SysModuleButtonEntity>();
            if (!string.IsNullOrEmpty(keyword))
            {
                expression = expression.And(t => t.FullName == keyword);
            }
            if (!string.IsNullOrEmpty(moduleId))
            {
                expression = expression.And(t => t.ModuleId == moduleId);
            }
            if (!showDisable)
            {
                expression = expression.And(p => p.EnabledMark == true);
            }
            var data = moduleButtonRepository.IQueryable(expression).OrderBy(t => t.Location).ThenBy(p => p.SortCode).ToList();
            return AutoMapper.Mapper.Map<List<SysModuleButtonEntity>, List<ModuleButtonDTO>>(data);
        }

        public ModuleButtonDTO GetForm(string keyValue)
        {
            var entity = moduleButtonRepository.FindEntity(p => p.Id == keyValue);
            var dtoResult = Mapper.Map<SysModuleButtonEntity, ModuleButtonDTO>(entity);
            dtoResult.CreateUserName = userRepository.IQueryable(p => p.RecordID == entity.AddUserId).Select(p => p.UserID).FirstOrDefault();
            dtoResult.UpdataUserName = userRepository.IQueryable(p => p.RecordID == entity.LastModifyUserId).Select(p => p.UserID).FirstOrDefault();
            return dtoResult;
        }
        public void DeleteForm(string keyValue)
        {
            if (moduleButtonRepository.IQueryable().Count(t => t.ParentId.Equals(keyValue)) > 0)
            {
                throw new Exception("删除失败！操作的对象包含了下级数据。");
            }
            else
            {
                moduleButtonRepository.Remove(t => t.Id == keyValue);
                RepositorytContext.Commit();
            }
        }
        /// <summary>
        /// 新增，编辑
        /// </summary>
        /// <param name="inputDto"></param>
        /// <param name="keyValue"></param>
        public void SubmitForm(SubmitModuleButtonInput inputDto, string keyValue)
        {
            var initGroupEnumDic = EnumOperate.enumToDictionary<ModuleButtonEnum.InitGroupEnum>();
            var initGroup = inputDto.InitGroup.CastTo<string>("", true);
            if (initGroupEnumDic.Values.Contains(initGroup))
            {
                inputDto.InitGroup = initGroup;
            }
            if (!string.IsNullOrEmpty(keyValue))
            {
                var entity = moduleButtonRepository.FindEntity(p => p.Id == keyValue);
                entity.Description = inputDto.Description;
                entity.Icon = inputDto.Icon;
                entity.ModuleId = inputDto.ModuleId;
                entity.ParentId = inputDto.ParentId;
                entity.EnabledMark = inputDto.EnabledMark;
                entity.EnCode = inputDto.EnCode;
                entity.SortCode = inputDto.SortCode;
                entity.Layers = inputDto.Layers;
                entity.FullName = inputDto.FullName;
                entity.Location = inputDto.Location;
                entity.JsEvent = inputDto.JsEvent;
                entity.UrlAddress = inputDto.UrlAddress;
                entity.UrlAddress = inputDto.UrlAddress;
                entity.Split = inputDto.Split;
                entity.IsPublic = inputDto.IsPublic;
                entity.Description = inputDto.Description;
                entity.InitGroup = inputDto.InitGroup;
                entity.LastModifyTime = DateTime.Now;
                entity.LastModifyUserId = OperatorProvider.Provider.GetCurrent().UserRecordID;
                entity.InitGroup = inputDto.InitGroup;
                moduleButtonRepository.Update(entity);
            }
            else
            {
                var entity = AutoMapper.Mapper.Map<SubmitModuleButtonInput, SysModuleButtonEntity>(inputDto);
                var LoginInfo = OperatorProvider.Provider.GetCurrent();
                if (LoginInfo != null)
                {
                    entity.AddUserId = LoginInfo.UserRecordID;
                }
                entity.Id = Common.GuId();
                entity.AddTime = DateTime.Now;
                moduleButtonRepository.Insert(entity);
            }
            RepositorytContext.Commit();
        }

        /// <summary>
        /// 克隆按钮
        /// </summary>
        /// <param name="moduleId"></param>
        /// <param name="Ids"></param>
        public void SubmitCloneButton(string moduleId, string Ids)
        {
            string[] ArrayId = Ids.Split(',');
            var data = this.GetList("", "", false);
            foreach (string item in ArrayId)
            {
                var moduleButtonEntity = data.Find(t => t.Id == item);
                moduleButtonEntity.Id = Common.GuId();
                moduleButtonEntity.ModuleId = moduleId;
                var entity = Mapper.Map<ModuleButtonDTO, SysModuleButtonEntity>(moduleButtonEntity);
                moduleButtonRepository.Insert(entity);
            }
            RepositorytContext.Commit();
        }
    }
}
