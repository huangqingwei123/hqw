﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using AutoMapper;
using P2.Infrastructure.Extensions;
using P2.Application.DTO.Output;
using P2.Application.DTO.Input;
using System.Transactions;
using P2.Infrastructure.Enums;
using P2.Infrastructure.Enums.SystemManage;
using P2.Application.IAppService;
using System.Web.ModelBinding;
using P2.Domain.Repositories.EntityFramework;

namespace P2.Application.AppService
{
    public class UserAppService : ApplicationService, IUserAppService
    {
        private IUserRepository userRepository;
        private IRoleRepository roleRepository;
        private IOrganizeRepository organizeRepository;
        private IPermissionRepository permissionRepository;
        private IUserRoleRepository userRoleRepository;
        private IModuleAppService moduleAppService;
        private IModuleButtonAppService moduleButtonAppService;

        public UserAppService(IRepositoryContext _repositoryContext, IUserRepository _userRepository, IRoleRepository _roleRepository,
            IOrganizeRepository _organizeRepository, IPermissionRepository _permissionRepository, IUserRoleRepository _userRoleRepository,
            IModuleAppService _moduleAppService, IModuleButtonAppService _moduleButtonAppService)
            : base(_repositoryContext)
        {
            userRepository = _userRepository;
            roleRepository = _roleRepository;
            organizeRepository = _organizeRepository;
            permissionRepository = _permissionRepository;
            userRoleRepository = _userRoleRepository;
            moduleAppService = _moduleAppService;
            moduleButtonAppService = _moduleButtonAppService;
        }

        #region 数据查询

        /// <summary>
        /// 分页列表
        /// </summary>
        /// <param name="pagination"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public List<UserDto> GetList(BaseQueryDto inputDto)
        {
            var expression = ExtLinq.True<SysUserEntity>();
            expression = expression.And(t => t.Account != "sysadmin" && !t.DeleteMark);
            if (!string.IsNullOrEmpty(inputDto.Keyword))
            {
                expression = expression.And(t => t.Account.Contains(inputDto.Keyword) || t.RealName.Contains(inputDto.Keyword));
            }
            if (!string.IsNullOrEmpty(inputDto.DepartmentId))
            {
                var inputDepartmentIds = inputDto.DepartmentId.Split(new char[] { ',' }).ToArray();
                expression = expression.And(t => inputDepartmentIds.Contains(t.DepartmentId));
            }
            var data = new List<SysUserEntity>();
            if (inputDto.IsGetAll)
            {
                data = userRepository.GetAll(expression, p => p.RoleList).OrderBy(p => p.Account).ToList();
            }
            else
            {
                data = userRepository.GetAll(expression, inputDto.Pagination, p => p.Account, Shared.SortOrder.Ascending, p => p.RoleList).ToList();
            }
            var dtoResult = Mapper.Map<List<SysUserEntity>, List<UserDto>>(data);
            if (dtoResult != null)
            {
                var userRoleIds = dtoResult.SelectMany(p => p.RoleList).Select(p => p.RoleId).Distinct().ToList();
                var departmentIds = dtoResult.Select(p => p.DepartmentId).Distinct().ToList();
                var roles = roleRepository.IQueryable(p => !p.DeleteMark && p.EnabledMark && userRoleIds.Contains(p.Id)).Select(p => new { p.Id, p.FullName }).ToList();
                var organizes = organizeRepository.IQueryable(p => !p.DeleteMark && p.EnabledMark && departmentIds.Contains(p.Id)).ToList();

                dtoResult.ForEach(p =>
                {
                    p.RoleList.ForEach(t => t.RoleName = roles.Where(x => x.Id == t.RoleId).Select(x => x.FullName).FirstOrDefault());
                    p.DepartmentName = organizes.Where(x => x.Id == p.DepartmentId).Select(x => x.FullName).FirstOrDefault();
                });
            }
            return dtoResult;
        }
        /// <summary>
        /// 查询用户信息
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public UserDto GetForm(string keyValue)
        {
            var entity = userRepository.FindEntity(p => p.Id == keyValue && !p.DeleteMark);            
            var dtoResult = Mapper.Map<SysUserEntity, UserDto>(entity);
            if (dtoResult != null)
            {
                dtoResult.DepartmentName = organizeRepository.IQueryable(p => p.Id == entity.DepartmentId).Select(p => p.FullName).FirstOrDefault();
                dtoResult.CreateUserName = userRepository.IQueryable(p => p.Id == entity.CreatorUserId).Select(p => p.RealName).FirstOrDefault();
                dtoResult.UpdataUserName = userRepository.IQueryable(p => p.Id == entity.LastModifyUserId).Select(p => p.RealName).FirstOrDefault();
            }
            return dtoResult;
        }
        #endregion

        #region 删除

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public ApplicationResult<int> DeleteForm(string keyValue)
        {
            var entity = userRepository.FindEntity(p => p.RealName == keyValue && !p.DeleteMark);
            if (entity == null)
            {
                return new BaseApplication<int>().Error("未找到可以删除的用户！");
            }
            entity.DeleteMark = true;
            entity.RoleList = new List<SysUserRoleEntity>();
            userRepository.Update(entity);
            permissionRepository.Remove(t => t.ObjectId == entity.Id);
            var result = RepositorytContext.Commit();
            if (!result)
            {
                return new BaseApplication<int>().Error("操作失败！");
            }
            return new BaseApplication<int>().Success("操作成功！");
        }
        #endregion

        #region 新增编辑用户

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="workEntity"></param>
        /// <returns></returns>
        public ApplicationResult<int> Insert(SubmitUserInput inputDto)
        {
            try
            {
                if (String.IsNullOrEmpty(inputDto.DutyId))
                {
                    throw new Exception("缺少岗位信息");
                }
                if (String.IsNullOrEmpty(inputDto.DepartmentId))
                {
                    throw new Exception("缺少部门信息");
                }
                if (inputDto.UserRoles == null || inputDto.UserRoles.Count <= 0)
                {
                    throw new Exception("缺少角色信息");
                }
                var departmentEntity = organizeRepository.FindEntity(p => p.Id == inputDto.DepartmentId && p.EnabledMark && !p.DeleteMark);
                if (departmentEntity == null)
                {
                    throw new Exception("部门信息错误");
                }
                var checkResult = userRepository.CheckSamName(inputDto.Account, true);
                if (!checkResult)
                {
                    throw new Exception("已存在该用户编号");
                }
                var entity = new SysUserEntity()
                {
                    Id = Guid.NewGuid().ToString("N"),
                    Account = inputDto.Account,
                    RealName = inputDto.RealName,
                    Password = Common.UserPasswordEncrypt("123456"),
                    Birthday = inputDto.Birthday,
                    Email = inputDto.Email,
                    WeChat = inputDto.WeChat,
                    Gender = inputDto.Gender,
                    IsAdministrator = inputDto.IsAdministrator,
                    MobilePhone = inputDto.MobilePhone,
                    Description = inputDto.Description,
                    CreatorTime = DateTime.Now,                    
                    CreatorUserId = inputDto.OperaterId,
                    EnabledMark = inputDto.EnabledMark,
                    Birthplace =  "",
                    DepartmentId = inputDto.DepartmentId,
                    EnterpriseJobNumber = inputDto.EnterpriseJobNumber,
                    EntryDate = inputDto.EntryDate,
                    IDNumber = inputDto.IDNumber,                     
                    NickName = inputDto.NickName,
                    SortCode = inputDto.SortCode.CastTo<int>(),
                    TurnPositiveDate = inputDto.TurnPositiveDate,
                    DutyId = inputDto.DutyId                    
                };
                userRepository.Insert(entity);
                AddUserPermissions(entity.Id, inputDto);
                AddUserRoles(entity.Id, inputDto);
                var result = RepositorytContext.Commit();
                if (!result)
                {
                    throw new Exception("操作失败");
                }
                return new BaseApplication<int>().Success("操作成功！");
            }
            catch (Exception ex)
            {
                return new BaseApplication<int>().Error(ex.Message);
            }
        }

        /// <summary>
        /// 编辑
        /// </summary>
        /// <param name="workEntity"></param>
        /// <returns></returns>
        public ApplicationResult<int> Modify(SubmitUserInput inputDto, out bool shouldClearCookie)
        {
            shouldClearCookie = false;
            try
            {
                if (String.IsNullOrEmpty(inputDto.DutyId))
                {
                    throw new Exception("缺少岗位信息");
                }
                if (String.IsNullOrEmpty(inputDto.DepartmentId))
                {
                    throw new Exception("缺少部门信息");
                }
                if (inputDto.UserRoles == null || inputDto.UserRoles.Count <= 0)
                {
                    throw new Exception("缺少角色信息");
                }
                var entity = userRepository.FindEntity(p => p.Id == inputDto.KeyValue);
                if (entity == null)
                {
                    throw new Exception("未找到符合条件的信息");
                }
                var checkResult = userRepository.CheckSamName(inputDto.Account, false, entity.Id);
                if (!checkResult)
                {
                    throw new Exception("已存在该账户名");
                }
                var departmentEntity = organizeRepository.FindEntity(p => p.Id == inputDto.DepartmentId && p.EnabledMark && !p.DeleteMark);
                if (departmentEntity == null)
                {
                    throw new Exception("部门信息错误");
                }
                entity.Account = inputDto.Account;
                entity.RealName = inputDto.RealName;
                entity.Birthday = inputDto.Birthday;
                entity.EnabledMark = inputDto.EnabledMark;
                entity.Gender = inputDto.Gender;
                entity.DepartmentId = inputDto.DepartmentId;
                entity.IsAdministrator = inputDto.IsAdministrator;
                entity.MobilePhone = inputDto.MobilePhone;
                entity.WeChat = inputDto.WeChat;
                entity.Email = inputDto.Email;
                entity.DutyId = inputDto.DutyId;
                entity.Description = inputDto.Description;                
                entity.EnterpriseJobNumber = inputDto.EnterpriseJobNumber;
                entity.EntryDate = inputDto.EntryDate;
                entity.IDNumber = inputDto.IDNumber;                
                entity.NickName = inputDto.NickName;
                entity.SortCode = inputDto.SortCode.CastTo<int>();
                entity.TurnPositiveDate = inputDto.TurnPositiveDate;
                entity.DutyId = inputDto.DutyId;
                entity.LastModifyTime = DateTime.Now;
                entity.LastModifyUserId = inputDto.OperaterId;                

                userRepository.Update(entity);
                AddUserPermissions(entity.Id, inputDto);
                AddUserRoles(entity.Id, inputDto);
                var result = RepositorytContext.Commit();
                if (!result)
                {
                    throw new Exception("操作失败");
                }
                return new BaseApplication<int>().Success("操作成功！");
            }
            catch (Exception ex)
            {
                return new BaseApplication<int>().Error(ex.Message);
            }
        }
        /// <summary>
        /// 处理权限信息
        /// </summary>
        /// <param name="inputDto"></param>
        /// <returns></returns>
        private void AddUserPermissions(string userId, SubmitUserInput inputDto)
        {
            var moduleList = moduleAppService.GetList(false);
            var buttonList = moduleButtonAppService.GetList("", "", false);
            if (inputDto.PermissionIdList != null && inputDto.PermissionIdList.Count > 0)
            {
                foreach (var itemId in inputDto.PermissionIdList)
                {
                    var roleAuthorizeEntity = new SysPermissionEntity()
                    {
                        Id = Common.GuId(),
                        ObjectType = PermissionEnum.ObjectTypeEnum.用户,
                        ObjectId = userId,
                        ItemId = itemId,
                        AddTime = DateTime.Now,
                        AddUserID = OperatorProvider.Provider.GetCurrent().UserId
                    };
                    if (moduleList.Find(t => t.Id == itemId) != null)
                    {
                        roleAuthorizeEntity.ItemType = PermissionEnum.ItemTypeEnum.模块;
                    }
                    if (buttonList.Find(t => t.Id == itemId) != null)
                    {
                        roleAuthorizeEntity.ItemType = PermissionEnum.ItemTypeEnum.按钮;
                    }
                    permissionRepository.Insert(roleAuthorizeEntity);
                }
            }
            permissionRepository.Remove(p => p.ObjectId == inputDto.KeyValue && p.ObjectType == PermissionEnum.ObjectTypeEnum.用户);
            userRepository.RemoveUserAuthorizeCache(roleId: null, userId: userId);
        }
        /// <summary>
        /// 添加用户角色
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="inputDto"></param>
        private void AddUserRoles(string userId, SubmitUserInput inputDto)
        {
            userRoleRepository.Remove(p => p.UserId == userId);
            if (inputDto.UserRoles != null && inputDto.UserRoles.Count > 0)
            {
                inputDto.UserRoles.ForEach(p =>
                {
                    userRoleRepository.Insert(new SysUserRoleEntity
                    {
                        Id = Common.GuId(),
                        RoleId = p,
                        UserId = userId,
                        AddTime = DateTime.Now,
                        AddUserId = OperatorProvider.Provider.GetCurrent().UserId
                    });
                });
            }
        }

        /// <summary>
        /// 检测相同的用户名
        /// </summary>
        /// <param name="productCode"></param>
        /// <returns></returns>
        public ApplicationResult<int> CheckSameCode(string userCode)
        {
            var flag = userRepository.CheckSamName(userCode, true);
            if (!flag)
            {
                return new BaseApplication<int>().Error("已存在该用户编号！");
            }
            return new BaseApplication<int>().Success("校验通过！");
        }
        #endregion

        #region 登录验证

        /// <summary>
        /// 登录验证
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public CheckLoginUserDto CheckLogin(string username, string password)
        {
            var userEntity = userRepository.FindEntity(t => t.Account == username && !t.DeleteMark);
            if (userEntity != null)
            {
                if (userEntity.EnabledMark)
                {
                    string dbPassword = Common.UserPasswordEncrypt(password);
                    if (dbPassword == userEntity.Password)
                    {
                        var lastVisitTime = DateTime.Now;
                        var userDto = Mapper.Map<SysUserEntity, CheckLoginUserDto>(userEntity);
                        userDto.DepartmentName = organizeRepository.IQueryable(p => p.Id == userDto.DepartmentId).Select(p => p.FullName).FirstOrDefault();
                        return userDto;
                    }
                    else
                    {
                        throw new Exception("密码不正确请重新输入！");
                    }
                }
                else
                {
                    throw new Exception("该账户已被系统禁用，请联系管理员！");
                }
            }
            else
            {
                throw new Exception("账户不存在请重新输入！");
            }
        }
        #endregion

        #region 重置密码

        public ApplicationResult<int> RevisePassword(string keyValue, string password)
        {
            var entity = userRepository.FindEntity(p => p.Id == keyValue);
            if (entity == null)
            {
                return new BaseApplication<int>().Error("未找到符合条件的信息！");
            }
            try
            {
                entity.Password = Common.UserPasswordEncrypt(password);
                entity.LastModifyUserId = OperatorProvider.Provider.GetCurrent().UserId;
                entity.LastModifyTime = DateTime.Now;
                userRepository.Update(entity);
                RepositorytContext.Commit();
                return new BaseApplication<int>().Success("操作成功！");
            }
            catch
            {
                return new BaseApplication<int>().Error("程序异常！");
            }
        }
        #endregion

        #region 修改密码

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="oldPassword">旧密码</param>
        /// <param name="password">新密码</param>
        /// <returns></returns>
        public ApplicationResult<int> ChangePassword(string oldPassword, string password)
        {
            var userID = OperatorProvider.Provider.GetCurrent().UserId;
            var entity = userRepository.FindEntity(p => p.Id == userID && !p.DeleteMark);
            if (entity == null)
            {
                return new BaseApplication<int>().Error("用户信息错误！");
            }
            if (entity.Password != Common.UserPasswordEncrypt(oldPassword))
            {
                return new BaseApplication<int>().Error("旧密码验证错误！");
            }
            if (oldPassword == password)
            {
                return new BaseApplication<int>().Error("旧密码和新密码相同，无须修改！");
            }
            try
            {
                entity.Password = Common.UserPasswordEncrypt(password);
                entity.LastModifyUserId = userID;
                entity.LastModifyTime = DateTime.Now;
                userRepository.Update(entity);
                RepositorytContext.Commit();
                return new BaseApplication<int>().Success("操作成功！");
            }
            catch
            {
                return new BaseApplication<int>().Error("程序异常！");
            }
        }
        #endregion

        #region 其他操作

        /// <summary>
        /// 人员部门移动
        /// </summary>
        /// <param name="keyValueList"></param>
        /// <param name="targetDepartmentId"></param>
        /// <returns></returns>
        public ApplicationResult<int> MoveDepartment(List<string> keyValueList, string targetDepartmentId)
        {
            try
            {
                var userList = userRepository.IQueryable(p => keyValueList.Contains(p.Id) && !p.DeleteMark).ToList();
                if (userList.Count <= 0)
                {
                    throw new Exception("未找到可以操作的用户");
                }
                var departmentEntity = organizeRepository.FindEntity(p => p.Id == targetDepartmentId && p.EnabledMark && !p.DeleteMark);
                if (departmentEntity == null)
                {
                    throw new Exception("移动的部门信息错误");
                }
                userList.ForEach(p =>
                {
                    p.DepartmentId = targetDepartmentId;
                    userRepository.Update(p);
                });
                var result = RepositorytContext.Commit();
                if (!result)
                {
                    return new BaseApplication<int>().Error("操作失败！");
                }
                return new BaseApplication<int>().Success("操作成功！");
            }
            catch (Exception ex)
            {
                return new BaseApplication<int>().Error(ex.Message);
            }
        }
        /// <summary>
        /// 禁用，启用
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public ApplicationResult<int> EnabledOrDisabled(string keyValue, Shared.ValidType type)
        {
            var entity = userRepository.FindEntity(p => p.RealName == keyValue);
            if (entity == null)
            {
                return new BaseApplication<int>().Error("未找到符合条件的信息！");
            }
            try
            {
                if (type == Shared.ValidType.禁用)
                {
                    entity.EnabledMark = false;
                }
                else
                {
                    entity.EnabledMark = true;
                }
                userRepository.Update(entity);
                var result = RepositorytContext.Commit();
                if (!result)
                {
                    return new BaseApplication<int>().Error("操作失败！");
                }
                return new BaseApplication<int>().Success("操作成功！");
            }
            catch
            {
                return new BaseApplication<int>().Error("程序异常！");
            }
        }
        #endregion

    }
}
