﻿using P2.Application.DTO.Output;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Infrastructure;
using P2.Infrastructure.Enums;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using P2.Infrastructure.Extensions;
using P2.Application.SystemManage.Interface;
using P2.Application.SystemManage.Implementation;
using P2.Application.AppService;
using P2.Application.IAppService;
using P2.Application.DTO.Input;

namespace P2.Application.AppService
{
    public class ItemsDetailAppService : ApplicationService, IItemsDetailAppService
    {
        private IItemsDetailRepository itemsDetailRepository;
        private IItemsRepository itemsRepository;
        private IUserRepository userRepository;

        public ItemsDetailAppService(IRepositoryContext _repositoryContext, IItemsDetailRepository _roleRepository, IItemsRepository _itemsRepository, IUserRepository _userRepository)
            : base(_repositoryContext)
        {
            itemsDetailRepository = _roleRepository;
            itemsRepository = _itemsRepository;
            userRepository = _userRepository;
        }

        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="itemId"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public List<ItemsDetailDto> GetList(string itemId = "", string keyword = "")
        {            
            var expression = ExtLinq.True<SysItemsDetailEntity>();
            expression = expression.And(t => t.DeleteMark == false);
            if (!string.IsNullOrEmpty(itemId))
            {
                expression = expression.And(t => t.ItemId == itemId);
            }
            if (!string.IsNullOrEmpty(keyword))
            {
                expression = expression.And(t => t.ItemName.Contains(keyword));
                expression = expression.Or(t => t.ItemCode.Contains(keyword));
            }
            var data = itemsDetailRepository.IQueryable(expression).OrderBy(t => t.SortCode).ToList();
            var dtoResult = AutoMapper.Mapper.Map<List<SysItemsDetailEntity>, List<ItemsDetailDto>>(data);
            return dtoResult;
        }

        /// <summary>
        /// 获取明细
        /// </summary>
        /// <param name="enCode"></param>
        /// <returns></returns>
        public List<ItemsDetailDto> GetItemList(string enCode)
        {
            var data = itemsDetailRepository.GetItemList(enCode);
            var dtoResult = AutoMapper.Mapper.Map<List<SysItemsDetailEntity>, List<ItemsDetailDto>>(data);
            return dtoResult;
        }

        /// <summary>
        /// 获取单条数据
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public ItemsDetailDto GetForm(string keyValue)
        {
            var entity = itemsDetailRepository.FindEntity(p => p.Id == keyValue);
            var dtoResult = AutoMapper.Mapper.Map<SysItemsDetailEntity, ItemsDetailDto>(entity);
            if (dtoResult != null)
            {
                dtoResult.CreateUserName = userRepository.IQueryable(p => p.Id == dtoResult.AddUserId).Select(p => p.RealName).FirstOrDefault();
                dtoResult.ModifyUserName = userRepository.IQueryable(p => p.Id == dtoResult.LastModifyUserId).Select(p => p.RealName).FirstOrDefault();
            }
            return dtoResult;
        }

        /// <summary>
        /// 新增编辑
        /// </summary>
        /// <param name="inputDto"></param>
        /// <param name="keyValue"></param>
        public ApplicationResult<int> SubmitForm(SubmitItemsDetailInput inputDto, string keyValue)
        {
            try
            {
                if (!string.IsNullOrEmpty(keyValue))
                {
                    var entity = itemsDetailRepository.FindEntity(p => p.Id == keyValue);
                    if (entity == null)
                    {
                        throw new Exception("未找到可以操作的数据");
                    }
                    if (itemsDetailRepository.IQueryable(p => p.ItemId == entity.ItemId && p.Id != keyValue && !p.DeleteMark && p.ItemName == inputDto.ItemName).Count() > 0)
                    {
                        throw new Exception("已存在相同的字典名称：" + inputDto.ItemName);
                    }
                    if (itemsDetailRepository.IQueryable(p => p.ItemId == entity.ItemId && p.Id != keyValue && !p.DeleteMark && p.ItemCode == inputDto.ItemCode).Count() > 0)
                    {
                        throw new Exception("已存在相同的字典编号：" + inputDto.ItemCode);
                    }
                    if (entity.ItemCode != inputDto.ItemCode || !inputDto.EnabledMark)
                    {
                        var validateResult = ValidateItemsCanRemoveFactory(entity);
                        if (validateResult.status != ResultCode.success)
                        {
                            throw new Exception(validateResult.message + "，不能禁用字典以及更改编码");
                        }
                        entity.ItemCode = inputDto.ItemCode;
                    }                    
                    entity.ParentId = inputDto.ParentId;
                    entity.ItemCode = inputDto.ItemCode;
                    entity.ItemName = inputDto.ItemName;
                    entity.SimpleSpelling = inputDto.SimpleSpelling;
                    entity.IsDefault = inputDto.IsDefault;
                    entity.Layers = inputDto.Layers;
                    entity.SortCode = inputDto.SortCode;
                    entity.EnabledMark = inputDto.EnabledMark;
                    entity.Description = inputDto.Description;
                    entity.LastModifyTime = DateTime.Now;
                    entity.LastModifyUserId = OperatorProvider.Provider.GetCurrent().Account;
                    itemsDetailRepository.Update(entity);
                }
                else
                {
                    if (itemsDetailRepository.IQueryable(p => p.ItemId == inputDto.ItemId && !p.DeleteMark && p.ItemName == inputDto.ItemName).Count() > 0)
                    {
                        throw new Exception("已存在相同的字典名称：" + inputDto.ItemName);
                    }
                    if (itemsDetailRepository.IQueryable(p => p.ItemId == inputDto.ItemId && !p.DeleteMark && p.ItemCode == inputDto.ItemCode).Count() > 0)
                    {
                        throw new Exception("已存在相同的字典编号：" + inputDto.ItemCode);
                    }
                    var entity = AutoMapper.Mapper.Map<SubmitItemsDetailInput, SysItemsDetailEntity>(inputDto);
                    var LoginInfo = OperatorProvider.Provider.GetCurrent();
                    if (LoginInfo != null)
                    {
                        entity.AddUserId = LoginInfo.Account;
                    }
                    entity.Id = Common.GuId();
                    entity.AddTime = DateTime.Now;
                    itemsDetailRepository.Insert(entity);
                }
                var result = RepositorytContext.Commit();
                if (!result)
                {
                    return new BaseApplication<int>().Error("操作失败！");
                }
                return new BaseApplication<int>().Success("操作成功！");
            }
            catch (Exception ex)
            {
                return new BaseApplication<int>().Error(ex.Message + "！");
            }
        }

        #region 删除字典

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="keyValue"></param>
        public ApplicationResult<int> DeleteForm(string keyValue)
        {
            var entity = itemsDetailRepository.FindEntity(p => p.Id == keyValue);
            if (entity == null)
            {
                return new BaseApplication<int>().Error("未找到可以删除的信息！");
            }
            var validateResult = ValidateItemsCanRemoveFactory(entity);
            if (validateResult.status != ResultCode.success)
            {
                return new BaseApplication<int>().Error(validateResult.message);
            }
            var LoginInfo = OperatorProvider.Provider.GetCurrent();
            if (LoginInfo != null)
            {
                entity.DeleteUserId = LoginInfo.Account;
            }
            entity.DeleteTime = DateTime.Now;
            entity.DeleteMark = true;
            itemsDetailRepository.Update(entity);
            return new BaseApplication<int>().Success("删除成功！");
        }

        /// <summary>
        /// 验证字典是否被使用
        /// </summary>
        /// <param name="itemsDetail"></param>
        /// <returns></returns>
        public ApplicationResult<int> ValidateItemsCanRemoveFactory(SysItemsDetailEntity itemsDetail)
        {
            try
            {
                var itemsEntity = itemsDetail.Items;
                if (itemsEntity == null)
                {
                    throw new Exception("未找到该字典的分类信息");
                }
                var enCodeString = itemsEntity.EnCode.CastTo<Shared.ItemsEnum>();
                var usedMsgList = new List<string>();
                IValidateItems instance;
                switch (enCodeString)
                {
                    case Shared.ItemsEnum.ReimbursementUse:
                        instance = new ValidateItemsImplementation.ReimbursementUseImplementation();
                        break;
                    default:
                        return new BaseApplication<int>().Success("验证通过！");
                }
                var result = instance.IsBeUsed(itemsDetail, out usedMsgList);
                if (result)
                {
                    return new BaseApplication<int>().Success("验证通过！");
                }
                throw new Exception(string.Join("<br />", usedMsgList.ToArray()));
            }
            catch (Exception ex)
            {
                return new BaseApplication<int>().Error(ex.Message + "！");
            }
        }
        #endregion
    }
}
