﻿using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using P2.Infrastructure;
using P2.Application.DTO.Output;
using AutoMapper;
using P2.Infrastructure.Enums;
using P2.Infrastructure.Extensions;
using P2.Application.IAppService;
using P2.Domain.Repositories.EntityFramework;
using P2.Application.DTO.Input;

namespace P2.Application.AppService
{
    public class OrganizeAppService : ApplicationService, IOrganizeAppService
    {
        private IOrganizeRepository organizeRepository;
        private IUserRepository userRepository;

        public OrganizeAppService(IRepositoryContext _repositoryContext, IOrganizeRepository _organizeRepository, IUserRepository _userRepository)
            : base(_repositoryContext)
        {
            organizeRepository = _organizeRepository;
            userRepository = _userRepository;
        }

        #region 获取数据

        /// <summary>
        /// 获取组织机构列表
        /// </summary>
        /// <param name="showDisable">是否显示已禁用的数据，默认是显示</param>
        /// <param name="prentId">父节点ID</param>
        /// <param name="category">分类</param>
        /// <returns></returns>
        public List<OrganizeDto> GetList(bool showDisable = true, string prentId = "", string category = "")
        {            
            var expression = ExtLinq.True<OrganizeDto>();

            if (!showDisable)
            {
                expression = expression.And(p => p.EnabledMark == true);
            }
            if (!string.IsNullOrEmpty(prentId))
            {
                expression = expression.And(p => p.ParentId.Equals(prentId));
            }
            if (!string.IsNullOrEmpty(category))
            {
                expression = expression.And(p => p.CategoryId == category);
            }
            using (var db = new P2DbContext())
            {
                var query = (from org in db.Organize
                             join managers in
                                 (from a in db.OrganizeManagers where !a.DeleteMark select new { a.OrganizeId, a.Id, a.ManagerId }) on org.Id equals managers.OrganizeId into managerstemp
                             from managersview in managerstemp.DefaultIfEmpty()
                             join user in db.User on managersview.ManagerId equals user.Id into user_temp
                             from user_view in user_temp.DefaultIfEmpty()
                             where !org.DeleteMark
                             orderby org.SortCode ascending, org.AddTime descending
                             select new OrganizeDto()
                             {
                                 Id = org.Id,
                                 FullName = org.FullName,
                                 EnCode = org.EnCode,
                                 ParentId = org.ParentId,
                                 SortCode = org.SortCode,
                                 CategoryId = org.CategoryId,
                                 EnabledMark = org.EnabledMark,
                                 AddTime = org.AddTime,
                                 AddUserId = org.CategoryId,
                                 ManagerName = (user_view == null ? "" : user_view.RealName)
                             });
                var data = query.Where(expression).ToList();
                var result = data.GroupBy(p => new
                {
                    p.Id,
                    p.FullName,
                    p.EnCode,
                    p.ParentId,
                    p.SortCode,
                    p.CategoryId,
                    p.EnabledMark,
                    p.Address,
                    p.AddUserId
                }).Select(p => new OrganizeDto
                {
                    Id = p.Key.Id,
                    FullName = p.Key.FullName,
                    EnCode = p.Key.EnCode,
                    ParentId = p.Key.ParentId,
                    SortCode = p.Key.SortCode,
                    CategoryId = p.Key.CategoryId,
                    EnabledMark = p.Key.EnabledMark,
                    Address = p.Key.Address,
                    AddUserId = p.Key.AddUserId,
                    ManagerNames = string.Join(",", p.Select(t => t.ManagerName).Take(2).ToArray())
                }).ToList();
                return result;
            }
        }

        /// <summary>
        /// 获取单个组织机构信息
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public OrganizeDto GetForm(string keyValue)
        {
            var entity = organizeRepository.FindEntity(p => p.Id == keyValue);
            var dtoResult = Mapper.Map<SysOrganizeEntity, OrganizeDto>(entity);
            if (dtoResult != null)
            {
                if (dtoResult.Managers != null && dtoResult.Managers.Count > 0)
                {
                    dtoResult.Managers = dtoResult.Managers.Where(p => p.DeleteMark == false).ToList();
                    dtoResult.Managers.ForEach(p => p.ManagerName = userRepository.IQueryable(t => t.Id == p.ManagerId).Select(t => t.RealName).FirstOrDefault());
                }
            }
            return dtoResult;
        }
        #endregion

        #region 删除机构

        /// <summary>
        /// 删除机构
        /// </summary>
        /// <param name="keyValue"></param>
        public ApplicationResult<int> DeleteForm(string keyValue)
        {
            var entity = organizeRepository.FindEntity(p => p.Id == keyValue);
            if (entity == null)
            {
                return new BaseApplication<int>().Error("未找到可以删除的机构信息！");
            }
            if (organizeRepository.IQueryable().Count(t => t.ParentId == keyValue) > 0)
            {
                return new BaseApplication<int>().Error("操作的对象包含了下级机构，删除失败！");
            }
            entity.DeleteMark = true;
            organizeRepository.Update(entity);
            var result = RepositorytContext.Commit();
            if (!result)
            {
                return new BaseApplication<int>().Error("操作失败！");
            }
            return new BaseApplication<int>().Success("操作成功！");
        }
        #endregion

        #region 新增，修改组织机构

        /// <summary>
        /// 新增，修改组织机构
        /// </summary>
        /// <param name="inputDto"></param>
        /// <param name="keyValue"></param>
        public void SubmitForm(SubmitOrganizeInput inputDto)
        {
            inputDto.CastPropertyNull();//将Null的转成字符串
            if (!string.IsNullOrEmpty(inputDto.keyValue))
            {
                if (inputDto.ParentId == inputDto.keyValue)
                {
                    throw new Exception("上级组织机构不能等于本身！");
                }
                var children = organizeRepository.IQueryable(p => p.ParentId == inputDto.keyValue).Select(p => p.Id).ToList();
                if (children.Contains(inputDto.ParentId))
                {
                    throw new Exception("上级组织机构不能等于的子机构！");
                }
                var organize = organizeRepository.FindEntity(p => p.Id == inputDto.keyValue);
                organize.ParentId = inputDto.ParentId;
                organize.Layers = inputDto.Layers;
                organize.EnCode = inputDto.EnCode;
                organize.FullName = inputDto.FullName;
                organize.ShortName = inputDto.ShortName;
                organize.CategoryId = inputDto.CategoryId;
                organize.ManagerId = inputDto.ManagerId;
                organize.TelePhone = inputDto.TelePhone;
                organize.MobilePhone = inputDto.MobilePhone;
                organize.WeChat = inputDto.WeChat;
                organize.Fax = inputDto.Fax;
                organize.Email = inputDto.Email;
                organize.AreaId = inputDto.AreaId;
                organize.Address = inputDto.Address;
                organize.SortCode = inputDto.SortCode;
                organize.EnabledMark = inputDto.EnabledMark;
                organize.Description = inputDto.Description;
                organize.LastModifyTime = DateTime.Now;
                organize.LastModifyUserId = OperatorProvider.Provider.GetCurrent().UserId;
                organizeRepository.Update(organize);
                AddManagers(organize, inputDto);//添加负责人
                RepositorytContext.Commit();
            }
            else
            {
                var organize = AutoMapper.Mapper.Map<SubmitOrganizeInput, SysOrganizeEntity>(inputDto);
                var LoginInfo = OperatorProvider.Provider.GetCurrent();
                if (LoginInfo != null)
                {
                    organize.AddUserId = LoginInfo.UserId;
                }
                organize.Id = Common.GuId();
                organize.AddTime = DateTime.Now;
                organizeRepository.Insert(organize);
                AddManagers(organize, inputDto);//添加负责人
                RepositorytContext.Commit();
            }
        }

        /// <summary>
        /// 添加负责人
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="inputDto"></param>
        private void AddManagers(SysOrganizeEntity entity, SubmitOrganizeInput inputDto)
        {
            var perInputManagerIds = (inputDto.ManagerIds == null ? new List<string>() : inputDto.ManagerIds);

            if (!String.IsNullOrEmpty(inputDto.keyValue))//编辑
            {
                foreach (var item in entity.Managers.Where(p => !p.DeleteMark))
                {
                    if (!perInputManagerIds.Contains(item.ManagerId))
                    {
                        item.DeleteMark = true;
                    }
                    else
                    {
                        perInputManagerIds.Remove(item.ManagerId);
                    }
                }
            }
            if (perInputManagerIds != null && perInputManagerIds.Count > 0)
            {
                perInputManagerIds.ForEach(item =>
                {
                    entity.Managers.Add(new SysOrganizeManagersEntity
                    {
                        Id = Common.GuId(),
                        OrganizeId = entity.Id,
                        ManagerId = item,
                        AddTime = DateTime.Now,
                        AddUserId = OperatorProvider.Provider.GetCurrent().UserId
                    });
                });
            }
        }
        #endregion
    }
}
