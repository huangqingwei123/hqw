﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using P2.Application.DTO.Output;
using AutoMapper;
using P2.Application.IAppService;
using P2.Application.DTO.Input;

namespace P2.Application.AppService
{
    public class ModuleAppService: ApplicationService, IModuleAppService
    {
        private IModuleRepository moduleRepository ;
        private IUserRepository userRepository;

        public ModuleAppService(IRepositoryContext _repositoryContext, IModuleRepository _moduleRepository, IUserRepository _userRepository)
            : base(_repositoryContext)
        {
            moduleRepository = _moduleRepository;
            userRepository = _userRepository;
        }

        public List<ModuleDto> GetList(bool showDisable = true)
        {
            var expression = ExtLinq.True<SysModuleEntity>();
            if (!showDisable)
            {
                expression = expression.And(p => p.EnabledMark == true);
            }
            var data = moduleRepository.IQueryable(expression).OrderBy(t => t.SortCode).ToList();
            var dtoResult = Mapper.Map<List<SysModuleEntity>, List<ModuleDto>>(data);
            return dtoResult;
        }

        public ModuleDto GetForm(string keyValue)
        {
            var entity = moduleRepository.FindEntity(p => p.Id == keyValue);
            var dtoResult = Mapper.Map<SysModuleEntity, ModuleDto>(entity);
            dtoResult.CreateUserName = userRepository.IQueryable(p => p.Id == entity.AddUserId).Select(p => p.RealName).FirstOrDefault();
            dtoResult.UpdataUserName = userRepository.IQueryable(p => p.Id == entity.LastModifyUserId).Select(p => p.RealName).FirstOrDefault();
            return dtoResult;
        }
        public void DeleteForm(string keyValue)
        {
            if (moduleRepository.IQueryable().Count(t => t.ParentId.Equals(keyValue)) > 0)
            {
                throw new Exception("删除失败！操作的对象包含了下级数据。");
            }
            else
            {
                moduleRepository.Remove(t => t.Id == keyValue);
            }
            RepositorytContext.Commit();
        }
        public void SubmitForm(SubmitModuleInput inputDto, string keyValue)
        {
            if (!string.IsNullOrEmpty(keyValue))
            {
                var entity = moduleRepository.FindEntity(p => p.Id == keyValue);
                entity.AllowEdit = inputDto.AllowEdit;
                entity.AllowDelete = inputDto.AllowDelete;                
                entity.EnabledMark = inputDto.EnabledMark;
                entity.EnCode = inputDto.EnCode;
                entity.FullName = inputDto.FullName;
                entity.Icon = inputDto.Icon;
                entity.IsExpand = inputDto.IsExpand;
                entity.IsMenu = inputDto.IsMenu;
                entity.IsPublic = inputDto.IsPublic;
                entity.Layers = inputDto.Layers;
                entity.ParentId = inputDto.ParentId;
                entity.SortCode = inputDto.SortCode;
                entity.Target = inputDto.Target;
                entity.UrlAddress = inputDto.UrlAddress;
                entity.Description = inputDto.Description;
                entity.EnName = inputDto.EnName;
                entity.LastModifyTime = DateTime.Now;
                entity.LastModifyUserId = OperatorProvider.Provider.GetCurrent().UserId;
                moduleRepository.Update(entity);
            }
            else
            {
                var entity = AutoMapper.Mapper.Map<SubmitModuleInput, SysModuleEntity>(inputDto);
                var LoginInfo = OperatorProvider.Provider.GetCurrent();
                if (LoginInfo != null)
                {
                    entity.AddUserId = LoginInfo.UserId;
                }
                entity.Id = Common.GuId();
                entity.AddTime = DateTime.Now;
                moduleRepository.Insert(entity);
            }
            RepositorytContext.Commit();
        }
    }
}
