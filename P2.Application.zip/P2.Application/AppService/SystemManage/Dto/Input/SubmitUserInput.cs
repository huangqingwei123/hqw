﻿using P2.Infrastructure.Enums;
using P2.Infrastructure.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Application.DTO.Input
{
    public class SubmitUserInput
    {
        public string KeyValue { get; set; }

        [DisplayName("用户编号")]
        [Required]
        [MaxByteLength(50)]
        public string Account { get; set; }

        [DisplayName("姓名")]
        [Required]
        [MaxByteLength(20)]
        public string RealName { get; set; }

        [Required]
        [DisplayName("部门编号")]
        [MaxByteLength(50)]
        public string DepartmentId { get; set; }

        [DisplayName("性别")]
        [Required]
        [MaxByteLength(1)]
        public bool Gender { get; set; }

        [DisplayName("手机")]
        [MaxByteLength(20)]
        public string MobilePhone { get; set; }

        [DisplayName("生日")]
        [MaxByteLength(10)]
        public DateTime? Birthday { get; set; }

        [DisplayName("微信")]
        [MaxByteLength(50)]
        public string WeChat { get; set; }

        [DisplayName("电子邮件")]
        [EmailAddress(ErrorMessage = "错误的电子邮件格式")]
        [MaxByteLength(50)]
        public string Email { get; set; }

        [DisplayName("类型")]
        public bool IsAdministrator { get; set; }

        [DisplayName("允许登录")]
        public bool EnabledMark { get; set; }

        [DisplayName("是否删除")]
        public bool DeleteMark { get; set; }

        [DisplayName("备注")]
        [MaxByteLength(500)]
        public string Description { get; set; }

        [DisplayName("操作员ID")]
        public string OperaterId { get; set; }

        [DisplayName("昵称")]
        [MaxByteLength(50)]
        public string NickName { get; set; }

        [DisplayName("权限")]
        public List<string> PermissionIdList { get; set; }

        [Required]
        [DisplayName("用户角色")]
        public List<string> UserRoles { get; set; }

        [DisplayName("岗位")]
        [MaxByteLength(50)]
        public string DutyId { get; set; }

        [DisplayName("排序码")]
        public int? SortCode { get; set; }
        /// <summary>
        /// 入职日期
        /// </summary>                
        [DisplayName("入职日期")]
        public DateTime? EntryDate { get; set; }
        /// <summary>
        /// 企业工号
        /// </summary>        
        [DisplayName("企业工号")]
        [MaxByteLength(50)]
        public string EnterpriseJobNumber { get; set; }
        /// <summary>
        /// 转正日期
        /// </summary>        
        [DisplayName("转正日期")]
        public DateTime? TurnPositiveDate { get; set; }
        /// <summary>
        /// 身份证号
        /// </summary>        
        [DisplayName("身份证号")]
        [MaxByteLength(50)]
        public string IDNumber { get; set; }
        /// <summary>
        /// 学历
        /// </summary>
        [DisplayName("学历")]
        [MaxByteLength(50)]
        public string EducationalBackground { get; set; }
        /// <summary>
        /// 计薪规则
        /// </summary>        
        [DisplayName("计薪规则")]
        [MaxByteLength(50)]
        public string CalculateSalaryRule { get; set; }
        /// <summary>
        /// 个人电脑号
        /// </summary>
        [DisplayName("个人电脑号")]
        [MaxByteLength(50)]
        public string PersonalPCNo { get; set; }
        /// <summary>
        /// 个人公积金账号
        /// </summary>
        [DisplayName("个人公积金账号")]
        [MaxByteLength(50)]
        public string PersonalProvidentFundAccount { get; set; }
        /// <summary>
        /// 离职日期
        /// </summary>
        [DisplayName("离职日期")]
        [MaxByteLength(50)]
        public DateTime? DimissionDate { get; set; }
    }

}