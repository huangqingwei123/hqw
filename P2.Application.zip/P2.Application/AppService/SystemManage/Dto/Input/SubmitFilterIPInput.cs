﻿using P2.Infrastructure.Enums;
using P2.Infrastructure.Enums.SystemManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Application.DTO.Input
{
    public class SubmitFilterIPInput
    {
        public string Id { get; set; }
        public bool? Type { get; set; }
        public string StartIP { get; set; }
        public string EndIP { get; set; }
        public int? SortCode { get; set; }
        public bool DeleteMark { get; set; }
        public bool EnabledMark { get; set; }
        public string Description { get; set; }
    }

}