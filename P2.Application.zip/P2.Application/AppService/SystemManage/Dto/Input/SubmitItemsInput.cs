﻿using P2.Infrastructure.Enums;
using P2.Infrastructure.Enums.SystemManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Application.DTO.Input
{
    public class SubmitItemsInput
    {
        /// <summary>
        /// 主表主键
        /// </summary>        
        public string Id { get; set; }
        /// <summary>
        /// 父级
        /// </summary>        
        public string ParentId { get; set; }
        /// <summary>
        /// 编码
        /// </summary>        
        public string EnCode { get; set; }
        /// <summary>
        /// 名称
        /// </summary>        
        public string FullName { get; set; }
        /// <summary>
        /// 树型
        /// </summary>        
        public bool IsTree { get; set; }
        /// <summary>
        /// 层次
        /// </summary>        
        public int Layers { get; set; }
        /// <summary>
        /// 排序码
        /// </summary>        
        public int? SortCode { get; set; }
        /// <summary>
        /// 有效标志
        /// </summary>        
        public bool EnabledMark { get; set; }
        /// <summary>
        /// 描述
        /// </summary>        
        public string Description { get; set; }
    }

}