﻿using P2.Infrastructure.Enums;
using P2.Infrastructure.Enums.SystemManage;
using P2.Infrastructure.Extensions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Application.DTO.Input
{
    public class SubmitRoleInput
    {
        public string KeyValue { get; set; }

        [Required]
        [DisplayName("组织")]
        [MaxByteLength(50)]
        public string OrganizeId { get; set; }
        /// <summary>
        /// 编号
        /// </summary>     
        [Required]
        [DisplayName("编号")]
        [MaxByteLength(50)]
        public string EnCode { get; set; }
        /// <summary>
        /// 名称
        /// </summary>     
        [Required]
        [DisplayName("名称")]
        [MaxByteLength(50)]
        public string FullName { get; set; }
        /// <summary>
        /// 类型
        /// </summary>           
        [DisplayName("类型")]
        [MaxByteLength(50)]
        public RoleEnum.RoleType? Type { get; set; }
        /// <summary>
        /// 排序码
        /// </summary>      
        [DisplayName("排序码")]
        public int SortCode { get; set; }
        /// <summary>
        /// 有效标志
        /// </summary>      
        [DisplayName("有效标志")]
        public bool EnabledMark { get; set; }
        /// <summary>
        /// 描述
        /// </summary>
        [DisplayName("描述")]
        [MyMaxLength(255)]
        public string Description { get; set; }
        /// <summary>
        /// 权限ID集合
        /// </summary>
        [DisplayName("权限")]
        public List<string> PermissionIdList { get; set; }
    }

}