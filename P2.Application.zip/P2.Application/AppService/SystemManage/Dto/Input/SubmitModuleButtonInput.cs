﻿using P2.Infrastructure.Enums;
using P2.Infrastructure.Enums.SystemManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Application.DTO.Input
{
    public class SubmitModuleButtonInput
    {
        /// <summary>
        /// 按钮主键
        /// </summary>        
        public string Id { get; set; }
        /// <summary>
        /// 模块主键
        /// </summary>        
        public string ModuleId { get; set; }
        /// <summary>
        /// 父级
        /// </summary>        
        public string ParentId { get; set; }
        /// <summary>
        /// 层次
        /// </summary>        
        public int Layers { get; set; }
        /// <summary>
        /// 编码
        /// </summary>        
        public string EnCode { get; set; }
        /// <summary>
        /// 名称
        /// </summary>        
        public string FullName { get; set; }
        /// <summary>
        /// 图标
        /// </summary>        
        public string Icon { get; set; }
        /// <summary>
        /// 位置
        /// 1初始，2选中
        /// </summary>        
        public int Location { get; set; }
        /// <summary>
        /// 事件
        /// </summary>        
        public string JsEvent { get; set; }
        /// <summary>
        /// 连接
        /// </summary>        
        public string UrlAddress { get; set; }
        /// <summary>
        /// 分开线
        /// </summary>        
        public bool Split { get; set; }
        /// <summary>
        /// 公共
        /// </summary>        
        public bool IsPublic { get; set; }
        /// <summary>
        /// 允许编辑
        /// </summary>        
        public bool AllowEdit { get; set; }
        /// <summary>
        /// 允许删除
        /// </summary>        
        public bool AllowDelete { get; set; }
        /// <summary>
        /// 排序码
        /// </summary>        
        public int SortCode { get; set; }
        /// <summary>
        /// 有效标志
        /// </summary>        
        public bool EnabledMark { get; set; }
        /// <summary>
        /// 初始位置按钮所属分组
        /// </summary>        
        public string InitGroup { get; set; }
        /// <summary>
        /// 描述
        /// </summary>        
        public string Description { get; set; }
        /// <summary>
        /// 英文名
        /// </summary>
        public string EnName { get; set; }
    }

}