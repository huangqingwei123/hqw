﻿using P2.Infrastructure.Enums;
using P2.Infrastructure.Enums.SystemManage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Application.DTO.Input
{
    public class SubmitItemsDetailInput
    {
        /// <summary>
        /// 明细主键
        /// </summary>        
        public string Id { get; set; }
        /// <summary>
        /// 主表主键
        /// </summary>        
        public string ItemId { get; set; }
        /// <summary>
        /// 父级
        /// </summary>        
        public string ParentId { get; set; }
        /// <summary>
        /// 编码
        /// </summary>        
        public string ItemCode { get; set; }
        /// <summary>
        /// 名称
        /// </summary>        
        public string ItemName { get; set; }
        /// <summary>
        /// 简拼
        /// </summary>        
        public string SimpleSpelling { get; set; }
        /// <summary>
        /// 默认
        /// </summary>        
        public bool IsDefault { get; set; }
        /// <summary>
        /// 层次
        /// </summary>        
        public int Layers { get; set; }
        /// <summary>
        /// 排序码
        /// </summary>        
        public int SortCode { get; set; }
        /// <summary>
        /// 有效标志
        /// </summary>        
        public bool EnabledMark { get; set; }
        /// <summary>
        /// 描述
        /// </summary>        
        public string Description { get; set; }
    }

}