﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using P2.Domain.Models;
using Newtonsoft.Json;
using P2.Infrastructure;

namespace P2.Application.DTO.Output
{
    public class CheckLoginUserDto
    {
        /// <summary>
        /// 主键
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 登录名
        /// </summary>        
        public string Account { get; set; }
        /// <summary>
        /// 用户名称
        /// </summary>        
        public string RealName { get; set; }
        /// <summary>
        /// 性别
        /// </summary>        
        public string SexCode { get; set; }
        /// <summary>
        /// 密码
        /// </summary>        
        public string Password { get; set; }
        /// <summary>
        /// 昵称
        /// </summary>        
        public string NickName { get; set; }
        /// <summary>
        /// 生日
        /// </summary>        
        [JsonConverter(typeof(DateConverter))]
        public DateTime? Birthday { get; set; }
        /// <summary>
        /// 微信
        /// </summary>        
        public string WeChat { get; set; }
        /// <summary>
        /// 角色主键
        /// </summary>        
        public string RoleId { get; set; }
        /// <summary>
        /// 岗位主键
        /// </summary>        
        public string DutyId { get; set; }
        /// <summary>
        /// 排序码
        /// </summary>        
        public int SortCode { get; set; }
        /// <summary>
        /// 有效标志
        /// </summary>        
        public bool EnabledMark { get; set; }
        /// <summary>
        /// 入职日期
        /// </summary>     
        [JsonConverter(typeof(DateConverter))]
        public DateTime? EntryDate { get; set; }
        /// <summary>
        /// 转正日期
        /// </summary>        
        [JsonConverter(typeof(DateConverter))]
        public DateTime? TurnPositiveDate { get; set; }
        /// <summary>
        /// 企业工号
        /// </summary>        
        public string EnterpriseJobNumber { get; set; }
        /// <summary>
        /// 籍贯
        /// </summary>        
        public string Birthplace { get; set; }
        /// <summary>
        /// 身份证
        /// </summary>        
        public string IDNumber { get; set; }
        /// <summary>
        /// 所属部门
        /// </summary>        
        public string DepartmentId { get; set; }
        /// <summary>
        /// 邮件地址
        /// </summary>        
        public string Email { get; set; }
        /// <summary>
        /// 联系方式
        /// 手机
        /// </summary>        
        public string LinkTel { get; set; }
        /// <summary>
        /// 是否为管理员
        /// </summary>
        public bool IsAdministrator { get; set; }
        /// <summary>
        /// 备注
        /// </summary>        
        public string Remark { get; set; }
        /// <summary>
        /// 录入人ID
        /// </summary>        
        public string InputUserID { get; set; }
        /// <summary>
        /// 录入时间
        /// </summary>        
        public DateTime? InputDate { get; set; }
        /// <summary>
        /// 更新人ID
        /// </summary>        
        public string UpdateUserID { get; set; }
        /// <summary>
        /// 更新时间
        /// </summary>        
        public DateTime? UpdateDate { get; set; }
        /// <summary>
        /// 有效
        /// 1有效，0无效
        /// </summary>        
        public string IsValid { get; set; }
        /// <summary>
        /// 是否限制IP登录
        /// </summary>        
        public string ProhibitIPLogin { get; set; }
        /// <summary>
        /// 部门名称
        /// </summary>
        public string DepartmentName { get; set; }
        /// <summary>
        /// 角色名称
        /// </summary>
        public string RoleName { get; set; }
        public List<UserRoleDto> RoleList { get; set; }
    }
}
