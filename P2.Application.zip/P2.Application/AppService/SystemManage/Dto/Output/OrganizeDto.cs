﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using P2.Domain.Models;

namespace P2.Application.DTO.Output
{
    public class OrganizeDto 
    {
        public string Id { get; set; }
        public string ParentId { get; set; }
        public int? Layers { get; set; }
        public string EnCode { get; set; }
        public string FullName { get; set; }
        public string ShortName { get; set; }
        public string CategoryId { get; set; }
        public string ManagerId { get; set; }
        public string ManagerName { get; set; }
        public string TelePhone { get; set; }
        public string MobilePhone { get; set; }
        public string WeChat { get; set; }
        public string Fax { get; set; }
        public string Email { get; set; }
        public string AreaId { get; set; }
        public string Address { get; set; }
        public bool? AllowEdit { get; set; }
        public bool? AllowDelete { get; set; }
        public int? SortCode { get; set; }
        public bool DeleteMark { get; set; }
        public bool EnabledMark { get; set; }
        public string Description { get; set; }
        public DateTime? AddTime { get; set; }
        public string AddUserId { get; set; }
        public DateTime? LastModifyTime { get; set; }
        public string LastModifyUserId { get; set; }
        public DateTime? DeleteTime { get; set; }
        public string DeleteUserId { get; set; }
        public string CreateUserName { get; set; }
        public string UpdateUserName { get; set; }
        public string ButtonText { get; set; }
        public string ManagerNames { get; set; }
        public List<OrganizeManagersDto> Managers { get; set; }
    }
}
