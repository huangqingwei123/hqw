﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using P2.Domain.Models;
using P2.Infrastructure.Enums.SystemManage;

namespace P2.Application.DTO.Output
{
    public class UserRoleDto
    {
        /// <summary>
        /// 用户主键
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 角色主键
        /// </summary>
        public string RoleId { get; set; }
        /// <summary>
        /// 角色名字
        /// </summary>
        public string RoleName { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>        
        public DateTime? AddTime { get; set; }
        /// <summary>
        /// 创建用户
        /// </summary>        
        public string AddUserId { get; set; }
    }
}
