﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using P2.Domain.Models;

namespace P2.Application.DTO.Output
{
    public class OrganizeManagersDto
    {
        /// <summary>
        /// 主键
        /// </summary>        
        public string Id { get; set; }        
        /// <summary>
        /// 负责人主键
        /// </summary>        
        public string ManagerId { get; set; }
        /// <summary>
        /// 负责人名字
        /// </summary>
        public string ManagerName { get; set; }
        /// <summary>
        /// 删除标记
        /// </summary>
        public bool DeleteMark { get; set; }
    }
}
