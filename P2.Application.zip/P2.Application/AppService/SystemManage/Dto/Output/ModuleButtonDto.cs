﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using P2.Domain.Models;

namespace P2.Application.DTO.Output
{
    public class ModuleButtonDto
    {
        public string Id { get; set; }
        public string ModuleId { get; set; }
        public string ParentId { get; set; }
        public string EnCode { get; set; }
        public string FullName { get; set; }        
        public string Icon { get; set; }
        public int? Location { get; set; }
        public string JsEvent { get; set; }
        public string UrlAddress { get; set; }
        public int? SortCode { get; set; }
        public bool DeleteMark { get; set; }
        public bool EnabledMark { get; set; }
        public DateTime? AddTime { get; set; }
        public string AddUserId { get; set; }
        public DateTime? LastModifyTime { get; set; }
        public string LastModifyUserId { get; set; }
        public string CreateUserName { get; set; }
        public string UpdataUserName { get; set; }
        public string Description { get; set; }
        public string InitGroup { get; set; }
        public string EnName { get; set; }
    }
}
