﻿using P2.Infrastructure;
using P2.Infrastructure.Extensions;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Application.DTO.Output
{
    public class UserExportDto
    {
        /// <summary>
        /// 系统唯一标识
        /// </summary>
        [Description("系统唯一标识")]
        public string Id { get; set; }
        /// <summary>
        /// 账户
        /// </summary>        
        [Description("账户")]
        public string Account { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>        
        [Description("姓名")]
        public string RealName { get; set; }
        /// <summary>
        /// 性别
        /// </summary>      
        [Custom(true)]
        [Description("性别")]
        public bool Gender { get; set; }
        /// <summary>
        /// 性别
        /// </summary>
        [Description("性别")]
        public string GenderDescription
        {
            get
            {
                return Gender ? "男" : "女";
            }
        }
        /// <summary>
        /// 部门
        /// </summary>
        [Description("部门")]
        public string DepartmentName { get; set; }
        /// <summary>
        /// 角色
        /// </summary>
        [Custom(true)]
        [Description("角色")]
        public List<UserRoleDto> RoleList { get; set; }
        /// <summary>
        /// 角色
        /// </summary>
        [Description("角色")]
        public string RoleIds
        {
            get
            {
                if (this.RoleList == null || this.RoleList.Count <= 0)
                {
                    return "";
                }
                return string.Join(",", this.RoleList.OrderByDescending(t => t.AddTime).Select(t => t.RoleName).ToArray());
            }
        }
        /// <summary>
        /// 岗位
        /// </summary>    
        [Custom(true)]
        [Description("岗位")]
        public string DutyId { get; set; }
        /// <summary>
        /// 邮箱
        /// </summary>        
        [Description("邮箱")]
        public string Email { get; set; }
        /// <summary>
        /// 手机        
        /// </summary>        
        [Description("手机")]
        public string MobilePhone { get; set; }
        /// <summary>
        /// 是否为管理员
        /// </summary>
        [Custom(true)]
        [Description("是否为管理员")]
        public bool IsAdministrator { get; set; }
        /// <summary>
        /// 排序码
        /// </summary>            
        [Custom(true)]
        [Description("排序码")]
        public int SortCode { get; set; }
        /// <summary>
        /// 录入日期
        /// </summary>        
        [Description("录入日期")]
        [JsonConverter(typeof(DateConverter))]
        public DateTime? CreatorTime { get; set; }
        /// <summary>
        /// 描述
        /// </summary>     
        [Description("描述")]
        public string Description { get; set; }
    }
}
