﻿using P2.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Application.SystemManage.Interface
{
    public interface IValidateItems
    {
        bool IsBeUsed(SysItemsDetailEntity itemsDetail, out List<string> usedMsgList);
    }
}