﻿using P2.Application.SystemManage.Interface;
using P2.Domain.Models;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Application.SystemManage.Implementation
{
    /// <summary>
    /// 字典验证是否被业务单据使用
    /// </summary>
    public class ValidateItemsImplementation
    {
        /// <summary>
        /// 费用报销用途
        /// </summary>
        public class ReimbursementUseImplementation : IValidateItems
        {
            public bool IsBeUsed(SysItemsDetailEntity itemsDetail, out List<string> usedMsgList)
            {
                throw new NotImplementedException();
            }
        }
    }
}
