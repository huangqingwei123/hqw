﻿using AutoMapper;
using P2.Application.DTO.Output;
using P2.Infrastructure;
using P2.Infrastructure.Model;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using P2.Infrastructure.Enums.SystemManage;
using P2.Application.IAppService;
using P2.Domain.Repositories.EntityFramework;

namespace P2.Application.AppService
{
    /// <summary>
    /// 系统权限接口
    /// </summary>
    public class PermissionAppService : ApplicationService, IPermissionAppService
    {
        private IPermissionRepository _permissionRepository;
        private IRoleRepository _roleRepository;
        private IModuleAppService _moduleAppService;
        private IModuleButtonAppService _moduleButtonAppService;

        public PermissionAppService(IRepositoryContext repositoryContext, IPermissionRepository permissionRepository, IRoleRepository roleRepository,
            IModuleAppService moduleAppService, IModuleButtonAppService moduleButtonAppService)
            : base(repositoryContext)
        {
            _permissionRepository = permissionRepository;
            _roleRepository = roleRepository;
            _moduleAppService = moduleAppService;
            _moduleButtonAppService = moduleButtonAppService;
        }

        /// <summary>
        /// 通过对象ID获取所有权限
        /// </summary>
        /// <param name="ObjectId"></param>
        /// <returns></returns>
        public List<PermissionDto> GetList(string ObjectId)
        {
            var entity = _permissionRepository.IQueryable(t => t.ObjectId == ObjectId).ToList();
            var dtoResult = Mapper.Map<List<SysPermissionEntity>, List<PermissionDto>>(entity);
            return dtoResult;
        }
        /// <summary>
        /// 获取用户的菜单权限
        /// </summary>
        /// <param name="userRecordID"></param>
        /// <param name="userRoles"></param>
        /// <param name="isSystem"></param>
        /// <returns></returns>
        public List<ModuleDto> GetMenuList(string userRecordID, List<string> userRoles, bool isSystem)
        {
            var data = new List<ModuleDto>();
            if (isSystem)
            {
                data = _moduleAppService.GetList(false);
            }
            else
            {
                var moduleList = _moduleAppService.GetList(false);

                var permissionIDs = _permissionRepository
                    .IQueryable(t => (userRoles.Contains(t.ObjectId) || t.ObjectId == userRecordID) && t.ItemType == PermissionEnum.ItemTypeEnum.模块)
                    .Select(p => p.ItemId)
                    .Distinct()
                    .ToList();

                data.AddRange(moduleList.Where(p => permissionIDs.Contains(p.Id)));
            }
            return data.OrderBy(t => t.SortCode).ToList();
        }
        /// <summary>
        /// 获取用户的按钮权限
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="userRoles"></param>
        /// <param name="isSystem"></param>
        /// <returns></returns>
        public List<ModuleButtonDto> GetButtonList(string userId, List<string> userRoles, bool isSystem)
        {
            var data = new List<ModuleButtonDto>();
            if (isSystem)
            {
                data = _moduleButtonAppService.GetList("", "", false);
            }
            else
            {
                var buttonList = _moduleButtonAppService.GetList("", "", false);

                var permissionIDs = _permissionRepository
                    .IQueryable(t => (userRoles.Contains(t.ObjectId) || t.ObjectId == userId) && t.ItemType == PermissionEnum.ItemTypeEnum.按钮)
                    .Select(p => p.ItemId)
                    .Distinct()
                    .ToList();

                data.AddRange(buttonList.Where(p => permissionIDs.Contains(p.Id)));
            }
            data.ForEach(p => p.FullName = p.FullName);
            return data.OrderBy(t => t.SortCode).ToList();
        }
        /// <summary>
        /// 校验权限
        /// </summary>
        /// <param name="userRecordID"></param>
        /// <param name="userRoles"></param>
        /// <param name="moduleId"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        public bool ActionValidate(string userRecordID, List<string> userRoles, string moduleId, string action)
        {
            var authorizeurldata = new List<AuthorizeActionModel>();
            var cachedata = CacheFactory.Cache().GetCache<List<AuthorizeActionModel>>("authorizeurldata_" + userRecordID);
            if (cachedata == null)
            {
                var moduledata = _moduleAppService.GetList(false);
                var buttondata = _moduleButtonAppService.GetList("", "", false);
                var permissionList = _permissionRepository
                    .IQueryable(t => (userRoles.Contains(t.ObjectId) || t.ObjectId == userRecordID))
                    .GroupBy(p => new { p.ItemId, p.ItemType })
                    .Select(p => p.Key)
                    .Distinct()
                    .ToList();

                foreach (var item in permissionList)
                {
                    if (item.ItemType == PermissionEnum.ItemTypeEnum.模块)
                    {
                        var moduleEntity = moduledata.Find(t => t.Id == item.ItemId);
                        if (moduleEntity != null)
                        {
                            authorizeurldata.Add(new AuthorizeActionModel { Id = moduleEntity.Id, UrlAddress = moduleEntity.UrlAddress });
                        }
                    }
                    else if (item.ItemType == PermissionEnum.ItemTypeEnum.按钮)
                    {
                        var moduleButtonEntity = buttondata.Find(t => t.Id == item.ItemId);
                        if (moduleButtonEntity != null)
                        {
                            authorizeurldata.Add(new AuthorizeActionModel { Id = moduleButtonEntity.ModuleId, UrlAddress = moduleButtonEntity.UrlAddress });
                        }
                    }
                }
                CacheFactory.Cache().WriteCache(authorizeurldata, "authorizeurldata_" + userRecordID, DateTime.Now.AddMinutes(5));
            }
            else
            {
                authorizeurldata = cachedata;
            }
            authorizeurldata = authorizeurldata.FindAll(t => t.Id.Equals(moduleId));
            foreach (var item in authorizeurldata)
            {
                if (!string.IsNullOrEmpty(item.UrlAddress))
                {
                    string[] url = item.UrlAddress.Split('?');
                    if (item.Id == moduleId && url[0].ToLower() == action.ToLower())
                    {
                        return true;
                    }
                }
            }
            return false;
        }
        /// <summary>
        /// 获取按钮信息
        /// </summary>
        /// <param name="userRoles"></param>
        /// <param name="moduleId"></param>
        /// <param name="location"></param>
        /// <param name="isSystem"></param>
        /// <returns></returns>
        public List<ModuleButtonDto> GetModuleButtonList(string userId, List<string> userRoles, string moduleId, int location = -1, bool isSystem = false)
        {
            var expression = ExtLinq.True<ModuleButtonDto>();
            if (location != -1)
            {
                expression = expression.And(p => p.Location == location);
            }
            if (isSystem)
            {
                return _moduleButtonAppService.GetList(null, moduleId, false).AsQueryable().Where(expression).ToList();
            }
            else
            {
                using (var db = new P2DbContext())
                {
                    var data = (from A in db.ModuleButton
                                where (from B in db.Permission
                                       where !A.DeleteMark
                                       && A.EnabledMark
                                       && A.ModuleId == moduleId
                                       && (userRoles.Contains(B.ObjectId) || B.ObjectId == userId)
                                       && B.ItemType == PermissionEnum.ItemTypeEnum.按钮
                                       select B.ItemId
                                       ).Contains(A.Id)
                                orderby A.SortCode ascending
                                select new ModuleButtonDto()
                                {
                                    Id = A.Id,
                                    FullName = A.FullName,
                                    EnCode = A.EnCode,
                                    Icon = A.Icon,
                                    JsEvent = A.JsEvent,
                                    InitGroup = A.InitGroup,
                                    SortCode = A.SortCode,
                                    ParentId = A.ParentId,
                                    UrlAddress = A.UrlAddress,
                                    Location = A.Location,
                                    Description = A.Description,
                                    EnName = A.EnName,
                                }).Where(expression).ToList();
                    return data;
                }
            }
        }
    }
}
