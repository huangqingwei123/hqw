﻿using P2.Application.DTO.Output;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Infrastructure;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using P2.Application.IAppService;
using P2.Application.DTO.Input;

namespace P2.Application.AppService
{
    public class ItemsAppService : ApplicationService, IItemsAppService
    {
        private IItemsRepository itemsRepository;
        private IUserRepository userRepository;

        public ItemsAppService(IRepositoryContext _repositoryContext, IItemsRepository _itemsRepository, IUserRepository _userRepository)
            : base(_repositoryContext)
        {
            itemsRepository = _itemsRepository;
            userRepository = _userRepository;
        }

        /// <summary>
        /// 获取列表数据
        /// </summary>
        /// <returns></returns>
        public List<ItemsDataDto> GetList()
        {
            var data = itemsRepository.IQueryable(p => p.DeleteMark == false).ToList();
            var dtoResult = AutoMapper.Mapper.Map<List<SysItemsEntity>, List<ItemsDataDto>>(data);
            return dtoResult;
        }

        /// <summary>
        /// 获取单条数据
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public ItemsDataDto GetForm(string keyValue)
        {
            var entity = itemsRepository.FindEntity(p => p.Id == keyValue);
            var dtoResult = AutoMapper.Mapper.Map<SysItemsEntity, ItemsDataDto>(entity);
            if (dtoResult != null)
            {
                dtoResult.CreateUserName = userRepository.IQueryable(p => p.Id == dtoResult.AddUserId).Select(p => p.RealName).FirstOrDefault();
                dtoResult.ModifyUserName = userRepository.IQueryable(p => p.Id == dtoResult.LastModifyUserId).Select(p => p.RealName).FirstOrDefault();
            }
            return dtoResult;
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="keyValue"></param>
        public ApplicationResult<int> DeleteForm(string keyValue)
        {
            var entity = itemsRepository.FindEntity(p => p.Id == keyValue);
            if (entity == null)
            {
                return new BaseApplication<int>().Error("未找到可以删除的信息！");
            }
            if (itemsRepository.IQueryable().Count(t => !t.DeleteMark && t.ParentId == keyValue) > 0)
            {
                return new BaseApplication<int>().Error("操作的对象包含了下级数据，删除失败！");
            }
            if (entity.Details != null && entity.Details.Count > 0)
            {
                return new BaseApplication<int>().Error("该分类包含了" + entity.Details.Count + "条字典数据！");
            }
            entity.DeleteMark = true;
            itemsRepository.Update(entity);
            var result = RepositorytContext.Commit();
            if (!result)
            {
                return new BaseApplication<int>().Error("操作失败！");
            }
            return new BaseApplication<int>().Success("操作成功！");
        }

        /// <summary>
        /// 新增提交
        /// </summary>
        /// <param name="inputDto"></param>
        /// <param name="keyValue"></param>
        public ApplicationResult<int> SubmitForm(SubmitItemsInput inputDto, string keyValue)
        {
            try
            {
                if (itemsRepository.IQueryable(p => p.Id != keyValue && !p.DeleteMark && p.FullName == inputDto.FullName).Count() > 0)
                {
                    throw new Exception("已存在相同的分类名称：" + inputDto.FullName);
                }
                if (itemsRepository.IQueryable(p => p.Id != keyValue && !p.DeleteMark && p.EnCode == inputDto.EnCode).Count() > 0)
                {
                    throw new Exception("已存在相同的编号：" + inputDto.EnCode);
                }
                if (inputDto.ParentId == keyValue)
                {
                    throw new Exception("上级分类不能等于本身");
                }
                var children = itemsRepository.IQueryable(p => p.ParentId == keyValue).Select(p => p.Id).ToList();
                if (children.Contains(inputDto.ParentId))
                {
                    throw new Exception("上级分类不能等于的下级");
                }
                if (!string.IsNullOrEmpty(keyValue))
                {
                    var entity = itemsRepository.FindEntity(p => p.Id == keyValue);
                    entity.ParentId = inputDto.ParentId;
                    entity.EnCode = inputDto.EnCode;
                    entity.FullName = inputDto.FullName;
                    entity.IsTree = inputDto.IsTree;
                    entity.Layers = inputDto.Layers;
                    entity.SortCode = inputDto.SortCode;
                    entity.EnabledMark = inputDto.EnabledMark;
                    entity.Description = inputDto.Description;
                    entity.LastModifyTime = DateTime.Now;
                    entity.LastModifyUserId = OperatorProvider.Provider.GetCurrent().UserId;
                    itemsRepository.Update(entity);
                }
                else
                {
                    var entity = AutoMapper.Mapper.Map<SubmitItemsInput, SysItemsEntity>(inputDto);
                    entity.Id = Common.GuId();
                    entity.AddUserId = OperatorProvider.Provider.GetCurrent().UserId;
                    entity.AddTime = DateTime.Now;
                    itemsRepository.Insert(entity);
                }
                var result = RepositorytContext.Commit();
                if (!result)
                {
                    return new BaseApplication<int>().Error("操作失败！");
                }
                return new BaseApplication<int>().Success("操作成功！");
            }
            catch (Exception ex)
            {
                return new BaseApplication<int>().Error(ex.Message);
            }
        }
    }
}
