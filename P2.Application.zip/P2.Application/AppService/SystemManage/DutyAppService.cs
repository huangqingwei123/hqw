﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using P2.Application.DTO.Output;
using System;
using P2.Application.IAppService;
using P2.Application.DTO.Input;

namespace P2.Application.AppService
{
    public class DutyAppService : ApplicationService, IDutyAppService
    {
        private IRoleRepository roleRepository;
        private IUserRepository userRepository;

        public DutyAppService(IRepositoryContext _repositoryContext, IRoleRepository _roleRepository, IUserRepository _userRepository)
            : base(_repositoryContext)
        {
            roleRepository = _roleRepository;
            userRepository = _userRepository;
        }

        public List<RoleDto> GetList(string keyword = "")
        {
            var expression = ExtLinq.True<SysRoleEntity>();
            if (!string.IsNullOrEmpty(keyword))
            {
                expression = expression.And(t => t.FullName.Contains(keyword) || t.EnCode.Contains(keyword));
            }
            expression = expression.And(t => t.Category == 2);
            var data = roleRepository.IQueryable(expression).OrderBy(t => t.SortCode).ToList();
            var dtoResult = Mapper.Map<List<SysRoleEntity>, List<RoleDto>>(data);
            dtoResult.ForEach(p => p.TypeDesc = p.Type.ToString());
            return dtoResult;
        }
        /// <summary>
        /// 岗位下拉框数据源
        /// </summary>
        /// <returns></returns>
        public List<RoleDto> GetDropList()
        {
            var expression = ExtLinq.True<SysRoleEntity>();
            expression = expression.And(t => t.Category == 2 && t.EnabledMark == true);
            var data = roleRepository.IQueryable(expression).OrderBy(t => t.SortCode).ToList();
            var dtoResult = Mapper.Map<List<SysRoleEntity>, List<RoleDto>>(data);
            dtoResult.ForEach(p => p.TypeDesc = p.Type.ToString());
            return dtoResult;
        }

        public RoleDto GetForm(string keyValue)
        {
            var entity = roleRepository.FindEntity(p => p.Id == keyValue);
            if (entity == null)
            {
                return null;
            }
            var roleEntity = Mapper.Map<SysRoleEntity, RoleDto>(entity);
            roleEntity.CreateUserName = userRepository.IQueryable(p => p.Id == entity.AddUserId).Select(p => p.RealName).FirstOrDefault();
            roleEntity.UpdataUserName = userRepository.IQueryable(p => p.Id == entity.LastModifyUserId).Select(p => p.RealName).FirstOrDefault();
            return roleEntity;
        }

        public void DeleteForm(string keyValue)
        {
            roleRepository.Remove(t => t.Id == keyValue);
            RepositorytContext.Commit();
        }

        public void SubmitForm(SubmitRoleInput inputDto, string keyValue)
        {
            if (!string.IsNullOrEmpty(keyValue))
            {
                if (roleRepository.IQueryable(p => p.Category == 2 && p.Id != keyValue && (p.FullName == inputDto.FullName || p.EnCode == inputDto.EnCode)).Count() > 0)
                {
                    throw new Exception("已存在相同编号或名称的岗位");
                }
                var moduleEntity = roleRepository.FindEntity(p => p.Id == keyValue);
                moduleEntity.EnabledMark = inputDto.EnabledMark;
                moduleEntity.EnCode = inputDto.EnCode;
                moduleEntity.FullName = inputDto.FullName;
                moduleEntity.OrganizeId = inputDto.OrganizeId;
                moduleEntity.SortCode = inputDto.SortCode;
                moduleEntity.Description = inputDto.Description;
                moduleEntity.LastModifyTime = DateTime.Now;
                moduleEntity.LastModifyUserId = OperatorProvider.Provider.GetCurrent().UserId;
                roleRepository.Update(moduleEntity);
                RepositorytContext.Commit();
            }
            else
            {
                if (roleRepository.IQueryable(p => p.Category == 2 && (p.FullName == inputDto.FullName || p.EnCode == inputDto.EnCode)).Count() > 0)
                {
                    throw new Exception("已存在相同编号或名称的岗位");
                }
                var entity = AutoMapper.Mapper.Map<SubmitRoleInput, SysRoleEntity>(inputDto);
                entity.Id = Common.GuId();
                entity.AddUserId = OperatorProvider.Provider.GetCurrent().UserId;
                entity.AddTime = DateTime.Now;
                entity.Category = 2;
                roleRepository.Insert(entity);
                RepositorytContext.Commit();
            }
        }
    }
}
