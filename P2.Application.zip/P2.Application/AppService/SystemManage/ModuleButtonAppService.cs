﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using P2.Application.DTO.Output;
using AutoMapper;
using P2.Infrastructure.Extensions;
using P2.Infrastructure.Enums;
using P2.Infrastructure.Enums.SystemManage;
using P2.Application.IAppService;
using P2.Application.DTO.Input;

namespace P2.Application.AppService
{
    public class ModuleButtonAppService : ApplicationService, IModuleButtonAppService
    {
        private IModuleButtonRepository _moduleButtonRepository;
        private IUserRepository _userRepository;        

        public ModuleButtonAppService(IRepositoryContext _repositoryContext, IModuleButtonRepository moduleButtonRepository, IUserRepository userRepository)
            : base(_repositoryContext)
        {
            _moduleButtonRepository = moduleButtonRepository;
            _userRepository = userRepository;            
        }

        public List<ModuleButtonDto> GetList(string keyword, string moduleId = "", bool showDisable = true)
        {
            var expression = ExtLinq.True<SysModuleButtonEntity>();
            if (!string.IsNullOrEmpty(keyword))
            {
                expression = expression.And(t => t.FullName == keyword);
            }
            if (!string.IsNullOrEmpty(moduleId))
            {
                expression = expression.And(t => t.ModuleId == moduleId);
            }
            if (!showDisable)
            {
                expression = expression.And(p => p.EnabledMark == true);
            }
            var data = _moduleButtonRepository.IQueryable(expression).OrderBy(t => t.Location).ThenBy(p => p.SortCode).ToList();
            return AutoMapper.Mapper.Map<List<SysModuleButtonEntity>, List<ModuleButtonDto>>(data);
        }

        public ModuleButtonDto GetForm(string keyValue)
        {
            var entity = _moduleButtonRepository.FindEntity(p => p.Id == keyValue);
            var dtoResult = Mapper.Map<SysModuleButtonEntity, ModuleButtonDto>(entity);
            dtoResult.CreateUserName = _userRepository.IQueryable(p => p.Id == entity.AddUserId).Select(p => p.RealName).FirstOrDefault();
            dtoResult.UpdataUserName = _userRepository.IQueryable(p => p.Id == entity.LastModifyUserId).Select(p => p.RealName).FirstOrDefault();
            return dtoResult;
        }
        public void DeleteForm(string keyValue)
        {
            if (_moduleButtonRepository.IQueryable().Count(t => t.ParentId.Equals(keyValue)) > 0)
            {
                throw new Exception("删除失败！操作的对象包含了下级数据。");
            }
            else
            {
                _moduleButtonRepository.Remove(t => t.Id == keyValue);
                RepositorytContext.Commit();
            }
        }
        /// <summary>
        /// 新增，编辑
        /// </summary>
        /// <param name="inputDto"></param>
        /// <param name="keyValue"></param>
        public void SubmitForm(SubmitModuleButtonInput inputDto, string keyValue)
        {
            var initGroupEnumDic = EnumOperate.enumToDictionary<ModuleButtonEnum.InitGroupEnum>();
            var initGroup = inputDto.InitGroup.CastTo<string>("", true);
            if (initGroupEnumDic.Values.Contains(initGroup))
            {
                inputDto.InitGroup = initGroup;
            }
            if (!string.IsNullOrEmpty(keyValue))
            {
                var entity = _moduleButtonRepository.FindEntity(p => p.Id == keyValue);
                entity.Description = inputDto.Description;
                entity.Icon = inputDto.Icon;
                entity.ModuleId = inputDto.ModuleId;
                entity.ParentId = inputDto.ParentId;
                entity.EnabledMark = inputDto.EnabledMark;
                entity.EnCode = inputDto.EnCode;
                entity.SortCode = inputDto.SortCode;
                entity.Layers = inputDto.Layers;
                entity.FullName = inputDto.FullName;
                entity.Location = inputDto.Location;
                entity.JsEvent = inputDto.JsEvent;
                entity.UrlAddress = inputDto.UrlAddress;
                entity.UrlAddress = inputDto.UrlAddress;
                entity.Split = inputDto.Split;
                entity.IsPublic = inputDto.IsPublic;
                entity.Description = inputDto.Description;
                entity.InitGroup = inputDto.InitGroup;
                entity.LastModifyTime = DateTime.Now;
                entity.LastModifyUserId = OperatorProvider.Provider.GetCurrent().UserId;
                entity.InitGroup = inputDto.InitGroup;
                entity.EnName = inputDto.EnName;
                _moduleButtonRepository.Update(entity);
            }
            else
            {
                var entity = AutoMapper.Mapper.Map<SubmitModuleButtonInput, SysModuleButtonEntity>(inputDto);
                var LoginInfo = OperatorProvider.Provider.GetCurrent();
                if (LoginInfo != null)
                {
                    entity.AddUserId = LoginInfo.UserId;
                }
                entity.Id = Common.GuId();
                entity.AddTime = DateTime.Now;
                _moduleButtonRepository.Insert(entity);
            }
            RepositorytContext.Commit();
            _userRepository.RemoveUserAuthorizeCache();
        }

        /// <summary>
        /// 克隆按钮
        /// </summary>
        /// <param name="moduleId"></param>
        /// <param name="Ids"></param>
        public void SubmitCloneButton(string moduleId, string Ids)
        {
            string[] ArrayId = Ids.Split(',');
            var data = this.GetList("", "", false);
            foreach (string item in ArrayId)
            {
                var moduleButtonEntity = data.Find(t => t.Id == item);
                moduleButtonEntity.Id = Common.GuId();
                moduleButtonEntity.ModuleId = moduleId;
                var entity = Mapper.Map<ModuleButtonDto, SysModuleButtonEntity>(moduleButtonEntity);
                _moduleButtonRepository.Insert(entity);
            }
            RepositorytContext.Commit();
            _userRepository.RemoveUserAuthorizeCache();
        }
    }
}
