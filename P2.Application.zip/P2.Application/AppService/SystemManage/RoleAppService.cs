﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System.Collections.Generic;
using System.Linq;
using System;
using P2.Application.DTO.Output;
using AutoMapper;
using P2.Infrastructure.Enums.SystemManage;
using System.Transactions;
using P2.Application.DTO.Input;
using P2.Infrastructure.Extensions;
using P2.Application.IAppService;

namespace P2.Application.AppService
{
    public class RoleAppService : ApplicationService, IRoleAppService
    {
        private IRoleRepository roleRepository;
        private IUserRepository userRepository;
        private IPermissionRepository permissionRepository;
        private IModuleAppService moduleAppService;
        private IModuleButtonAppService moduleButtonAppService;

        public RoleAppService(IRepositoryContext _repositoryContext, IRoleRepository _roleRepository, IUserRepository _userRepository,
           IPermissionRepository _permissionRepository, IModuleAppService _moduleAppService, IModuleButtonAppService _moduleButtonAppService)
            : base(_repositoryContext)
        {
            roleRepository = _roleRepository;
            userRepository = _userRepository;
            permissionRepository = _permissionRepository;
            moduleAppService = _moduleAppService;
            moduleButtonAppService = _moduleButtonAppService;
        }

        /// <summary>
        /// 分页列表
        /// </summary>
        /// <param name="keyword">关键词</param>
        /// <param name="showDisable">是否隐藏已禁用的数据</param>
        /// <returns></returns>
        public List<RoleDto> GetList(string keyword = "", bool showDisable = true)
        {
            var expression = ExtLinq.True<SysRoleEntity>();
            if (!string.IsNullOrEmpty(keyword))
            {
                expression = expression.And(t => t.FullName.Contains(keyword) || t.EnCode.Contains(keyword));
            }
            if (!showDisable)
            {
                expression = expression.And(t => t.EnabledMark == true);
            }
            expression = expression.And(t => t.Category == 1);
            var data = roleRepository.IQueryable(expression).OrderBy(t => t.SortCode).ToList();
            var dtoResult = Mapper.Map<List<SysRoleEntity>, List<RoleDto>>(data);
            dtoResult.ForEach(p => p.TypeDesc = p.Type.ToString());
            return dtoResult;
        }

        /// <summary>
        /// 获取下拉绑定列表
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public List<RoleDto> GetList()
        {
            var data = roleRepository.IQueryable(p => p.Category == 1 && p.EnabledMark == true && p.EnabledMark != null).OrderBy(t => t.FullName).ToList();
            var dtoResult = Mapper.Map<List<SysRoleEntity>, List<RoleDto>>(data);
            return dtoResult;
        }

        /// <summary>
        /// 获取单个角色信息
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public RoleDto GetForm(string keyValue)
        {
            var entity = roleRepository.FindEntity(p => p.Id == keyValue);
            if (entity == null)
            {
                return null;
            }
            var roleEntity = Mapper.Map<SysRoleEntity, RoleDto>(entity);
            roleEntity.CreateUserName = userRepository.IQueryable(p => p.Id == entity.AddUserId).Select(p => p.RealName).FirstOrDefault();
            roleEntity.UpdataUserName = userRepository.IQueryable(p => p.Id == entity.LastModifyUserId).Select(p => p.RealName).FirstOrDefault();
            return roleEntity;
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="keyValue"></param>
        public ApplicationResult<int> DeleteForm(string keyValue)
        {
            var entity = roleRepository.FindEntity(p => p.Id == keyValue);
            if (entity == null)
            {
                return new BaseApplication<int>().Error("未找到可以删除的数据！");
            }
            if (IsBindUser(keyValue))
            {
                return new BaseApplication<int>().Error("该角色已经绑定了用户，删除失败！");
            }
            roleRepository.Remove(t => t.Id == keyValue);
            permissionRepository.Remove(t => t.ObjectId == keyValue);
            var result = RepositorytContext.Commit();
            if (!result)
            {
                return new BaseApplication<int>().Error("操作失败！");
            }
            return new BaseApplication<int>().Success("操作成功！");
        }

        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="workEntity"></param>
        /// <returns></returns>
        public ApplicationResult<int> Insert(SubmitRoleInput inputDto)
        {
            try
            {
                var entity = new SysRoleEntity()
                {
                    Id = Common.GuId(),
                    Category = 1,
                    FullName = inputDto.FullName,
                    Type = inputDto.Type,
                    EnCode = inputDto.EnCode,
                    Description = inputDto.Description,
                    OrganizeId = inputDto.OrganizeId,
                    AddTime = DateTime.Now,
                    AddUserId = OperatorProvider.Provider.GetCurrent().UserId,
                    EnabledMark = inputDto.EnabledMark,
                    SortCode = inputDto.SortCode.CastTo<int>(),
                    AllowDelete = true,
                    AllowEdit = true,
                };
                roleRepository.Insert(entity);
                AddRolePermissions(entity.Id, inputDto);
                if (RepositorytContext.Commit())
                {
                    return new BaseApplication<int>().Success("操作成功！");
                }
                return new BaseApplication<int>().Error("操作失败！");
            }
            catch (Exception ex)
            {
                return new BaseApplication<int>().Error(ex.Message);
            }
        }

        /// <summary>
        /// 编辑
        /// </summary>
        /// <param name="workEntity"></param>
        /// <returns></returns>
        public ApplicationResult<int> Modify(SubmitRoleInput inputDto)
        {
            try
            {
                var entity = roleRepository.FindEntity(p => p.Id == inputDto.KeyValue);
                if (entity == null)
                {
                    return new BaseApplication<int>().Error("未找到符合条件的信息！");
                }
                if (!inputDto.EnabledMark && IsBindUser(inputDto.KeyValue))
                {
                    return new BaseApplication<int>().Error("该角色已经绑定了用户，禁用失败！");
                }
                entity.OrganizeId = inputDto.OrganizeId;
                entity.EnCode = inputDto.EnCode;
                entity.FullName = inputDto.FullName;
                entity.Type = inputDto.Type;
                entity.SortCode = inputDto.SortCode;
                entity.EnabledMark = inputDto.EnabledMark;
                entity.Description = inputDto.Description;
                entity.LastModifyTime = DateTime.Now;
                entity.LastModifyUserId = OperatorProvider.Provider.GetCurrent().UserId;

                roleRepository.Update(entity);
                AddRolePermissions(entity.Id, inputDto);
                if (RepositorytContext.Commit())
                {
                    return new BaseApplication<int>().Success("操作成功！");
                }
                return new BaseApplication<int>().Error("操作失败！");
            }
            catch
            {
                return new BaseApplication<int>().Error("程序异常！");
            }
        }

        /// <summary>
        /// 处理权限信息
        /// </summary>
        /// <param name="inputDto"></param>
        /// <returns></returns>
        private void AddRolePermissions(string roleId, SubmitRoleInput inputDto)
        {
            var moduleList = moduleAppService.GetList(false);
            var buttonList = moduleButtonAppService.GetList("", "", false);
            if (inputDto.PermissionIdList != null && inputDto.PermissionIdList.Count > 0)
            {
                foreach (var itemId in inputDto.PermissionIdList)
                {
                    var roleAuthorizeEntity = new SysPermissionEntity()
                    {
                        Id = Common.GuId(),
                        ObjectType = PermissionEnum.ObjectTypeEnum.角色,
                        ObjectId = roleId,
                        ItemId = itemId,
                        AddTime = DateTime.Now,
                        AddUserID = OperatorProvider.Provider.GetCurrent().UserId
                    };
                    if (moduleList.Find(t => t.Id == itemId) != null)
                    {
                        roleAuthorizeEntity.ItemType = PermissionEnum.ItemTypeEnum.模块;
                    }
                    if (buttonList.Find(t => t.Id == itemId) != null)
                    {
                        roleAuthorizeEntity.ItemType = PermissionEnum.ItemTypeEnum.按钮;
                    }
                    permissionRepository.Insert(roleAuthorizeEntity);
                }
            }
            permissionRepository.Remove(p => p.ObjectId == inputDto.KeyValue && p.ObjectType == PermissionEnum.ObjectTypeEnum.角色);//删除原有信息
            userRepository.RemoveUserAuthorizeCache(roleId: roleId, userId: null);
        }

        /// <summary>
        /// 检测该角色是否已经绑定了用户
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public bool IsBindUser(string keyValue)
        {
            return userRepository.GetAll(p => p.RoleList.Any(t => t.RoleId == keyValue), p => p.RoleList).Count() > 0;
        }
    }
}
