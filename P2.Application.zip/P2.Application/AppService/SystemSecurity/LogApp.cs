﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System;
using System.Linq;
using System.Collections.Generic;
using P2.Application.IAppService;
using P2.Infrastructure.Enums;
using P2.Application.DTO.Output;

namespace P2.Application.AppService
{
    public class LogAppService : ApplicationService, ILogAppService
    {
        private ILogRepository logRepository;

        public LogAppService(IRepositoryContext _repositoryContext, ILogRepository _logRepository)
            : base(_repositoryContext)
        {
            logRepository = _logRepository;
        }

        public List<LogDto> GetList(Pagination pagination, string queryJson)
        {
            var expression = ExtLinq.True<LogEntity>();
            var queryParam = queryJson.ToJObject();
            if (!queryParam["productID"].IsEmpty())
            {
                string keyword = queryParam["productID"].ToString();
                expression = expression.And(t => t.Account.Contains(keyword));
            }
            if (!queryParam["timeType"].IsEmpty())
            {
                string timeType = queryParam["timeType"].ToString();
                DateTime startTime = DateTime.Now.ToString("yyyy-MM-dd").ToDate();
                DateTime endTime = DateTime.Now.ToString("yyyy-MM-dd").ToDate().AddDays(1);
                switch (timeType)
                {
                    case "1":
                        break;
                    case "2":
                        startTime = DateTime.Now.AddDays(-7);
                        break;
                    case "3":
                        startTime = DateTime.Now.AddMonths(-1);
                        break;
                    case "4":
                        startTime = DateTime.Now.AddMonths(-3);
                        break;
                    default:
                        break;
                }
                expression = expression.And(t => t.Date >= startTime && t.Date <= endTime);
            }
            var data = logRepository.GetAll(expression, pagination, p => p.AddTime, Shared.SortOrder.Descending).ToList();
            var dtoResult = AutoMapper.Mapper.Map<List<LogEntity>, List<LogDto>>(data);
            return dtoResult;
        }
        public void RemoveLog(string keepTime)
        {
            DateTime operateTime = DateTime.Now;
            if (keepTime == "7")            //保留近一周
            {
                operateTime = DateTime.Now.AddDays(-7);
            }
            else if (keepTime == "1")       //保留近一个月
            {
                operateTime = DateTime.Now.AddMonths(-1);
            }
            else if (keepTime == "3")       //保留近三个月
            {
                operateTime = DateTime.Now.AddMonths(-3);
            }
            var expression = ExtLinq.True<LogEntity>();
            expression = expression.And(t => t.Date <= operateTime);
            logRepository.Remove(expression);
        }
        public void WriteDbLog(bool result, string resultLog)
        {
            LogEntity logEntity = new LogEntity();
            logEntity.Id = Common.GuId();
            logEntity.Date = DateTime.Now;
            logEntity.Account = OperatorProvider.Provider.GetCurrent().Account;
            logEntity.NickName = OperatorProvider.Provider.GetCurrent().RealName;
            logEntity.IPAddress = Net.Ip;
            logEntity.IPAddressName = Net.GetLocation(logEntity.IPAddress);
            logEntity.Result = result;
            logEntity.Description = resultLog;
            var LoginInfo = OperatorProvider.Provider.GetCurrent();
            if (LoginInfo != null)
            {
                logEntity.AddUserId = LoginInfo.UserId;
            }
            logEntity.AddTime = DateTime.Now;
            logRepository.Insert(logEntity);
        }
        public void WriteDbLog(LogDto input)
        {
            var logEntity = new LogEntity()
            {
                Id = Common.GuId(),
                Date = DateTime.Now,
                IPAddress = "117.81.192.182",
                IPAddressName = Net.GetLocation(input.IPAddress),
            };
            var LoginInfo = OperatorProvider.Provider.GetCurrent();
            if (LoginInfo != null)
            {
                logEntity.AddUserId = LoginInfo.UserId;
            }
            logEntity.AddTime = DateTime.Now;
            logRepository.Insert(logEntity);
        }
    }
}
