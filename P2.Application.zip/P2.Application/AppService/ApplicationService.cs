﻿using P2.Application.IAppService;
using P2.Domain.IRepositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Application.AppService
{
    /// <summary>
    /// 定义一个应用服务抽象类，以便把重复的代码放在该抽象类中
    /// </summary>
    public abstract class ApplicationService : IApplicationService
    {
        private readonly IRepositoryContext _repositoryContext;

        protected ApplicationService(IRepositoryContext repositoryContext)
        {
            _repositoryContext = repositoryContext;
        }

        protected IRepositoryContext RepositorytContext
        {
            get { return this._repositoryContext; }
        }
    }
}
