﻿using P2.Application.DTO.Output;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Infrastructure;
using P2.Infrastructure.Enums;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using P2.Infrastructure.Extensions;
using P2.Application.SystemManage.Interface;
using P2.Application.SystemManage.Implementation;
using P2.Application.DTO.Input;

namespace P2.Application.IAppService
{
    public interface IItemsDetailAppService
    {
        /// <summary>
        /// 查询
        /// </summary>
        /// <param name="itemId"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        List<ItemsDetailDto> GetList(string itemId = "", string keyword = "");
        /// <summary>
        /// 获取明细
        /// </summary>
        /// <param name="enCode"></param>
        /// <returns></returns>
        List<ItemsDetailDto> GetItemList(string enCode);
        /// <summary>
        /// 获取单条数据
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        ItemsDetailDto GetForm(string keyValue);
        /// <summary>
        /// 新增编辑
        /// </summary>
        /// <param name="inputDto"></param>
        /// <param name="keyValue"></param>
        ApplicationResult<int> SubmitForm(SubmitItemsDetailInput inputDto, string keyValue);
        /// 删除
        /// </summary>
        /// <param name="keyValue"></param>
        ApplicationResult<int> DeleteForm(string keyValue);

        /// <summary>
        /// 验证字典是否被使用
        /// </summary>
        /// <param name="itemsDetail"></param>
        /// <returns></returns>
        ApplicationResult<int> ValidateItemsCanRemoveFactory(SysItemsDetailEntity itemsDetail);
    }
}
