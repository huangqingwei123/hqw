﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using AutoMapper;
using P2.Infrastructure.Extensions;
using P2.Application.DTO.Output;
using P2.Application.DTO.Input;
using System.Transactions;
using P2.Infrastructure.Enums;
using P2.Infrastructure.Enums.SystemManage;

namespace P2.Application.IAppService
{
    public interface IUserAppService
    {       
        /// <summary>
        /// 分页列表
        /// </summary>
        /// <param name="pagination"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        List<UserDto> GetList(BaseQueryDto request);
        /// <summary>
        /// 查询用户信息
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        UserDto GetForm(string keyValue);
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        ApplicationResult<int> DeleteForm(string keyValue);
        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="workEntity"></param>
        /// <returns></returns>
        ApplicationResult<int> Insert(SubmitUserInput inputDto);
        /// <summary>
        /// 编辑
        /// </summary>
        /// <param name="workEntity"></param>
        /// <returns></returns>
        ApplicationResult<int> Modify(SubmitUserInput inputDto, out bool shouldClearCookie);
        /// <summary>
        /// 检测相同的用户名
        /// </summary>
        /// <param name="productCode"></param>
        /// <returns></returns>
        ApplicationResult<int> CheckSameCode(string userCode);
        /// <summary>
        /// 登录验证
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        CheckLoginUserDto CheckLogin(string username, string password);
        ApplicationResult<int> RevisePassword(string keyValue, string password);
        /// <summary>
        /// 修改密码
        /// </summary>
        /// <param name="oldPassword">旧密码</param>
        /// <param name="password">新密码</param>
        /// <returns></returns>
        ApplicationResult<int> ChangePassword(string oldPassword, string password);
        /// 人员部门移动
        /// </summary>
        /// <param name="keyValueList"></param>
        /// <param name="targetDepartmentId"></param>
        /// <returns></returns>
        ApplicationResult<int> MoveDepartment(List<string> keyValueList, string targetDepartmentId);
        /// <summary>
        /// 禁用，启用
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        ApplicationResult<int> EnabledOrDisabled(string keyValue, Shared.ValidType type);
    }
}
