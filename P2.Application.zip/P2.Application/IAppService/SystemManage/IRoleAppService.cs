﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System.Collections.Generic;
using System.Linq;
using System;
using P2.Application.DTO.Output;
using AutoMapper;
using P2.Infrastructure.Enums.SystemManage;
using System.Transactions;
using P2.Application.DTO.Input;
using P2.Infrastructure.Extensions;

namespace P2.Application.IAppService
{
    public interface IRoleAppService
    {
        /// <summary>
        /// 分页列表
        /// </summary>
        /// <param name="keyword">关键词</param>
        /// <param name="showDisable">是否隐藏已禁用的数据</param>
        /// <returns></returns>
        List<RoleDto> GetList(string keyword = "", bool showDisable = true);
        /// <summary>
        /// 获取下拉绑定列表
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        List<RoleDto> GetList();
        /// <summary>
        /// 获取单个角色信息
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        RoleDto GetForm(string keyValue);
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="keyValue"></param>
        ApplicationResult<int> DeleteForm(string keyValue);
        /// <summary>
        /// 新增
        /// </summary>
        /// <param name="workEntity"></param>
        /// <returns></returns>
        ApplicationResult<int> Insert(SubmitRoleInput inputDto);
        /// <summary>
        /// 编辑
        /// </summary>
        /// <param name="workEntity"></param>
        /// <returns></returns>
        ApplicationResult<int> Modify(SubmitRoleInput inputDto);
        /// <summary>
        /// 检测该角色是否已经绑定了用户
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        bool IsBindUser(string keyValue);
    }
}
