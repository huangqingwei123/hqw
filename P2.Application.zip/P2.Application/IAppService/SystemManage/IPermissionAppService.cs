﻿using AutoMapper;
using P2.Application.DTO.Output;
using P2.Infrastructure;
using P2.Infrastructure.Model;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using P2.Infrastructure.Enums.SystemManage;

namespace P2.Application.IAppService
{
    /// <summary>
    /// 系统权限接口
    /// </summary>
    public interface IPermissionAppService
    {

        /// <summary>
        /// 通过对象ID获取所有权限
        /// </summary>
        /// <param name="ObjectId"></param>
        /// <returns></returns>
        List<PermissionDto> GetList(string ObjectId);
        /// <summary>
        /// 获取用户的菜单权限
        /// </summary>
        /// <param name="userRecordID"></param>
        /// <param name="userRoles"></param>
        /// <param name="isSystem"></param>
        /// <returns></returns>
        List<ModuleDto> GetMenuList(string userRecordID, List<string> userRoles, bool isSystem);
        /// <summary>
        /// 获取用户的按钮权限
        /// </summary>
        /// <param name="userRecordID"></param>
        /// <param name="userRoles"></param>
        /// <param name="isSystem"></param>
        /// <returns></returns>
        List<ModuleButtonDto> GetButtonList(string userRecordID, List<string> userRoles, bool isSystem);
        /// <summary>
        /// 校验权限
        /// </summary>
        /// <param name="userRecordID"></param>
        /// <param name="userRoles"></param>
        /// <param name="moduleId"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        bool ActionValidate(string userRecordID, List<string> userRoles, string moduleId, string action);
        /// <summary>
        /// 获取按钮信息
        /// </summary>
        /// <param name="userRoles"></param>
        /// <param name="moduleID"></param>
        /// <param name="location"></param>
        /// <param name="isSystem"></param>
        /// <returns></returns>
        List<ModuleButtonDto> GetModuleButtonList(string userRecordID, List<string> userRoles, string moduleID, int location = -1, bool isSystem = false);        
    }
}
