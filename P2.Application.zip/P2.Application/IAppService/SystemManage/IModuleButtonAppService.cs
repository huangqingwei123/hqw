﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using P2.Application.DTO.Output;
using AutoMapper;
using P2.Infrastructure.Extensions;
using P2.Infrastructure.Enums;
using P2.Infrastructure.Enums.SystemManage;
using P2.Application.DTO.Input;

namespace P2.Application.IAppService
{
    public interface IModuleButtonAppService
    {
        List<ModuleButtonDto> GetList(string keyword, string moduleId = "", bool showDisable = true);
        ModuleButtonDto GetForm(string keyValue);
        void DeleteForm(string keyValue);
        void SubmitForm(SubmitModuleButtonInput inputDto, string keyValue);
        void SubmitCloneButton(string moduleId, string Ids);
    }
}
