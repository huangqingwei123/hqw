﻿using P2.Application.DTO.Output;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Infrastructure;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using P2.Application.DTO.Input;

namespace P2.Application.IAppService
{
    public interface IItemsAppService
    {
        List<ItemsDataDto> GetList();
        /// <summary>
        /// 获取单条数据
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        ItemsDataDto GetForm(string keyValue);
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="keyValue"></param>
        ApplicationResult<int> DeleteForm(string keyValue);
        /// <summary>
        /// 新增提交
        /// </summary>
        /// <param name="inputDto"></param>
        /// <param name="keyValue"></param>
        ApplicationResult<int> SubmitForm(SubmitItemsInput inputDto, string keyValue);
    }
}
