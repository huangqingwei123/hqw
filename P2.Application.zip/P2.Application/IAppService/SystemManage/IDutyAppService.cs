﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using P2.Application.DTO.Output;
using System;
using P2.Application.DTO.Input;

namespace P2.Application.IAppService
{
    public interface IDutyAppService
    {
        List<RoleDto> GetList(string keyword = "");
        List<RoleDto> GetDropList();
        RoleDto GetForm(string keyValue);
        void DeleteForm(string keyValue);
        void SubmitForm(SubmitRoleInput inputDto, string keyValue);
    }
}
