﻿using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using P2.Infrastructure;
using P2.Application.DTO.Output;
using AutoMapper;
using P2.Infrastructure.Enums;
using P2.Infrastructure.Extensions;
using P2.Application.DTO.Input;

namespace P2.Application.IAppService
{
    public interface IOrganizeAppService
    {
        /// <summary>
        /// 获取组织机构列表
        /// </summary>
        /// <param name="showDisable">是否显示已禁用的数据，默认是显示</param>
        /// <param name="prentId">父节点ID</param>
        /// <param name="category">分类</param>
        /// <returns></returns>
        List<OrganizeDto> GetList(bool showDisable = true, string prentId = "", string category = "");
        /// <summary>
        /// 获取单个组织机构信息
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        OrganizeDto GetForm(string keyValue);
        /// <summary>
        /// 删除机构
        /// </summary>
        /// <param name="keyValue"></param>
        ApplicationResult<int> DeleteForm(string keyValue);
        /// <summary>
        /// 新增，修改组织机构
        /// </summary>
        /// <param name="inputDto"></param>
        /// <param name="keyValue"></param>
        void SubmitForm(SubmitOrganizeInput inputDto);
    }
}
