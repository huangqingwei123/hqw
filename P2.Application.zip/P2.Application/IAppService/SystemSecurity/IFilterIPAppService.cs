﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System.Collections.Generic;
using System.Linq;
using System;
using P2.Application.DTO.Input;

namespace P2.Application.IAppService
{
    public interface IFilterIPAppService
    {
        List<SysFilterIPEntity> GetList(string keyword);
        SysFilterIPEntity GetForm(string keyValue);
        void DeleteForm(string keyValue);
        void SubmitForm(SubmitFilterIPInput inputDto, string keyValue);
    }
}
