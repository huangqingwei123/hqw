﻿using P2.Infrastructure;
using P2.Domain.Models;
using P2.Domain.IRepositories;
using P2.Domain.Repositories;
using System;
using System.Collections.Generic;
using P2.Application.DTO.Output;

namespace P2.Application.IAppService
{
    public interface ILogAppService
    {
        List<LogDto> GetList(Pagination pagination, string queryJson);
        void RemoveLog(string keepTime);
        void WriteDbLog(bool result, string resultLog);
        void WriteDbLog(LogDto logEntity);
    }
}
