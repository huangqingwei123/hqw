﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;
using AutoMapper.Configuration;
using P2.Application.DTO.Output;
using P2.Domain.Models;
using P2.Application.DTO.Input;
using P2.Application.DTO;

namespace P2.Application
{
    public class AutoMapperConfig
    {
        public static void Initialize()
        {
            var cfg = new MapperConfigurationExpression();

            #region 系统管理

            cfg.CreateMap<OrganizeDto, SysOrganizeEntity>();
            cfg.CreateMap<SysOrganizeEntity, OrganizeDto>();
            cfg.CreateMap<SysOrganizeManagersEntity, OrganizeManagersDto>();
            cfg.CreateMap<OrganizeManagersDto, SysOrganizeManagersEntity>();

            cfg.CreateMap<RoleDto, SysRoleEntity>();
            cfg.CreateMap<SysRoleEntity, RoleDto>();

            cfg.CreateMap<ModuleDto, SysModuleEntity>();
            cfg.CreateMap<SysModuleEntity, ModuleDto>();

            cfg.CreateMap<SysUserEntity, UserDto>();
            cfg.CreateMap<SysUserRoleEntity, UserRoleDto>();
            cfg.CreateMap<SysUserEntity, CheckLoginUserDto>();
            cfg.CreateMap<UserDto, UserExportDto>();

            cfg.CreateMap<ModuleButtonDto, SysModuleButtonEntity>();
            cfg.CreateMap<SysModuleButtonEntity, ModuleButtonDto>();

            cfg.CreateMap<SysItemsEntity, ItemsDataDto>();
            cfg.CreateMap<ItemsDataDto, SysItemsEntity>();

            cfg.CreateMap<SysItemsEntity, ItemsDataDto>();
            cfg.CreateMap<ItemsDataDto, SysItemsEntity>();

            cfg.CreateMap<SysItemsDetailEntity, ItemsDetailDto>();
            cfg.CreateMap<ItemsDetailDto, SysItemsDetailEntity>();

            cfg.CreateMap<SubmitRoleInput, SysRoleEntity>();
            cfg.CreateMap<SubmitItemsInput, SysItemsEntity>();
            cfg.CreateMap<SubmitItemsDetailInput, SysItemsDetailEntity>();
            cfg.CreateMap<SubmitModuleInput, SysModuleEntity>();
            cfg.CreateMap<SubmitModuleButtonInput, SysModuleButtonEntity>();
            cfg.CreateMap<SubmitOrganizeInput, SysOrganizeEntity>();
            cfg.CreateMap<SubmitFilterIPInput, SysFilterIPEntity>();            

            #endregion

            Mapper.Initialize(cfg);
        }
    }
}