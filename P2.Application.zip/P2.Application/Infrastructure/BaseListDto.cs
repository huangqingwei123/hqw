﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Application
{
    public class BaseListDto
    {
        /// <summary>
        /// 列表操作按钮Html字符串
        /// </summary>
        public string ButtonText { get; set; }
    }
}
