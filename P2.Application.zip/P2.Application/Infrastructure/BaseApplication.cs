﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using P2.Infrastructure;

namespace P2.Application
{
    public class BaseApplication<T>
    {        
        /// <summary>
        /// 执行成功时返回
        /// </summary>
        /// <param name="message">提示语</param>
        /// <returns></returns>
        public ApplicationResult<T> Success(string message)
        {
            return new ApplicationResult<T>()
            {
                status = ResultCode.success,
                message = message
            };
        }

        /// <summary>
        /// 执行成功时返回
        /// </summary>
        /// <param name="message">提示语</param>
        /// <param name="data">数据</param>
        /// <returns></returns>
        public ApplicationResult<T> Success(string message,T data)
        {
            return new ApplicationResult<T>()
            {
                status = ResultCode.success,
                message = message,
                data = data
            };
        }

        /// <summary>
        /// 执行失败时返回
        /// </summary>
        /// <param name="message">失败提示语</param>
        /// <returns></returns>
        public ApplicationResult<T> Error(string message)
        {
            return new ApplicationResult<T>()
            {
                status = ResultCode.error,
                message = message
            };
        }

        /// <summary>
        /// 异常请求时返回
        /// </summary>
        /// <param name="message">提示语</param>
        /// <returns></returns>
        public ApplicationResult<T> Invalid(string message)
        {
            return new ApplicationResult<T>()
            {
                status = ResultCode.invalid,
                message = message
            };
        }
    }
}
