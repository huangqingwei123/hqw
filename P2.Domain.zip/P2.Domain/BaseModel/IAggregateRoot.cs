﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Domain.BaseModel
{
    public interface IAggregateRoot : IEntity
    {
        
    }
}
