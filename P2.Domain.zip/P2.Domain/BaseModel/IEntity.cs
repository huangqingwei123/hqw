﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Domain.BaseModel
{
    /// <summary>
    /// 继承该接口的类型为领域实体
    /// </summary>
    public interface IEntity
    {
        
    }
}
