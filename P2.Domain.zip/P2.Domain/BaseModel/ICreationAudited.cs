﻿using System;

namespace P2.Domain.BaseModel
{
    public interface ICreationAudited
    {
        string Id { get; set; }
        string AddUserId { get; set; }
        DateTime? AddTime { get; set; }
    }
}