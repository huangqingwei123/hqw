﻿using P2.Infrastructure;
using System;

namespace P2.Domain.BaseModel
{
    public class Entity : IEntity
    {
        
    }
}
