﻿using System;
using System.Collections.Generic;
using P2.Domain;
using P2.Domain.BaseModel;

namespace P2.Domain.Models
{
    /// <summary>
    /// 数据字典详细表
    /// </summary>
    public class SysItemsDetailEntity : AggregateRoot, ICreationAudited, IModificationAudited, IDeleteAudited
    {
        /// <summary>
        /// 明细主键
        /// </summary>        
        public string Id { get; set; }
        /// <summary>
        /// 主表主键
        /// </summary>        
        public string ItemId { get; set; }
        /// <summary>
        /// 父级
        /// </summary>        
        public string ParentId { get; set; }
        /// <summary>
        /// 编码
        /// </summary>        
        public string ItemCode { get; set; }
        /// <summary>
        /// 名称
        /// </summary>        
        public string ItemName { get; set; }
        /// <summary>
        /// 简拼
        /// </summary>        
        public string SimpleSpelling { get; set; }
        /// <summary>
        /// 默认
        /// </summary>        
        public bool IsDefault { get; set; }
        /// <summary>
        /// 层次
        /// </summary>        
        public int Layers { get; set; }
        /// <summary>
        /// 排序码
        /// </summary>        
        public int SortCode { get; set; }
        /// <summary>
        /// 删除标志
        /// </summary>        
        public bool DeleteMark { get; set; }
        /// <summary>
        /// 有效标志
        /// </summary>        
        public bool EnabledMark { get; set; }
        /// <summary>
        /// 描述
        /// </summary>        
        public string Description { get; set; }
        /// <summary>
        /// 创建日期
        /// </summary>        
        public DateTime? AddTime { get; set; }
        /// <summary>
        /// 创建用户主键
        /// </summary>        
        public string AddUserId { get; set; }
        /// <summary>
        /// 最后修改时间
        /// </summary>        
        public DateTime? LastModifyTime { get; set; }
        /// <summary>
        /// 最后修改用户
        /// </summary>        
        public string LastModifyUserId { get; set; }
        /// <summary>
        /// 删除时间
        /// </summary>        
        public DateTime? DeleteTime { get; set; }
        /// <summary>
        /// 删除用户
        /// </summary>        
        public string DeleteUserId { get; set; }
        public virtual SysItemsEntity Items { get; set; }
    }
}
