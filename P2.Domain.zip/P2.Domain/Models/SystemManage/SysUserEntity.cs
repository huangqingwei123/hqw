﻿using System;
using System.Collections.Generic;
using P2.Infrastructure.Extensions;
using P2.Infrastructure.Enums;
using P2.Domain.BaseModel;

namespace P2.Domain.Models
{
    public class SysUserEntity : AggregateRoot
    {
        public SysUserEntity()
        {
            this.RoleList = new List<SysUserRoleEntity>();
        }
        /// <summary>
        /// 主键
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 账户
        /// </summary>
        public string Account { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }
        /// <summary>
        /// 姓名
        /// </summary>
        public string RealName { get; set; }
        /// <summary>
        /// 昵称
        /// </summary>
        public string NickName { get; set; }
        /// <summary>
        /// 头像
        /// </summary>
        public string HeadIcon { get; set; }
        /// <summary>
        /// 0：男，1：女
        /// </summary>
        public bool Gender { get; set; }
        /// <summary>
        /// 生日
        /// </summary>
        public DateTime? Birthday { get; set; }
        /// <summary>
        /// 手机号码
        /// </summary>
        public string MobilePhone { get; set; }
        /// <summary>
        /// 邮箱地址
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// 微信
        /// </summary>
        public string WeChat { get; set; }
        /// <summary>
        /// 主管主键
        /// </summary>
        public string ManagerId { get; set; }
        /// <summary>
        /// 安全等级
        /// </summary>
        public int? SecurityLevel { get; set; }
        /// <summary>
        /// 个性签名
        /// </summary>
        public string Signature { get; set; }
        /// <summary>
        /// 所属部门
        /// </summary>
        public string DepartmentId { get; set; }
        /// <summary>
        /// 岗位主键
        /// </summary>
        public string DutyId { get; set; }
        /// <summary>
        /// 是否为管理员
        /// </summary>
        public bool IsAdministrator { get; set; }
        /// <summary>
        /// 排序码
        /// </summary>
        public int SortCode { get; set; }
        /// <summary>
        /// 删除标记
        /// </summary>
        public bool DeleteMark { get; set; }
        /// <summary>
        /// 可用标记
        /// </summary>
        public bool EnabledMark { get; set; }
        /// <summary>
        /// 描述
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// 入职日期
        /// </summary>        
        public DateTime? EntryDate { get; set; }
        /// <summary>
        /// 转正日期
        /// </summary>        
        public DateTime? TurnPositiveDate { get; set; }
        /// <summary>
        /// 离职日期
        /// </summary>        
        public DateTime? DimissionDate { get; set; }
        /// <summary>
        /// 企业工号
        /// </summary>        
        public string EnterpriseJobNumber { get; set; }
        /// <summary>
        /// 籍贯
        /// </summary>        
        public string Birthplace { get; set; }
        /// <summary>
        /// 身份证
        /// </summary>        
        public string IDNumber { get; set; }
        /// <summary>
        /// 学历
        /// </summary>        
        public string EducationalBackground { get; set; }
        /// <summary>
        /// 计薪规则
        /// </summary>
        public string CalculateSalaryRule { get; set; }
        /// <summary>
        /// 个人电脑号
        /// </summary>
        public string PersonalPCNo { get; set; }
        /// <summary>
        /// 个人公积金账号
        /// </summary>
        public string PersonalProvidentFundAccount { get; set; }
        public DateTime? CreatorTime { get; set; }
        public string CreatorUserId { get; set; }
        public DateTime? LastModifyTime { get; set; }
        public string LastModifyUserId { get; set; }
        public DateTime? DeleteTime { get; set; }
        public string DeleteUserId { get; set; }
        /// <summary>
        /// 用户角色
        /// </summary>
        public virtual List<SysUserRoleEntity> RoleList { get; set; }
    }
}