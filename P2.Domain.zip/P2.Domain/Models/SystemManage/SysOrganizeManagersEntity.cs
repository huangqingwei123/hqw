﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using P2.Infrastructure.Extensions;
using P2.Domain.BaseModel;

namespace P2.Domain.Models
{
    /// <summary>
    ///组织机构负责人表
    /// </summary>
    [Table("Sys_OrganizeManagers")]
    public class SysOrganizeManagersEntity : AggregateRoot
    {
        /// <summary>
        /// 主键
        /// </summary>        
        public string Id { get; set; }
        /// <summary>
        /// 组织机构主键
        /// </summary>        
        public string OrganizeId { get; set; }
        /// <summary>
        /// 负责人主键
        /// </summary>        
        public string ManagerId { get; set; }
        /// <summary>
        /// 删除标记（0：否，1：是）
        /// </summary>        
        public bool DeleteMark { get; set; }
        /// <summary>
        /// 添加时间
        /// </summary>        
        public DateTime? AddTime { get; set; }
        /// <summary>
        /// 添加人
        /// </summary>        
        public string AddUserId { get; set; }
        public virtual SysOrganizeEntity Organize { get; set; }
    }
}

