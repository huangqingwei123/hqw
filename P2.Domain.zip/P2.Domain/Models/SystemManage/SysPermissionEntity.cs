﻿using P2.Domain.BaseModel;
using P2.Infrastructure.Enums.SystemManage;
using System;

namespace P2.Domain.Models
{
    public class SysPermissionEntity : AggregateRoot
    {
        /// <summary>
        /// 角色授权主键
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 项目类型1-模块2-按钮3-列表
        /// </summary>
        public PermissionEnum.ItemTypeEnum ItemType { get; set; }
        /// <summary>
        /// 项目主键
        /// </summary>
        public string ItemId { get; set; }
        /// <summary>
        /// 对象分类
        /// 1-角色2-用户-3部门
        /// </summary>
        public PermissionEnum.ObjectTypeEnum ObjectType { get; set; }
        /// <summary>
        /// 对象主键
        /// </summary>
        public string ObjectId { get; set; }
        /// <summary>
        /// 排序码
        /// </summary>
        public int SortCode { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>
        public DateTime? AddTime { get; set; }
        /// <summary>
        /// 创建用户
        /// </summary>
        public string AddUserID { get; set; }
    }
}
