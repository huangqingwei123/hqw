﻿using P2.Domain.BaseModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P2.Domain.Models
{
    public class SysUserRoleEntity : AggregateRoot, ICreationAudited
    {
        /// <summary>
        /// 主键
        /// </summary>
        public string Id { get; set; }
        /// <summary>
        /// 用户主键
        /// </summary>
        public string UserId { get; set; }
        /// <summary>
        /// 角色主键
        /// </summary>
        public string RoleId { get; set; }
        /// <summary>
        /// 创建时间
        /// </summary>        
        public DateTime? AddTime { get; set; }
        /// <summary>
        /// 创建用户
        /// </summary>        
        public string AddUserId { get; set; }
        /// <summary>
        /// 用户
        /// </summary>
        public virtual SysUserEntity User { get; set; }
    }
}
