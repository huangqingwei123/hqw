﻿using P2.Infrastructure;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Linq.Expressions;
using P2.Infrastructure.Enums;
using P2.Domain.BaseModel;

namespace P2.Domain.IRepositories
{
    /// <summary>
    /// 仓储接口
    /// </summary>
    /// <typeparam name="TAggregateRoot">实体类型</typeparam>
    public interface IRepository<TAggregateRoot> where TAggregateRoot : IAggregateRoot
    {
        void Insert(TAggregateRoot aggregateRoot);        
        void Update(TAggregateRoot aggregateRoot);        
        void Remove(TAggregateRoot aggregateRoot);
        void Remove(Expression<Func<TAggregateRoot, bool>> predicate);
        TAggregateRoot FindEntity(Expression<Func<TAggregateRoot, bool>> predicate);
        IQueryable<TAggregateRoot> IQueryable();
        IQueryable<TAggregateRoot> IQueryable(Expression<Func<TAggregateRoot, bool>> predicate);
        IEnumerable<TAggregateRoot> GetAll(Expression<Func<TAggregateRoot, bool>> predicate, Expression<Func<TAggregateRoot, dynamic>> sortPredicate, Shared.SortOrder sortOrder);
        IEnumerable<TAggregateRoot> GetAll(Expression<Func<TAggregateRoot, bool>> predicate, params Expression<Func<TAggregateRoot, dynamic>>[] eagerLoadingProperties);
        IEnumerable<TAggregateRoot> GetAll(Expression<Func<TAggregateRoot, bool>> predicate, Expression<Func<TAggregateRoot, dynamic>> sortPredicate,
            Shared.SortOrder sortOrder, params Expression<Func<TAggregateRoot, dynamic>>[] eagerLoadingProperties);
        IEnumerable<TAggregateRoot> GetAll(Expression<Func<TAggregateRoot, bool>> predicate, Pagination pagination, Expression<Func<TAggregateRoot, dynamic>> sortPredicate,
            Shared.SortOrder sortOrder, params Expression<Func<TAggregateRoot, dynamic>>[] eagerLoadingProperties);
    }
}
