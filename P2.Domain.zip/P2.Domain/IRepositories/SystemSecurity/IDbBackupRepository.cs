﻿using P2.Domain.Models;

namespace P2.Domain.IRepositories
{
    public interface IDbBackupRepository : IRepository<SysDbBackupEntity>
    {
        void DeleteForm(string keyValue);
        void ExecuteDbBackup(SysDbBackupEntity dbBackupEntity);
    }
}
