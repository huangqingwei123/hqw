﻿using P2.Domain.Models;

namespace P2.Domain.IRepositories
{
    public interface IModuleRepository : IRepository<SysModuleEntity>
    {
    }
}
