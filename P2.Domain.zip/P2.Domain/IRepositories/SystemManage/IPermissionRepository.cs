﻿using P2.Domain.Models;

namespace P2.Domain.IRepositories
{
    public interface IPermissionRepository : IRepository<SysPermissionEntity>
    {
    }
}
