﻿using P2.Domain.Models;
using System.Collections.Generic;

namespace P2.Domain.IRepositories
{
    public interface IRoleRepository : IRepository<SysRoleEntity>
    {
        
    }
}
