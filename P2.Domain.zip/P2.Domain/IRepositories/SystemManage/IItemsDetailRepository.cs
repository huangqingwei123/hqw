﻿using P2.Domain.Models;
using System.Collections.Generic;

namespace P2.Domain.IRepositories
{
    public interface IItemsDetailRepository : IRepository<SysItemsDetailEntity>
    {
        List<SysItemsDetailEntity> GetItemList(string enCode);
    }
}
