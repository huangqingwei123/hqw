﻿using P2.Domain.Models;

namespace P2.Domain.IRepositories
{
    public interface IUserRepository : IRepository<SysUserEntity>
    {        
        bool CheckSamName(string userCode, bool isAdd, string userID = "");
        void RemoveUserAuthorizeCache(string roleId = "", string userId = "");
    }
}
