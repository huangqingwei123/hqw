﻿using P2.QuartzServer;
using System;
using System.IO;
using Topshelf;

namespace P2.QuartzServer
{
    class Program
    {
        static void Main(string[] args)
        {
            log4net.Config.XmlConfigurator.ConfigureAndWatch(new FileInfo(AppDomain.CurrentDomain.BaseDirectory + "log4net.config"));
            AutofacConfig.Register();
            HostFactory.Run(x =>
            {
                x.UseLog4Net();

                x.Service<ServiceRunner>();

                x.RunAsLocalSystem();

                x.SetDescription("P2.QuartzServer实现Windows服务作业调度");
                x.SetDisplayName("P2.QuartzServer服务");
                x.SetServiceName("P2.QuartzServer");

                x.EnablePauseAndContinue();

            });
        }
    }
}
