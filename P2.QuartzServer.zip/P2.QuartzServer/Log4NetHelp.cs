﻿using System;
using System.Data;
using System.IO;
using System.Text;
using log4net;
using log4net.Appender;
using log4net.Config;
using log4net.Layout;
using log4net.Repository;
using log4net.Repository.Hierarchy;
using System.Configuration;
using log4net.Core;
namespace P2.QuartzServer
{
    /// <summary>
    /// 重新封装
    /// </summary>
    public class Log4NetHelp
    {
        #region 变量定义
        /// <summary>
        /// 手动加载配置中的信息模板
        /// </summary>
        public static string ConversionPattern = "【记录时间】%date%n【描述】%message%n%n";
        //常用LoggerName
        private const string FatalLogger = "Fatal";
        private const string ErrorLogger = "Error";
        private const string WarnLogger = "Warn";
        private const string InfoLogger = "Info";
        private const string DebugLogger = "Debug";
        #endregion

        #region 封装Log4net
        /// <summary>
        /// 
        /// </summary>
        ///  
        public static void Debug(object message)
        {
            var log = LogManager.GetLogger(DebugLogger);
            if (log.IsDebugEnabled)
            {
                log.Debug(message);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        ///  
        public static void Debug(object message, Exception ex)
        {
            var log = LogManager.GetLogger(DebugLogger);
            if (log.IsDebugEnabled)
            {
                log.Debug(message, ex);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        public static void DebugFormat(string format, params object[] args)
        {
            var log = LogManager.GetLogger(DebugLogger);
            if (log.IsDebugEnabled)
            {
                log.DebugFormat(format, args);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        public static void Error(object message)
        {
            var log = LogManager.GetLogger(ErrorLogger);
            if (log.IsErrorEnabled)
            {
                log.Error(message);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        public static void Error(object message, Exception ex)
        {
            var log = LogManager.GetLogger(ErrorLogger);
            if (log.IsErrorEnabled)
            {
                log.Error(message, ex);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        public static void ErrorFormat(string format, params object[] args)
        {
            var log = LogManager.GetLogger(ErrorLogger);
            if (log.IsErrorEnabled)
            {
                log.ErrorFormat(format, args);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        public static void Fatal(object message)
        {
            var log = LogManager.GetLogger(FatalLogger);
            if (log.IsFatalEnabled)
            {
                log.Fatal(message);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        public static void Fatal(object message, Exception ex)
        {
            var log = LogManager.GetLogger(FatalLogger);
            if (log.IsFatalEnabled)
            {
                log.Fatal(message, ex);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        ///  
        public static void FatalFormat(string format, params object[] args)
        {
            var log = LogManager.GetLogger(FatalLogger);
            if (log.IsFatalEnabled)
            {
                log.FatalFormat(format, args);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        ///  
        public static void Info(object message)
        {
            var log = LogManager.GetLogger(InfoLogger);
            if (log.IsInfoEnabled)
            {
                log.Info(message);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        public static void Info(object message, Exception ex)
        {
            var log = LogManager.GetLogger(InfoLogger);
            if (log.IsInfoEnabled)
            {
                log.Info(message, ex);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// 
        public static void InfoFormat(string format, params object[] args)
        {
            var log = LogManager.GetLogger(InfoLogger);
            if (log.IsInfoEnabled)
            {
                log.InfoFormat(format, args);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        ///  
        public static void Warn(object message)
        {
            var log = LogManager.GetLogger(WarnLogger);
            if (log.IsWarnEnabled)
            {
                log.Warn(message);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        ///  
        public static void Warn(object message, Exception ex)
        {
            var log = LogManager.GetLogger(WarnLogger);
            if (log.IsWarnEnabled)
            {
                log.Warn(message, ex);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        ///  
        public static void WarnFormat(string format, params object[] args)
        {
            var log = LogManager.GetLogger(WarnLogger);
            if (log.IsWarnEnabled)
            {
                log.WarnFormat(format, args);
            }
        }
        #endregion

        #region 手动加载配置
        /// <summary>
        /// 代码指定配置文件，以及监视文件改变
        /// </summary>
        /// <param name="path">配置文件路径</param>
        /// <param name="isWatch">是否监视</param>
        public static void LoadConfig(string path, bool isWatch = false)
        {
            if (isWatch) XmlConfigurator.ConfigureAndWatch(new FileInfo(path));
            else XmlConfigurator.Configure(new FileInfo(path));
        }

        /// <summary>
        /// 加载文件Appender
        /// </summary>
        public static void LoadFileAppender(ILoggerRepository repository = null)
        {
            FileAppender appender = new FileAppender();
            appender.Name = "FileAppender";
            appender.File = repository == null ? "程序日志.log" : repository.Name + ".log";
            appender.AppendToFile = true;
            appender.Encoding = Encoding.UTF8;
            LoadLayout(appender, repository: repository);
        }

        /// <summary>
        /// 加载滚动文件Appender
        /// </summary>
        public static void LoadRollingFileAppender(ILoggerRepository repository = null)
        {
            RollingFileAppender appender = new RollingFileAppender();
            appender.AppendToFile = true;
            appender.Name = "RollingFileAppender";

            //若配置了repository 则使用静态日志文件名
            if (repository != null)
            {
                appender.RollingStyle = RollingFileAppender.RollingMode.Size;
                appender.File = "Log/"+ System.DateTime.Now.ToString("yyyy-MM-dd") +"[" + repository.Name + "]" + ".log";
                appender.StaticLogFileName = true;
            }
            else
            {
                appender.File = "Log/";
                appender.DatePattern = "yyyy-MM-dd HH'.log'";
                appender.StaticLogFileName = false;
            }

            appender.AppendToFile = true;
            appender.RollingStyle = RollingFileAppender.RollingMode.Composite;
            appender.MaximumFileSize = "10024kb";
            appender.MaxSizeRollBackups = 1;
            appender.Encoding = Encoding.UTF8;
            LoadLayout(appender, repository: repository);
        }

        /// <summary>
        /// 加载控制台Appender
        /// </summary>
        public static void LoadConsoleAppender(ILoggerRepository repository = null)
        {
            ConsoleAppender appender = new ConsoleAppender();
            appender.Name = "ConsoleAppender";
            LoadLayout(appender, repository: repository);
        }

        /// <summary>
        /// 加载调试Appender
        /// </summary>
        public static void LoadTraceAppender(ILoggerRepository repository = null)
        {
            TraceAppender appender = new TraceAppender();
            appender.Name = "TraceAppender";
            LoadLayout(appender, "%message", repository);
        }

        /// <summary>
        /// 加载WindowEvent Appender(指定来源以及日志名称，便于其他程序读取)
        /// </summary>
        /// <param name="applicationName">来源</param>
        /// <param name="logName">日志名称</param>
        /// <remarks>当日志信息写入过快，容易发生异常</remarks>
        public static void LoadEventLogAppender(string applicationName, string logName)
        {
            EventLogAppender appender = new EventLogAppender();
            appender.Name = "EventLogAppender";
            appender.ApplicationName = applicationName;
            appender.LogName = logName;
            LoadLayout(appender, "%message");
        }

        private static void LoadLayout(AppenderSkeleton appender, string conversionPattern = "【记录时间】%date%n【描述】%message%n%n", ILoggerRepository repository = null)
        {
            if (appender == null) return;

            var patternLayout = new PatternLayout();
            patternLayout.ConversionPattern = conversionPattern;
            patternLayout.ActivateOptions();
            appender.Layout = patternLayout;
            appender.ActivateOptions();

            if (repository != null) BasicConfigurator.Configure(repository, appender);
            else BasicConfigurator.Configure(appender);
        }
        #endregion
        /// <summary>
        /// 
        /// </summary>
        /// 
        public static ILog GetLogger(string repositoryName = "")
        {
            if (string.IsNullOrEmpty(repositoryName)) return LogManager.GetLogger("Defalut");

            ILoggerRepository repository = null;
            try
            {
                repository = LogManager.GetRepository(repositoryName);
            }
            catch (Exception) { }

            //找到直接返回ilog
            if (repository != null)
                return LogManager.GetLogger(repositoryName, "Defalut");

            //未找到则创建，多线程下很有可能创建时，就存在了
            try
            {
                repository = LogManager.CreateRepository(repositoryName);
            }
            catch (Exception)
            {
                repository = LogManager.GetRepository(repositoryName);
            }

            //配置日志等级  读取Appsettings默认配置  
            var appSet = ConfigurationManager.AppSettings.AllKeys;

            //查找日志等级
            const string logLevel = "LogLevel";
            var hasSettings = Array.IndexOf(appSet, logLevel);
            if (hasSettings > -1)
            {
                var level = ConfigurationManager.AppSettings[logLevel].ToLower();
                if (level == "all") repository.Threshold = Level.All;
                else if (level == "debug") repository.Threshold = Level.Debug;
                else if (level == "info") repository.Threshold = Level.Info;
                else if (level == "warn") repository.Threshold = Level.Warn;
                else if (level == "error") repository.Threshold = Level.Error;
                else if (level == "fatal") repository.Threshold = Level.Fatal;
                else if (level == "off") repository.Threshold = Level.Off;
            }
            else repository.Threshold = Level.All;

            //查找输出Appender
            const string logAppender = "LogAppender";
            hasSettings = Array.IndexOf(appSet, logAppender);
            if (hasSettings > -1)
            {
                var appenders = ConfigurationManager.AppSettings[logAppender].ToLower().Split(',');
                foreach (var appender in appenders)
                {
                    if (appender == "rollingfile") LoadRollingFileAppender(repository);
                    else if (appender == "console") LoadConsoleAppender(repository);
                    else if (appender == "trace") LoadTraceAppender(repository);
                }
            }
            else LoadRollingFileAppender(repository);

            return LogManager.GetLogger(repositoryName, "Default");
        }
    }
}
