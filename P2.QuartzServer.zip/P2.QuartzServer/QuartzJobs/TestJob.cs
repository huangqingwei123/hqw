﻿using Autofac;
using Quartz;
using P2.Application.IAppService;

namespace P2.QuartzServer.QuartzJobs
{
    public sealed class TestJob : IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            //服务定位器方法示例
            var userAppService = AutofacConfig.Container.Resolve<IUserAppService>();
            var user = userAppService.GetForm("4be0ae03e2354dabb5f5247687462b88");
            CommonHelper.AppLogger.InfoFormat("TestJob测试");
        }
    }
}
