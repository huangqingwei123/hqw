﻿using log4net;

namespace P2.QuartzServer
{
    class CommonHelper
    {        
        public static readonly ILog AppLogger = LogManager.GetLogger("ColoredConsoleAppender");

        static CommonHelper()
        {

        }

    }
}
