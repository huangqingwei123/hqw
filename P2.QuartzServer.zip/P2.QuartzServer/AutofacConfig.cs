﻿using Autofac;
using System.Reflection;

namespace P2.QuartzServer
{
    public class AutofacConfig
    {
        public static IContainer Container;
        public static void Register()
        {
            var builder = new ContainerBuilder();

            SetupResolveRules(builder);

            Container = builder.Build();
        }

        public static void SetupResolveRules(ContainerBuilder builder)
        {
            builder.RegisterAssemblyTypes(Assembly.Load("P2.Domain.Repositories"))
                .Where(t => t.Name.EndsWith("Repository"))
                .AsImplementedInterfaces()
                .InstancePerLifetimeScope();

            builder.RegisterAssemblyTypes(Assembly.Load("P2.Application"))
                .Where(t => t.Name.EndsWith("AppService"))
                .AsImplementedInterfaces()
                .InstancePerLifetimeScope();

            builder.RegisterType(Assembly.Load("P2.Domain.Repositories").GetType("P2.Domain.Repositories.EntityFramework.EntityFrameworkRepositoryContext"))
                .As(Assembly.Load("P2.Domain").GetType("P2.Domain.IRepositories.IRepositoryContext")).InstancePerLifetimeScope();
        }
    }
}
