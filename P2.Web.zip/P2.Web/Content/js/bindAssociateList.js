﻿//账号关键词联想下拉数据绑定
$.fn.bindClientList = function (_options) {
    $this = $(this);
    var isSubmited = false;
    $this.unbind("keyup").bind("keyup", function (e) {
        if (!!e && !!e.keyCode) {
            if (!isSubmited) {
                if (e.keyCode < 47 && e.keyCode != 8) return;
                $this = $(this);
                $thisDrop = $($this.next('datalist'));
                var defaults = {
                    url: "/AmazonRemovalManage/Tracking/GetClientList",
                    dataSize: 10,
                    data: {},
                    datatype: "json",
                    success: function (result) {
                        var data = eval('(' + result + ')');
                        if (!!data) {
                            for (var i = 0; i < data.length; i++) {
                                var Client = data[i].SellerID;
                                $thisDrop.append("<option value='" + Client + "'>" + Client + "</option>");
                            }
                        }
                    },
                    complete: function () {
                        isSubmited = false;
                    },
                };
                var options = $.extend(defaults, _options);
                $thisDrop.empty();
                options.data["dataSize"] = options.dataSize;
                options.data["keyword"] = $this.val();
                isSubmited = true;
                $.ajax(options);
            }
        }
    })
}

//店铺关键词联想下拉数据绑定
$.fn.bindShopList = function (_options) {
    $this = $(this);
    var isSubmited = false;
    $this.unbind("keyup").bind("keyup", function (e) {
        if (!!e && !!e.keyCode) {
            if (!isSubmited) {
                if (e.keyCode < 47 && e.keyCode != 8) return;
                $this = $(this);
                $thisDrop = $($this.next('datalist'));
                var defaults = {
                    url: "/OverSeaBusinessDataManage/Shop/GetShopList",
                    dataSize: 10,
                    data: {},
                    datatype: "json",
                    success: function (result) {
                        var data = eval('(' + result + ')');
                        if (!!data) {
                            for (var i = 0; i < data.length; i++) {
                                var ShopName = data[i].ShopName;
                                $thisDrop.append("<option value='" + ShopName + "'>" + ShopName + "</option>");
                            }
                        }
                    },
                    complete: function () {
                        isSubmited = false;
                    },
                };
                var options = $.extend(defaults, _options);
                $thisDrop.empty();
                options.data["dataSize"] = options.dataSize;
                options.data["keyword"] = $this.val();
                isSubmited = true;
                $.ajax(options);
            }
        }
    })
}