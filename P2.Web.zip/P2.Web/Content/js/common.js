﻿//去除文本内容中的HTML标签
replaceHTML=function(str) {
    str = str.replace(/<[^>].*?>/g, "");
    str = str.replace(/ /g, "");
    return str;
}
function DoPostAjax(url, sendData, func, dataType, async) {
    if (async != undefined && async != null) {
        async = false;
    }
    $.ajax({
        type: "POST",
        url: url,
        cache: false,
        dataType: !dataType ? 'json' : dataType,
        async: async,
        data: sendData,
        success: function (msg) {
            func(msg);
        },
        complete: function (msg) {
            //debugger;
        },
        error: function (msg) {
            //debugger;
            alert("程序异常，请联系管理员！");
        }
    });
}

function getNowFormatDate() {
    var date = new Date();
    var seperator1 = "-";
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = year + seperator1 + month + seperator1 + strDate;
    return currentdate;
}