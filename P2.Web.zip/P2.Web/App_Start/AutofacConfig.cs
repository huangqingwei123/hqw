﻿using Autofac;
using Autofac.Integration.Mvc;
using P2.Application.AppService;
using P2.Application.IAppService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace P2.Web
{
    /// <summary>
    /// 将仓储，服务注入Autofac容器
    /// </summary>
    public class AutofacConfig
    {
        public static IContainer Container;
        public static void Register()
        {
            var builder = new ContainerBuilder();

            builder.RegisterControllers(Assembly.GetCallingAssembly());

            SetupResolveRules(builder);

            var container = builder.Build();
            Container = container;
            DependencyResolver.SetResolver(new AutofacDependencyResolver(container));
        }

        public static void SetupResolveRules(ContainerBuilder builder)
        {
            builder.RegisterAssemblyTypes(Assembly.Load("P2.Domain.Repositories"))
                .Where(t => t.Name.EndsWith("Repository"))
                .AsImplementedInterfaces()
                .InstancePerLifetimeScope();

            builder.RegisterAssemblyTypes(Assembly.Load("P2.Application"))
                .Where(t => t.Name.EndsWith("AppService"))
                .AsImplementedInterfaces()
                .InstancePerLifetimeScope();

            builder.RegisterType(Assembly.Load("P2.Domain.Repositories").GetType("P2.Domain.Repositories.EntityFramework.EntityFrameworkRepositoryContext"))
                .As(Assembly.Load("P2.Domain").GetType("P2.Domain.IRepositories.IRepositoryContext")).InstancePerLifetimeScope();
        }
    }
}