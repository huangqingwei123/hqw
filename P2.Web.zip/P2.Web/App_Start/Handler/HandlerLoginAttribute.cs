﻿using P2.Infrastructure;
using System.Web.Mvc;
using System.Web.SessionState;

namespace P2.Web
{
    public class HandlerLoginAttribute : AuthorizeAttribute
    {
        public bool Ignore = true;
        public HandlerLoginAttribute(bool ignore = true)
        {
            Ignore = ignore;
        }
        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            if (Ignore == false)
            {
                return;
            }            
            var operatorInstace = OperatorProvider.Provider;            
            if (!operatorInstace.IsLogin)
            {
                WebHelper.WriteCookie("cookie_login_error", "overdue");
                filterContext.HttpContext.Response.Write("<script>top.location.href = '/Login/Index';</script>");
                return;
            }
            operatorInstace.ExtendTime();

            var Session = System.Web.HttpContext.Current.Session;
            if (Session != null && Session["Culture"] != null)
            {
                var id = System.Threading.Thread.CurrentThread.ManagedThreadId;
                System.Threading.Thread.CurrentThread.CurrentCulture = (System.Globalization.CultureInfo)Session["Culture"];
                System.Threading.Thread.CurrentThread.CurrentUICulture = (System.Globalization.CultureInfo)Session["Culture"];
            }
        }
    }
}