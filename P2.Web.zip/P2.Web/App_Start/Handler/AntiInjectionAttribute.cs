﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace P2.Web
{
    public class AntiInjectionAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var request = filterContext.RequestContext.HttpContext.Request.QueryString as NameValueCollection;                        

            var arguments = filterContext.ActionParameters;
            var newArgu = new Dictionary<string,object>();

            //filterContext.HttpContext.Response.Redirect("/SystemManage/Store/Index");            
        }
    }
}