﻿using P2.Application.IAppService;
using P2.Application.SystemManage;
using P2.Infrastructure;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Autofac;

namespace P2.Web
{
    public class HandlerAuthorizeAttribute : ActionFilterAttribute
    {
        private IPermissionAppService permissionAppService;

        public bool Ignore { get; set; }
        public HandlerAuthorizeAttribute(bool ignore = true)
        {
            Ignore = ignore;
        }
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (OperatorProvider.Provider.GetCurrent().IsSystem)
            {
                return;
            }
            if (Ignore == false)
            {
                return;
            }
            var isAjax = filterContext.RequestContext.HttpContext.Request.IsAjaxRequest();//当前请求是否为Ajax
            if (!this.ActionAuthorize(filterContext))
            {
                if (isAjax)
                {
                    filterContext.Result = new ContentResult() { Content = new AjaxResult { state = ResultType.error.ToString(), message = "很抱歉！您的权限不足，访问被拒绝！" }.ToJson() };
                    return;
                }
                StringBuilder sbScript = new StringBuilder();
                sbScript.Append("<script type='text/javascript'>alert('很抱歉！您的权限不足，访问被拒绝！');</script>");
                filterContext.Result = new ContentResult() { Content = sbScript.ToString() };
                return;
            }
        }
        private bool ActionAuthorize(ActionExecutingContext filterContext)
        {
            var operatorProvider = OperatorProvider.Provider.GetCurrent();
            var userRoles = operatorProvider.RoleList;
            var userRecordID = operatorProvider.UserId;
            var moduleId = WebHelper.GetCookie("currentModuleID");
            var action = HttpContext.Current.Request.ServerVariables["SCRIPT_NAME"].ToString();
            permissionAppService = AutofacConfig.Container.Resolve<IPermissionAppService>();
            return permissionAppService.ActionValidate(userRecordID, userRoles, moduleId, action);
        }
    }
}