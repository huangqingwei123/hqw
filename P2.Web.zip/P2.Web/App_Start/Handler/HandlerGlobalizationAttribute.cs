﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace P2.Web
{    
    public class HandlerGlobalizationAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var session = System.Web.HttpContext.Current.Session;
            if (session != null && session["Culture"] != null)
            {
                var id = System.Threading.Thread.CurrentThread.ManagedThreadId;
                System.Threading.Thread.CurrentThread.CurrentCulture = (System.Globalization.CultureInfo)session["Culture"];
                System.Threading.Thread.CurrentThread.CurrentUICulture = (System.Globalization.CultureInfo)session["Culture"];
            }        
        }
    }
}
