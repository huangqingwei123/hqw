﻿using System;
using System.IO;
using System.Text;
using System.Linq;
using System.Web.Mvc;
using System.Linq.Expressions;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using P2.Web;
using P2.Infrastructure;
using P2.Infrastructure.Extensions;
using P2.Application.SystemManage;
using P2.Application.DTO.Output;
using P2.Infrastructure.Enums.SystemManage;
using P2.Infrastructure.Enums;
using System.Web;
using P2.Application.IAppService;
using System.Data;

namespace P2.Web
{
    [HandlerLogin]
    [HandlerGlobalizationAttribute]
    public abstract class ControllerBase : Controller
    {
        private IPermissionAppService permissionAppService;
        protected List<ModuleButtonDto> initialButtonList = new List<ModuleButtonDto>();//初始位置的按钮集合
        protected List<ModuleButtonDto> rowButtonList = new List<ModuleButtonDto>();//选中位置的按钮集合   
        protected List<ModuleButtonDto> permissionButtonList = new List<ModuleButtonDto>();//选中位置的按钮集合     

        public ControllerBase(IPermissionAppService _permissionAppService)
        {
            permissionAppService = _permissionAppService;
        }
        public Log FileLog
        {
            get { return LogFactory.GetLogger(this.GetType().ToString()); }
        }

        public string AreaName
        {
            get
            {
                return RouteData.DataTokens["area"].ToString();
            }
        }

        public string ControllerName
        {
            get
            {
                return RouteData.Values["controller"].ToString();
            }
        }

        public string ActionName
        {
            get
            {
                return RouteData.Values["action"].ToString();
            }
        }

        #region 视图页

        [HttpGet]
        [HandlerAuthorize]
        public virtual ActionResult Index()
        {
            GetIniaialButtonList();
            ViewBag.InitialButtonText = BulidInitialButtonText();
            ViewBag.ModuleName = AreaName + "-" + ControllerName + "-" + ActionName;
            return View();
        }
        [HttpGet]
        [HandlerAuthorize]
        public virtual ActionResult Form()
        {
            ViewBag.ModuleName = AreaName + "-" + ControllerName + "-" + ActionName;
            return View();
        }
        [HttpGet]
        [HandlerAuthorize]
        public virtual ActionResult CacelForm()
        {
            return View();
        }
        [HttpGet]
        [HandlerAuthorize]
        public virtual ActionResult Details()
        {
            ViewBag.ModuleName = AreaName + "-" + ControllerName + "-" + ActionName;
            return View();
        }

        #endregion

        #region 返回方法

        protected virtual ActionResult Success(string message)
        {
            return Content(new AjaxResult { state = ResultType.success.ToString(), message = message }.ToJson());
        }
        protected virtual ActionResult Success(string message, object data)
        {
            return Content(new AjaxResult { state = ResultType.success.ToString(), message = message, data = data }.ToJson());
        }
        protected virtual ActionResult Error(string message)
        {
            return Content(new AjaxResult { state = ResultType.error.ToString(), message = message }.ToJson());
        }

        #endregion

        #region 下载完文件后自动删除

        [HttpGet]
        [DeleteExportFileAttribute]//下载完导出文件后自动删除文件
        public virtual ActionResult DownloadFile(string file)
        {
            //到服务器临时文件目录下载相应的文件
            string fullPath = Path.Combine(P2.Infrastructure.ExportAndImport.ExportFileAbsolutePath, file);
            //返回文件对象，这里用的是Excel，所以文件头使用了"application/vnd.ms-excel"
            string fileName = file.Substring(file.LastIndexOf("\\") + 1);
            string suffix = fileName.Substring(fileName.LastIndexOf(".") + 1).ToLower();
            if (suffix == "xls")//03版
            {
                return File(fullPath, "application/vnd.ms-excel", fileName);
            }
            else//07或更高版本
            {
                return File(fullPath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
            }
        }

        [HttpGet]
        [DeleteExportFileAttribute]//下载完导出文件后自动删除文件
        public virtual ActionResult DownloadFilePDF(string file)
        {
            //到服务器临时文件目录下载相应的文件
            string fullPath = Path.Combine(P2.Infrastructure.ExportAndImport.ExportFileAbsolutePath, file);
            //返回文件对象，这里用的是Excel，所以文件头使用了"application/vnd.ms-excel"
            return File(fullPath, "application/pdf", file.Substring(file.LastIndexOf("\\") + 1));
        }

        [HttpGet]
        //[DeleteExportFileAttribute]//下载完导出文件后自动删除文件
        public virtual ActionResult DownloadFileTxt(string file)
        {
            //到服务器临时文件目录下载相应的文件
            string fullPath = Path.Combine(P2.Infrastructure.ExportAndImport.ExportFileAbsolutePath, file);
            //返回文件对象，这里用的是Txt，所以文件头使用了"text/plain"
            return File(fullPath, "text/plain", file.Substring(file.LastIndexOf("\\") + 1));
        }
        #endregion

        #region 根据角色模块构建按钮Html

        /// <summary>
        /// 根据角色以及模块名获取当前模块的按钮列表
        /// </summary>
        /// <returns></returns>
        public virtual void GetRowButtonList()
        {
            var userRecordID = OperatorProvider.Provider.GetCurrent().UserId;
            var userRoles = OperatorProvider.Provider.GetCurrent().RoleList;
            var isSystem = OperatorProvider.Provider.GetCurrent().IsSystem;
            var moduleID = Request["moduleID"].CastTo<string>("", true).Trim();
            if (!String.IsNullOrEmpty(moduleID))
            {
                rowButtonList = permissionAppService.GetModuleButtonList(userRecordID, userRoles, moduleID, 2, isSystem).ToList();
            }
        }

        /// <summary>
        /// 构建数据行的操作按钮
        /// 根据lambda表达式排除禁用的按钮
        /// </summary>
        /// <param name="key">ID</param>
        /// <param name="predicate">谓词</param>
        /// <returns></returns>
        public virtual string BulidButtonText(string key, Expression<Func<ModuleButtonDto, bool>> predicate)
        {
            var buttonText = new StringBuilder();
            var buttonQuerable = rowButtonList.AsQueryable();//只取选中类型的按钮

            if (predicate == null)
                predicate = ExtLinq.True<ModuleButtonDto>();

            var enabledList = buttonQuerable.Where(predicate).ToList();//可以使用的按钮集合

            foreach (var button in rowButtonList)
            {
                if (enabledList.Contains(button))
                {
                    var jsEvent = (!String.IsNullOrEmpty(button.JsEvent) ? button.JsEvent.Replace("(", "('" + key + "'") : button.JsEvent);
                    buttonText.AppendFormat("<a id=\"{0}\" href=\"javascript:void(0);\" onclick=\"{1}\"><i style=\"padding:4px;\" class=\"{3}\">{2}</i></a>"
                        , button.EnCode, jsEvent, GetCultureButtonName(button), button.Icon);
                }
                else
                {
                    buttonText.AppendFormat("<a id=\"{0}\" href=\"javascript:void(0);\" class=\"disabled\"><i style=\"padding:4px;\" class=\"{1}\">{2}</i></a>"
                       , button.EnCode, button.Icon, GetCultureButtonName(button));
                }
            }
            return buttonText.ToString();
        }

        /// <summary>
        /// 构建按钮Html
        /// </summary>        
        /// <param name="disablePredicate">禁用表达式</param>
        /// <param name="hidePredicate">隐藏表达式</param>
        /// <param name="ButtonRenameFunction">按钮重命名委托</param>
        /// <param name="keys">方法操作参数集合</param>
        /// <returns></returns>
        public string BulidButtonText(Expression<Func<ModuleButtonDto, bool>> disablePredicate,
            Expression<Func<ModuleButtonDto, bool>> hidePredicate, Func<string, string> ButtonRenameFunction, params string[] keys)
        {
            if (keys == null || keys.Length <= 0) return "";
            var buttonText = new StringBuilder();
            var buttonQuerable = rowButtonList.AsQueryable();//只取选中类型的按钮

            if (disablePredicate == null)
                disablePredicate = ExtLinq.True<ModuleButtonDto>();
            if (hidePredicate == null)
                hidePredicate = ExtLinq.False<ModuleButtonDto>();

            var enabledList = buttonQuerable.Where(disablePredicate).ToList();//可用的按钮集合
            var hideList = buttonQuerable.Where(hidePredicate).ToList();//需要隐藏的按钮集合

            foreach (var button in rowButtonList)
            {
                if (hideList.Contains(button)) continue;//跳过隐藏项                
                var buttonName = GetCultureButtonName(button);
                if (ButtonRenameFunction != null)
                {
                    buttonName = ButtonRenameFunction(button.FullName);
                }
                if (enabledList.Contains(button))
                {
                    string strKey = "'" + string.Join("','", keys.ToArray()) + "'";
                    var jsEvent = (!String.IsNullOrEmpty(button.JsEvent) ? button.JsEvent.Replace("(", "(" + strKey) : button.JsEvent);
                    buttonText.AppendFormat("<a id=\"{0}\" href=\"javascript:void(0);\" onclick=\"{1}\"><i style=\"padding:4px;\" class=\"{3}\">{2}</i></a>"
                        , button.EnCode, jsEvent, buttonName, button.Icon);
                }
                else
                {
                    buttonText.AppendFormat("<a id=\"{0}\" href=\"javascript:void(0);\" class=\"disabled\"><i style=\"padding:4px;\" class=\"{1}\">{2}</i></a>"
                       , button.EnCode, button.Icon, buttonName);
                }
            }
            return buttonText.ToString();
        }

        #endregion

        #region 根据模块获取初始按钮

        /// <summary>
        /// 获取初始化按钮集合
        /// </summary>
        public virtual void GetIniaialButtonList()
        {
            var userRecordID = OperatorProvider.Provider.GetCurrent().UserId;
            var userRoles = OperatorProvider.Provider.GetCurrent().RoleList;
            var isSystem = OperatorProvider.Provider.GetCurrent().IsSystem;
            var moduleID = Request["moduleID"].CastTo<string>("", true).Trim();
            if (!String.IsNullOrEmpty(moduleID))
            {
                initialButtonList = permissionAppService.GetModuleButtonList(userRecordID, userRoles, moduleID, 1, isSystem).ToList();
            }
        }

        /// <summary>
        /// 构建初始化按钮
        /// </summary>
        /// <returns></returns>
        public virtual string BulidInitialButtonText()
        {
            var buttonText = new StringBuilder();
            var initGroupEnumDic = EnumOperate.enumToDictionary<ModuleButtonEnum.InitGroupEnum>();//所有分组信息
            var groupButtonList = initialButtonList.GroupBy(p => p.InitGroup);//通过字段分组
            var commonButtonList = groupButtonList.Where(p => !initGroupEnumDic.Values.Contains(p.Key)).SelectMany(p => p);//不分组的按钮集合

            //处理不分组的按钮集合
            foreach (var button in commonButtonList)
            {
                buttonText.AppendLine("<div class=\"btn-group\">");
                buttonText.AppendFormat("<a class=\"btn btn-primary dropdown-text\" onclick=\"{0}\"><i class=\"{1}\"></i>{2}</a>", button.JsEvent, button.Icon, GetCultureButtonName(button));
                buttonText.AppendLine("</div>");
            }
            //处理分组的按钮集合
            foreach (var buttonList in groupButtonList)
            {
                if (initGroupEnumDic.Values.Contains(buttonList.Key))//属于需要分组
                {
                    //分组按钮处理
                    if (buttonList.Count() > 0)
                    {
                        buttonText.AppendLine("<a class=\"btn btn-primary\" data-toggle=\"dropdown\" aria-expanded=\"false\" style=\"height: 13px;line-height: 0px;padding: 8px 5px 8px 15px;\">" + buttonList.Key + "<i class=\"fa fa-caret-down\" style=\"padding: 0px 0px 0px 5px;\"></i></a>");
                        buttonText.AppendLine("<ul class=\"dropdown-menu dropdown-menu-right\">");
                        foreach (var groupButton in buttonList)
                        {
                            buttonText.AppendLine("<li>");
                            buttonText.AppendFormat("<a class=\"btn\" style=\"text-align:left !important;\" onclick=\"{0}\"><i class=\"{1}\"></i>{2}</a>"
                                , groupButton.JsEvent, groupButton.Icon, GetCultureButtonName(groupButton));
                            buttonText.AppendLine("</li>");
                        }
                        buttonText.AppendLine("</ul>");
                    }
                }
            }
            return buttonText.ToString();
        }
        #endregion

        #region 获取有效的文件数据,过滤空数据

        /// <summary>
        /// 获取有效的文件数据
        /// 过滤空数据
        /// </summary>
        /// <param name="files">表单提交的文件集合</param>
        /// <param name="allowExtendNames">允许的扩展名，可选</param>
        /// <returns></returns>
        public virtual List<HttpPostedFile> GetValidFileData(HttpFileCollection files, params string[] allowExtendNames)
        {
            List<HttpPostedFile> outFiles = new List<HttpPostedFile>();
            for (var i = 0; i < files.Count; i++)
            {
                if (files[i].ContentLength <= 0)
                {
                    continue;//文件大小为0，跳过
                }
                if (allowExtendNames != null && allowExtendNames.Length > 0)//允许的扩展名
                {
                    var exName = System.IO.Path.GetExtension(files[i].FileName); //得到单个文件扩展名
                    if (!allowExtendNames.ToArray().Contains(exName.ToLower()))//不在允许名单中，跳过
                    {
                        continue;
                    }
                }
                outFiles.Add(files[i]);//验证通过，添加至结果集
            }
            return outFiles;
        }
        #endregion

        #region 下载文件，不删除源文件

        /// <summary>
        /// 文件下载
        /// 不删除记录
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult DownloadFileNew(string fileName)
        {
            try
            {
                string filePath = Server.MapPath("~" + fileName);//路径
                var re = System.IO.File.Exists(filePath);
                return File(new FileStream(filePath, FileMode.Open), "application/vnd.ms-excel", fileName);
            }
            catch (Exception ex)
            {
                return Error(ex.Message);
            }
        }
        /// <summary>
        /// 检测是否存在物理路径
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult FileIsExist(string fileName)
        {
            try
            {
                string filePath = Server.MapPath("~" + fileName);//路径
                if (System.IO.File.Exists(filePath))
                {
                    return Success("校验通过", fileName);
                }
                return Error("文件不存在");
            }
            catch (Exception ex)
            {
                return Error(ex.Message);
            }
        }
        #endregion

        #region 把DataTable转为Json字符串
        /// <summary>
        /// DataTable转为Json字符串（"["123","12"]"）
        /// </summary>
        /// <param name="dataTable">DataTable对象</param>
        /// <returns></returns>
        public string DataTableToJson(DataTable dataTable)
        {
            if (dataTable != null)
            {
                int total = dataTable.Rows.Count;
                if (dataTable.Rows.Count > 0)
                {
                    StringBuilder JsonString = new StringBuilder();
                    JsonString.Append("[");

                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {

                        JsonString.AppendFormat("\"{0}\",", dataTable.Rows[i]["Code"].ToString().Replace("\r\n", "<br>").Replace("\n", "<br>").Replace("\\", "\\\\"));
                        if (i == dataTable.Rows.Count - 1)
                        {
                            JsonString.AppendFormat("\"{0}\"", dataTable.Rows[i]["Code"].ToString().Replace("\r\n", "<br>").Replace("\n", "<br>").Replace("\\", "\\\\"));
                        }
                    }
                    JsonString.Append("]");
                    return JsonString.ToString();
                }
                else
                {
                    return "[]";
                }
            }
            else
            {
                return "[]";
            }
        }
        #endregion

        #region 获取验证权限按钮集合

        public void GetPermissionButtonList()
        {
            var userRecordID = OperatorProvider.Provider.GetCurrent().UserId;
            var userRoles = OperatorProvider.Provider.GetCurrent().RoleList;
            var isSystem = OperatorProvider.Provider.GetCurrent().IsSystem;
            var moduleID = Request["moduleID"].CastTo<string>("", true).Trim();
            if (!String.IsNullOrEmpty(moduleID))
            {
                permissionButtonList = permissionAppService.GetModuleButtonList(userRecordID, userRoles, moduleID, 3, isSystem).ToList();
            }
        }

        #endregion 获取验证权限按钮集合

        #region 辅助操作

        public string GetCultureButtonName(ModuleButtonDto buttonDto)
        {
            string currentCulture = "zh-CN";
            if (Session != null && Session["Culture"] != null)
            {
                currentCulture = Session["Culture"].ToString();
            }
            switch (currentCulture)
            {
                case "en-US":
                    return buttonDto.EnName;
                default:
                    return buttonDto.FullName;
            }
        }
        public string GetCultureModuleName(ModuleDto moduleDto)
        {
            string currentCulture = "zh-CN";
            if (Session != null && Session["Culture"] != null)
            {
                currentCulture = Session["Culture"].ToString();
            }
            switch (currentCulture)
            {
                case "en-US":
                    return moduleDto.EnName;
                default:
                    return moduleDto.FullName;
            }
        }
        #endregion
    }
}
