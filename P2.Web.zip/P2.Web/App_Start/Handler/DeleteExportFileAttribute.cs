﻿using P2.Infrastructure;
using System.Web.Mvc;

namespace P2.Web
{
    public class DeleteExportFileAttribute : ActionFilterAttribute
    {
        public override void OnResultExecuted(ResultExecutedContext filterContext)
        {
            filterContext.HttpContext.Response.Flush();
            //將当前filter context转换成具体操作的文件并获取文件路径
            string filePath = (filterContext.Result as FilePathResult).FileName;
            //有文件路径后就可以直接删除相关文件了
            System.IO.File.Delete(filePath);
        }
    }
}