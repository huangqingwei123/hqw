﻿using P2.Application.IAppService;
using P2.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace P2.Web.Areas.SystemSecurity.Controllers
{
    public class LogController : ControllerBase
    {
        private ILogAppService logAppService;
        private IPermissionAppService permissionAppService;

        public LogController(IPermissionAppService _permissionAppService, ILogAppService _logAppService)
            : base(_permissionAppService)
        {
            logAppService = _logAppService;
        }

        [HttpGet]
        public ActionResult RemoveLog()
        {
            return View();
        }
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson(Pagination pagination, string queryJson)
        {
            var data = new
            {
                rows = logAppService.GetList(pagination, queryJson),
                total = pagination.total,
                page = pagination.page,
                records = pagination.records
            };
            return Content(data.ToJson());
        }
        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult SubmitRemoveLog(string keepTime)
        {
            logAppService.RemoveLog(keepTime);
            return Success("清空成功。");
        }
    }
}
