﻿using System.Web.Mvc;

namespace P2.Web.Areas.SystemSecurity
{
    public class VoucherManageAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "SystemSecurity";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                 this.AreaName + "_Default",
                 this.AreaName + "/{controller}/{action}/{id}",
                 new { area = this.AreaName, controller = "ResHome", action = "Index", id = UrlParameter.Optional },
                 new string[] { "P2.Web.Areas." + this.AreaName + ".Controllers" }
           );
        }
    }
}
