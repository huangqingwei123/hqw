﻿using P2.Application.SystemManage;
using P2.Infrastructure;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web;
using P2.Infrastructure.Extensions;
using System;
using System.Text;
using P2.Application.DTO.Output;
using P2.Application.IAppService;
using P2.Application.DTO.Input;

namespace P2.Web.Areas.SystemManage.Controllers
{
    public class ModuleController : ControllerBase
    {
        private IModuleAppService moduleAppService;        

        public ModuleController(IPermissionAppService _permissionAppService, IModuleAppService _moduleAppService)
            : base(_permissionAppService)
        {
            moduleAppService = _moduleAppService;
        }

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetTreeSelectJson()
        {
            var data = moduleAppService.GetList(false);
            var treeList = new List<TreeSelectModel>();
            foreach (var item in data)
            {
                TreeSelectModel treeModel = new TreeSelectModel();
                treeModel.id = item.Id;
                treeModel.text = item.FullName;
                treeModel.parentId = item.ParentId;
                treeList.Add(treeModel);
            }
            return Content(treeList.TreeSelectJson());
        }

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetTreeGridJson()
        {
            var keyword = Request["keyword"].CastTo<string>("", true).Trim();
            var rowsData = moduleAppService.GetList();

            if (!string.IsNullOrEmpty(keyword))
            {
                rowsData = rowsData.TreeWhere(t => t.FullName.Contains(keyword));
            }
            GetRowButtonList();
            rowsData.ForEach(p =>
            {
                var expression = ExtLinq.True<ModuleButtonDto>();
                p.ButtonText = BulidButtonText(p.Id, expression);
            });
            var treeList = new List<TreeGridModel>();
            foreach (var item in rowsData)
            {
                TreeGridModel treeModel = new TreeGridModel();
                bool hasChildren = rowsData.Count(t => t.ParentId == item.Id) == 0 ? false : true;
                treeModel.id = item.Id;
                treeModel.isLeaf = hasChildren;
                treeModel.parentId = item.ParentId;
                treeModel.expanded = hasChildren;
                treeModel.entityJson = item.ToJson();
                treeList.Add(treeModel);
            }
            return Content(treeList.TreeGridJson());
        }

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetFormJson(string keyValue)
        {
            var data = moduleAppService.GetForm(keyValue);
            return Content(data.ToJson());
        }

        [HttpPost]
        [HandlerAjaxOnly]
        [ValidateAntiForgeryToken]
        public ActionResult SubmitForm(SubmitModuleInput moduleEntity, string keyValue)
        {
            moduleAppService.SubmitForm(moduleEntity, keyValue);
            return Success("操作成功。");
        }

        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteForm(string keyValue)
        {
            moduleAppService.DeleteForm(keyValue);
            return Success("删除成功。");
        }
    }
}
