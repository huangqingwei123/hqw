﻿using P2.Application.SystemManage;
using P2.Infrastructure;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using P2.Application.DTO.Output;
using P2.Infrastructure.Extensions;
using System;
using P2.Application;
using P2.Application.IAppService;
using P2.Application.DTO.Input;

namespace P2.Web.Areas.SystemManage.Controllers
{
    /// <summary>
    /// 组织架构/部门控制器
    /// </summary>
    public class OrganizeController : ControllerBase
    {
        private IOrganizeAppService organizeAppService;
        private IUserAppService userAppService;                

        public OrganizeController(IPermissionAppService _permissionAppService, IOrganizeAppService _organizeAppService, IUserAppService _userAppService)
            : base(_permissionAppService)
        {
            organizeAppService = _organizeAppService;
            userAppService = _userAppService;            
        }

        #region 获取数据

        /// <summary>
        /// 构建部门树形选择框
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetTreeSelectJson()
        {
            var parentId = Request["parentId"].CastTo<string>("", true).Trim();
            var data = organizeAppService.GetList(false, parentId, "");
            var treeList = new List<TreeSelectModel>();
            foreach (var item in data)
            {
                TreeSelectModel treeModel = new TreeSelectModel();
                treeModel.id = item.Id;
                treeModel.text = item.FullName;
                treeModel.parentId = item.ParentId;
                treeModel.data = item;
                treeList.Add(treeModel);
            }
            if (!string.IsNullOrEmpty(parentId))
                return Content(treeList.ToJson());
            return Content(treeList.TreeSelectJson());
        }
        /// <summary>
        /// 构建部门树
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetTreeJson()
        {
            var data = organizeAppService.GetList(true, "");
            var treeList = new List<TreeViewModel>();
            foreach (var item in data)
            {
                var tree = new TreeViewModel();
                bool hasChildren = data.Count(t => t.ParentId == item.Id) == 0 ? false : true;
                tree.id = item.Id;
                tree.text = item.FullName;
                tree.value = item.EnCode;
                tree.parentId = item.ParentId;
                tree.isexpand = (item.ParentId == "0" ? true : false);
                tree.complete = true;
                tree.hasChildren = hasChildren;
                tree.showcheck = true;
                treeList.Add(tree);
            }
            return Content(treeList.TreeViewJson());
        }
        /// <summary>
        /// 构建部门用户树
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetUserTreeJson()
        {
            var keyword = Request["keyword"].CastTo<string>("", true).Trim();
            var data = organizeAppService.GetList(true, "");
            if (data != null && data.Count > 0)
            {
                var userData = userAppService.GetList(new BaseQueryDto()
                {
                    IsGetAll = true,
                    Keyword = keyword,
                });
                var treeList = new List<TreeViewModel>();
                foreach (var item in data)
                {
                    var tree = new TreeViewModel();
                    var ownUserList = userData.Where(p => p.DepartmentId == item.Id);//部门所属用户
                    var childrenCount = data.Count(t => t.ParentId == item.Id);
                    tree.id = item.Id;
                    tree.text = item.FullName;
                    tree.value = item.EnCode;
                    tree.parentId = item.ParentId;
                    tree.isexpand = (item.ParentId == "0" ? true : false);
                    tree.complete = true;
                    tree.hasChildren = (childrenCount > 0 || ownUserList.Count() > 0);
                    treeList.Add(tree);
                }

                data = data.TreeWhere(p => userData.Count(t => t.DepartmentId == p.Id) > 0).ToList();
                treeList = treeList.Where(p => data.Select(t => t.Id).Contains(p.id)).ToList();
                if (!String.IsNullOrEmpty(keyword))
                {
                    treeList.ForEach(p => p.isexpand = true);//属于查询的话把所有相关用户的部门展开
                }
                foreach (var item in data.TreeWhere(p => userData.Count(t => t.DepartmentId == p.Id) > 0))
                {
                    var ownUserList = userData.Where(p => p.DepartmentId == item.Id);//部门所属用户
                    foreach (var user in ownUserList)
                    {
                        var tree = new TreeViewModel()
                        {
                            id = user.Id,
                            text = user.RealName,
                            value = user.Account,
                            parentId = item.Id,
                            complete = true,
                        };
                        treeList.Add(tree);
                    }
                }
                return Content(treeList.TreeViewJson());
            }
            return Content("");
        }
        /// <summary>
        /// 获取部门树形表格
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetTreeGridJson()
        {
            var keyword = Request["keyword"].CastTo<string>("", true).Trim();
            var rowsData = organizeAppService.GetList();

            GetRowButtonList();
            rowsData.ForEach(p =>
            {
                var expression = ExtLinq.True<ModuleButtonDto>();
                p.ButtonText = BulidButtonText(p.Id, expression);
            });
            if (!string.IsNullOrEmpty(keyword))
            {
                rowsData = rowsData.TreeWhere(t => t.FullName.Contains(keyword));
            }
            var treeList = new List<TreeGridModel>();
            foreach (var item in rowsData)
            {
                TreeGridModel treeModel = new TreeGridModel();
                bool hasChildren = rowsData.Count(t => t.ParentId == item.Id) == 0 ? false : true;
                treeModel.id = item.Id;
                treeModel.isLeaf = hasChildren;
                treeModel.parentId = item.ParentId;
                treeModel.expanded = hasChildren;
                treeModel.entityJson = item.ToJson();
                treeList.Add(treeModel);
            }
            return Content(treeList.TreeGridJson());
        }
        #endregion

        #region 获取单个部门信息

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetFormJson(string keyValue)
        {            
            var data = organizeAppService.GetForm(keyValue);            
            return Content(data.ToJson());
        }
        #endregion

        #region 添加，编辑

        [HttpPost]
        [HandlerAjaxOnly]
        public ActionResult SubmitForm(SubmitOrganizeInput organizeEntity)
        {
            try
            {
                organizeAppService.SubmitForm(organizeEntity);
                return Success("操作成功。");
            }
            catch (Exception ex)
            {
                return Error(ex.Message);
            }
        }
        #endregion

        #region 删除

        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteForm(string keyValue)
        {
            var result = organizeAppService.DeleteForm(keyValue);
            if (result.status != ResultCode.success)
            {
                return Error(result.message);
            }
            return Success(result.message);
        }
        #endregion

        #region 视图页

        [HttpGet]
        public virtual ActionResult TreeControl()
        {
            return View();
        }

        [HttpGet]
        public virtual ActionResult UserTreeControl()
        {
            return View();
        }
        #endregion
    }
}
