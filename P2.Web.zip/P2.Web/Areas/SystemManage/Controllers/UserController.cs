﻿using AutoMapper;
using P2.Application.SystemManage;
using P2.Application.DTO.Input;
using P2.Infrastructure;
using P2.Infrastructure.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using P2.Application.DTO.Output;
using P2.Infrastructure.Enums;
using P2.Application;
using P2.Application.IAppService;
using P2.Infrastructure.Excel;


namespace P2.Web.Areas.SystemManage.Controllers
{
    public class UserController : ControllerBase
    {
        private IUserAppService userAppService;
        private IPermissionAppService permissionAppService;
        private IModuleAppService moduleAppService;
        private IModuleButtonAppService moduleButtonAppService;

        public UserController(IPermissionAppService _permissionAppService, IUserAppService _userAppService, IModuleAppService _moduleAppService, IModuleButtonAppService _moduleButtonAppService)
            : base(_permissionAppService)
        {
            userAppService = _userAppService;
            moduleAppService = _moduleAppService;
            permissionAppService = _permissionAppService;
            moduleButtonAppService = _moduleButtonAppService;
        }

        #region 查询用户

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson(Pagination pagination)
        {
            var request = new BaseQueryDto()
            {
                Pagination = pagination,
                Keyword = Request["keyword"].CastTo<string>("", true).Trim(),
                DepartmentId = Request["departmentId"].CastTo<string>("", true).Trim(),
            };
            var rowsData = userAppService.GetList(request);
            GetRowButtonList();
            rowsData.ForEach(p =>
            {
                var expression = ExtLinq.True<ModuleButtonDto>();
                var hideExpression = ExtLinq.False<ModuleButtonDto>();
                if (p.EnabledMark == false)//已禁用
                {
                    hideExpression = hideExpression.Or(t => t.FullName == "禁用");
                }
                else
                {
                    hideExpression = hideExpression.Or(t => t.FullName == "启用");
                }
                p.ButtonText = BulidButtonText(expression, hideExpression, null, p.Id);
            });
            var data = new
            {
                rows = rowsData,
                total = pagination.total,
                page = pagination.page,
                records = pagination.records
            };
            return Content(data.ToJson());
        }

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetFormJson(string keyValue)
        {
            var data = userAppService.GetForm(keyValue);
            return Content(data.ToJson());
        }
        #endregion

        #region 添加，编辑用户信息

        [HttpPost]
        [HandlerAjaxOnly]
        public ActionResult SubmitForm(SubmitUserInput inputDto)
        {
            if (!ModelState.IsValid)
            {
                var errorList = ModelState.Values.Where(p => p.Errors.Count > 0).FirstOrDefault().Errors;
                return Error(errorList[0].ErrorMessage);
            }
            inputDto.OperaterId = OperatorProvider.Provider.GetCurrent().UserId;

            var result = new ApplicationResult<int>();
            var rediretUrl = "";
            if (String.IsNullOrEmpty(inputDto.KeyValue))
            {
                result = userAppService.Insert(inputDto);
            }
            else
            {
                var shouldClearCookie = false;
                result = userAppService.Modify(inputDto, out shouldClearCookie);
                if (shouldClearCookie)
                {
                    Session.Abandon();
                    Session.Clear();
                    OperatorProvider.Provider.RemoveCurrent();
                    result.message += ",请重新登录";
                    rediretUrl = "/Login/Index";
                }
            }
            if (result.status != ResultCode.success)
            {
                return Error(result.message);
            }
            return Success(result.message, rediretUrl);
        }
        #endregion

        #region 删除

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteForm(string keyValue)
        {
            var result = userAppService.DeleteForm(keyValue);
            if (result.status != ResultCode.success)
            {
                return Error(result.message);
            }
            return Success(result.message);
        }
        #endregion

        #region 禁用，启用

        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult Disabled(string keyValue)
        {
            var result = userAppService.EnabledOrDisabled(keyValue, P2.Infrastructure.Enums.Shared.ValidType.禁用);
            if (result.status != ResultCode.success)
            {
                return Error(result.message);
            }
            return Success(result.message);
        }

        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult Enabled(string keyValue)
        {
            var result = userAppService.EnabledOrDisabled(keyValue, P2.Infrastructure.Enums.Shared.ValidType.启用);
            if (result.status != ResultCode.success)
            {
                return Error(result.message);
            }
            return Success(result.message);
        }
        #endregion

        #region 视图页

        [HttpGet]
        public ActionResult Info()
        {
            return View();
        }

        [HttpGet]
        public ActionResult ChangePassword()
        {
            return View();
        }
        [HttpGet]
        public virtual ActionResult WinUser()
        {
            return View();
        }
        #endregion

        #region 修改密码

        /// <summary>
        /// 修改密码
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [HandlerAjaxOnly]
        [ValidateAntiForgeryToken]
        public ActionResult SubmitChanangePwd()
        {
            string oldPassword = Request.Form["oldPassword"].CastTo<string>("", true).Trim();
            string password = Request.Form["password"].CastTo<string>("", true).Trim();

            if (String.IsNullOrEmpty(oldPassword) || String.IsNullOrEmpty(password))
            {
                return Error("缺少必要参数！");
            }
            if (oldPassword.GetStringLength() > 20 || password.GetStringLength() > 20)
            {
                return Error("密码长度不能超过20位！");
            }
            var result = userAppService.ChangePassword(oldPassword, password);
            if (result.status != ResultCode.success)
            {
                return Error(result.message);
            }
            Session.Abandon();
            Session.Clear();
            OperatorProvider.Provider.RemoveCurrent();
            return Success(result.message);
        }

        /// <summary>
        /// 重置密码
        /// </summary>
        /// <param name="keyValue"></param>
        /// <param name="userPassword"></param>
        /// <returns></returns>
        [HttpPost]
        [HandlerAjaxOnly]
        [ValidateAntiForgeryToken]
        public ActionResult PostRevisePassword(string keyValue, string userPassword)
        {
            if (String.IsNullOrEmpty(userPassword))
            {
                return Error("缺少必要参数！");
            }
            if (userPassword.GetStringLength() > 20)
            {
                return Error("密码长度不能超过20位！");
            }
            userAppService.RevisePassword(keyValue, userPassword);
            return Success("重置密码成功!");
        }
        #endregion

        #region 检测用户编号

        /// <summary>
        /// 检测商品Code
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult CheckUserCode()
        {
            var userCode = Request["userCode"].ToString();
            if (userCode == null || userCode.Trim() == "")
            {
                return Error("用户编号不能为空!");
            }
            var result = userAppService.CheckSameCode(userCode);
            if (result.status == ResultCode.success)
            {
                return Success(result.message);
            }
            return Error(result.message);
        }
        #endregion

        #region 人员部门移动

        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        public ActionResult PostMoveDepartment(List<string> keyValueList, string targetDepartmentId)
        {
            var result = userAppService.MoveDepartment(keyValueList, targetDepartmentId);
            if (result.status != ResultCode.success)
            {
                return Error(result.message);
            }
            return Success(result.message);
        }
        #endregion

        #region 权限相关

        /// <summary>
        /// 获取用户权限树
        /// </summary>
        /// <param name="keyValue"></param>
        /// <returns></returns>
        public ActionResult GetPermissionTree(string keyValue)
        {
            var moduledata = moduleAppService.GetList(false);
            var buttondata = moduleButtonAppService.GetList("", "", false);
            var authorizedata = new List<PermissionDto>();
            if (!string.IsNullOrEmpty(keyValue))
            {
                authorizedata = permissionAppService.GetList(keyValue);
            }
            var treeList = new List<TreeViewModel>();
            foreach (var item in moduledata)
            {
                TreeViewModel tree = new TreeViewModel();
                bool hasChildren = moduledata.Count(t => t.ParentId == item.Id) == 0 ? false : true;
                tree.id = item.Id;
                tree.text = item.FullName;
                tree.value = item.EnCode;
                tree.parentId = item.ParentId;
                tree.isexpand = false;
                tree.complete = true;
                tree.showcheck = true;
                tree.checkstate = authorizedata.Count(t => t.ItemId == item.Id);
                tree.hasChildren = true;
                tree.img = item.Icon == "" ? "" : item.Icon;
                treeList.Add(tree);
            }
            foreach (var item in buttondata)
            {
                TreeViewModel tree = new TreeViewModel();
                bool hasChildren = buttondata.Count(t => t.ParentId == item.Id) == 0 ? false : true;
                tree.id = item.Id;
                tree.text = item.FullName;
                tree.value = item.EnCode;
                tree.parentId = item.ParentId == "0" ? item.ModuleId : item.ParentId;
                tree.isexpand = false;
                tree.complete = true;
                tree.showcheck = true;
                tree.checkstate = authorizedata.Count(t => t.ItemId == item.Id);
                tree.hasChildren = hasChildren;
                tree.img = item.Icon == "" ? "" : item.Icon;
                treeList.Add(tree);
            }
            return Content(treeList.TreeViewJson());
        }
        #endregion

        #region 导出

        /// <summary>
        /// 导出用户列表
        /// </summary>
        /// <returns></returns>
        public ActionResult PostExportData()
        {
            try
            {
                var inputDto = new BaseQueryDto()
                {
                    Keyword = Request["keyword"].CastTo<string>("", true).Trim(),
                    DepartmentId = Request["departmentId"].CastTo<string>("", true).Trim(),
                    IsGetAll = true,
                };
                var result = userAppService.GetList(inputDto);
                if (result == null || result.Count <= 0)
                {
                    return Error("数据为空！");
                }
                var exportData = AutoMapper.Mapper.Map<List<UserDto>, List<UserExportDto>>(result);
                var fileName = "纽尔组织架构人员信息_" + DateTime.Now.ToString("yyyyMMdd_HHmmssfff") + ".xls";
                FileHelper.CreateDirectory(ExportAndImport.ExportFileAbsolutePath);
                var excelInstance = new NPOIExcel("组织架构人员信息", "组织架构人员信息", FileHelper.MapPath(ExportAndImport.ExportFileRelativePath + fileName));
                excelInstance.ToExcel(exportData, false, true);//导出到Excel
                return Success("导出成功！", fileName);
            }
            catch (Exception ex)
            {
                return Error(ex.Message);
            }
        }
        #endregion
    }
}
