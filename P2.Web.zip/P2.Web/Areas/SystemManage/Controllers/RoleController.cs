﻿using P2.Application.SystemManage;
using P2.Infrastructure;
using P2.Infrastructure.Extensions;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using P2.Application.DTO.Output;
using AutoMapper;
using System;
using P2.Application.DTO.Input;
using P2.Application.IAppService;

namespace P2.Web.Areas.SystemManage.Controllers
{
    public class RoleController : ControllerBase
    {
        private IRoleAppService roleAppService;
        private IPermissionAppService permissionAppService;
        private IModuleAppService moduleAppService;
        private IModuleButtonAppService moduleButtonAppService;

        public RoleController(IPermissionAppService _permissionAppService, IRoleAppService _roleAppService, IModuleAppService _moduleAppService, IModuleButtonAppService _moduleButtonAppService)
            : base(_permissionAppService)
        {
            roleAppService = _roleAppService;
            moduleAppService = _moduleAppService;
            permissionAppService = _permissionAppService;
            moduleButtonAppService = _moduleButtonAppService;
        }

        #region 查询列表

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson()
        {
            var keyword = Request["keyword"].CastTo<string>("", true).Trim();
            var showDisable = Request.QueryString["showDisable"].CastTo<bool>(true);
            var rowsData = roleAppService.GetList(keyword, showDisable);

            GetRowButtonList();
            rowsData.ForEach(p =>
            {
                var expression = ExtLinq.True<ModuleButtonDto>();
                p.ButtonText = BulidButtonText(p.Id, expression);
            });
            var data = new
            {
                rows = rowsData,
            };
            return Content(data.ToJson());
        }

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetAllListJson()
        {
            var data = roleAppService.GetList();
            return Content(data.ToJson());
        }

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetFormJson(string keyValue)
        {
            var data = roleAppService.GetForm(keyValue);
            return Content(data.ToJson());
        }
        #endregion

        #region 添加，编辑用户信息

        [HttpPost]
        [HandlerAjaxOnly]
        public ActionResult SubmitForm(SubmitRoleInput inputDto)
        {
            if (!ModelState.IsValid)
            {
                var errorList = ModelState.Values.Where(p => p.Errors.Count > 0).FirstOrDefault().Errors;
                return Error(errorList[0].ErrorMessage);
            }            
            var result = new ApplicationResult<int>();
            if (String.IsNullOrEmpty(inputDto.KeyValue))
            {
                result = roleAppService.Insert(inputDto);
            }
            else
            {
                result = roleAppService.Modify(inputDto);
            }
            if (result.status != ResultCode.success)
            {
                return Error(result.message);
            }
            return Success(result.message);
        }
        #endregion

        #region 删除

        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteForm(string keyValue)
        {
            var result = roleAppService.DeleteForm(keyValue);
            if (result.status != ResultCode.success)
            {
                return Error(result.message);
            }
            return Success(result.message);
        }
        #endregion

        #region 权限相关

        /// <summary>
        /// 获取角色权限树
        /// </summary>
        /// <param name="roleId"></param>
        /// <returns></returns>
        public ActionResult GetPermissionTree(string roleId)
        {
            var moduledata = moduleAppService.GetList(false);
            var buttondata = moduleButtonAppService.GetList("", "", false);
            var authorizedata = new List<PermissionDto>();
            if (!string.IsNullOrEmpty(roleId))
            {
                authorizedata = permissionAppService.GetList(roleId);
            }
            var treeList = new List<TreeViewModel>();
            foreach (var item in moduledata)
            {
                TreeViewModel tree = new TreeViewModel();
                bool hasChildren = moduledata.Count(t => t.ParentId == item.Id) == 0 ? false : true;
                tree.id = item.Id;
                tree.text = item.FullName;
                tree.value = item.EnCode;
                tree.parentId = item.ParentId;
                tree.isexpand = false;
                tree.complete = true;
                tree.showcheck = true;
                tree.checkstate = authorizedata.Count(t => t.ItemId == item.Id);
                tree.hasChildren = true;
                tree.img = item.Icon == "" ? "" : item.Icon;
                treeList.Add(tree);
            }
            foreach (var item in buttondata)
            {
                TreeViewModel tree = new TreeViewModel();
                bool hasChildren = buttondata.Count(t => t.ParentId == item.Id) == 0 ? false : true;
                tree.id = item.Id;
                tree.text = item.FullName;
                tree.value = item.EnCode;
                tree.parentId = item.ParentId == "0" ? item.ModuleId : item.ParentId;
                tree.isexpand = false;
                tree.complete = true;
                tree.showcheck = true;
                tree.checkstate = authorizedata.Count(t => t.ItemId == item.Id);
                tree.hasChildren = hasChildren;
                tree.img = item.Icon == "" ? "" : item.Icon;
                treeList.Add(tree);
            }
            return Content(treeList.TreeViewJson());
        }
        #endregion
    }
}
