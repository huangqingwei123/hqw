﻿using P2.Application.SystemManage;
using P2.Infrastructure;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using P2.Application.DTO.Output;
using P2.Infrastructure.Extensions;
using P2.Application.IAppService;
using P2.Application.DTO.Input;

namespace P2.Web.Areas.SystemManage.Controllers
{
    public class DutyController : ControllerBase
    {
        private IDutyAppService dutyAppService;

        public DutyController(IPermissionAppService _permissionAppService, IDutyAppService _dutyAppService)
            : base(_permissionAppService)
        {
            dutyAppService = _dutyAppService;
        }

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson()
        {
            string keyword = Request["keyword"].CastTo<string>("", true).Trim();
            var rowsData = dutyAppService.GetList(keyword);
            GetRowButtonList();
            rowsData.ForEach(p =>
            {
                var expression = ExtLinq.True<ModuleButtonDto>();
                p.ButtonText = BulidButtonText(p.Id, expression);
            });
            return Content(rowsData.ToJson());
        }
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetFormJson(string keyValue)
        {
            var data = dutyAppService.GetForm(keyValue);
            return Content(data.ToJson());
        }
        [HttpPost]
        [HandlerAjaxOnly]
        [ValidateAntiForgeryToken]
        public ActionResult SubmitForm(SubmitRoleInput roleEntity, string keyValue)
        {
            dutyAppService.SubmitForm(roleEntity, keyValue);
            return Success("操作成功。");
        }
        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteForm(string keyValue)
        {
            dutyAppService.DeleteForm(keyValue);
            return Success("删除成功。");
        }
    }
}
