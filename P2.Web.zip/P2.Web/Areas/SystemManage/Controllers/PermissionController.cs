﻿using P2.Application.SystemManage;
using P2.Infrastructure;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using P2.Application.IAppService;
using P2.Application.DTO.Output;

namespace P2.Web.Areas.SystemManage.Controllers
{
    public class PermissionController : ControllerBase
    {
        private IPermissionAppService permissionAppService;
        private IModuleAppService moduleAppService;
        private IModuleButtonAppService moduleButtonAppService;

        public PermissionController(IPermissionAppService _permissionAppService, IModuleAppService _moduleAppService, IModuleButtonAppService _moduleButtonAppService)
            : base(_permissionAppService)
        {
            moduleAppService = _moduleAppService;
            moduleButtonAppService = _moduleButtonAppService;
        }

        public ActionResult GetPermissionTree(string roleId)
        {
            var moduledata = moduleAppService.GetList(false);
            var buttondata = moduleButtonAppService.GetList("", "", false);
            var authorizedata = new List<PermissionDto>();
            if (!string.IsNullOrEmpty(roleId))
            {
                authorizedata = permissionAppService.GetList(roleId);
            }
            var treeList = new List<TreeViewModel>();
            foreach (var item in moduledata)
            {
                TreeViewModel tree = new TreeViewModel();
                bool hasChildren = moduledata.Count(t => t.ParentId == item.Id) == 0 ? false : true;
                tree.id = item.Id;
                tree.text = item.FullName;
                tree.value = item.EnCode;
                tree.parentId = item.ParentId;
                tree.isexpand = false;
                tree.complete = true;
                tree.showcheck = true;
                tree.checkstate = authorizedata.Count(t => t.ItemId == item.Id);
                tree.hasChildren = true;
                tree.img = item.Icon == "" ? "" : item.Icon;
                treeList.Add(tree);
            }
            foreach (var item in buttondata)
            {
                TreeViewModel tree = new TreeViewModel();
                bool hasChildren = buttondata.Count(t => t.ParentId == item.Id) == 0 ? false : true;
                tree.id = item.Id;
                tree.text = item.FullName;
                tree.value = item.EnCode;
                tree.parentId = item.ParentId == "0" ? item.ModuleId : item.ParentId;
                tree.isexpand = false;
                tree.complete = true;
                tree.showcheck = true;
                tree.checkstate = authorizedata.Count(t => t.ItemId == item.Id);
                tree.hasChildren = hasChildren;
                tree.img = item.Icon == "" ? "" : item.Icon;
                treeList.Add(tree);
            }
            return Content(treeList.TreeViewJson());
        }
    }
}
