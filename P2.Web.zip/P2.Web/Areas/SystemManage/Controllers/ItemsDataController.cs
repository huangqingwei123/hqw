﻿using P2.Application.SystemManage;
using P2.Web;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using P2.Infrastructure;
using P2.Application.DTO.Output;
using P2.Infrastructure.Extensions;
using P2.Application.IAppService;
using P2.Application.DTO.Input;

namespace P2.Web.Areas.SystemManage.Controllers
{
    public class ItemsDataController : ControllerBase
    {
        private IItemsDetailAppService itemsDetailApp;               

        public ItemsDataController(IPermissionAppService _permissionAppService, IItemsDetailAppService _itemsDetailApp)
            : base(_permissionAppService)
        {
            itemsDetailApp = _itemsDetailApp;
        }

        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetGridJson()
        {
            var itemId = Request["itemId"].CastTo<string>("", true).Trim();
            var keyword = Request["keyword"].CastTo<string>("", true).Trim();
            var rowsData = itemsDetailApp.GetList(itemId, keyword);
            GetRowButtonList();
            rowsData.ForEach(p =>
            {
                var expression = ExtLinq.True<ModuleButtonDto>();
                p.ButtonText = BulidButtonText(p.Id, expression);
            });
            return Content(rowsData.ToJson());
        }
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetSelectJson()
        {
            string enCode = Request["enCode"].CastTo<string>("", true).Trim();
            var data = itemsDetailApp.GetItemList(enCode);
            List<object> list = new List<object>();
            foreach (var item in data)
            {
                list.Add(new { id = item.ItemCode, text = item.ItemName });
            }
            return Content(list.ToJson());
        }
        [HttpGet]
        [HandlerAjaxOnly]
        public ActionResult GetFormJson(string keyValue)
        {
            var data = itemsDetailApp.GetForm(keyValue);
            return Content(data.ToJson());
        }
        [HttpPost]
        [HandlerAjaxOnly]
        [ValidateAntiForgeryToken]
        public ActionResult SubmitForm(SubmitItemsDetailInput itemsDetailEntity, string keyValue)
        {
            var result = itemsDetailApp.SubmitForm(itemsDetailEntity, keyValue);
            if (result.status != ResultCode.success)
            {
                return Error(result.message);
            }
            return Success(result.message);
        }

        [HttpPost]
        [HandlerAjaxOnly]
        [HandlerAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteForm(string keyValue)
        {
            var result = itemsDetailApp.DeleteForm(keyValue);
            if (result.status != ResultCode.success)
            {
                return Error(result.message);
            }
            return Success(result.message);
        }

        //[HttpGet]
        //[HandlerAjaxOnly]
        //public ActionResult GetStoreListJson()
        //{
        //    var id = Request["id"].CastTo<int>(-1);
        //    var storeType = Request["storeType"].CastTo<int>();
        //    var storeNature = Request["storeNature"].CastTo<int>();
        //    var data = app.GetList(id, storeNature, storeType);
        //    return Content(data.ToJson());
        //}
    }
}
