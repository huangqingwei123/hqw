﻿using Microsoft.Owin;
using Owin;
using P2.Application;
using System.Web.Http;

[assembly: OwinStartup(typeof(P2.Api.Startup))]

namespace P2.Api
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            HttpConfiguration config = new HttpConfiguration();
            config.MapHttpAttributeRoutes();
            WebApiConfig.Register(config);
            AutoMapperConfig.Initialize();
            AutofacConfig.Register(config);
            app.UseWebApi(config);
        }
    }
}
