﻿using Autofac;
using P2.Application.IAppService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Http;

namespace P2.Api.Controllers
{
    [RoutePrefix("api/HelloWorld")]
    public class HelloWorldController : ApiController
    {

        [Route("")]
        public IHttpActionResult Get()
        {
            return Ok<string>("Hello World");
        }
    }
}