﻿using P2.Application.IAppService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace P2.Api.Controllers
{

    public class TestController : ApiController
    {
        private IUserAppService _userAppService;

        public TestController(IUserAppService userAppService)
        {
            _userAppService = userAppService;
        }

        // GET: api/Test
        public Application.DTO.Output.UserDto Get()
        {
            return _userAppService.GetForm("4be0ae03e2354dabb5f5247687462b88");
        }

        // GET: api/Test/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Test
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/Test/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Test/5
        public void Delete(int id)
        {
        }
    }
}
