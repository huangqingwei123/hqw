﻿using Autofac;
using Autofac.Integration.WebApi;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Http;

namespace P2.Api
{
    public class AutofacConfig
    {
        public static IContainer Container;
        public static void Register(HttpConfiguration config)
        {
            var builder = new ContainerBuilder();
            
            SetupResolveRules(builder);

            //注册所有的ApiControllers
            builder.RegisterApiControllers(Assembly.GetCallingAssembly());

            var container = builder.Build();
            Container = container;

            //api的控制器对象由autofac来创建
            config.DependencyResolver = new AutofacWebApiDependencyResolver(container);
        }

        public static void SetupResolveRules(ContainerBuilder builder)
        {
            builder.RegisterAssemblyTypes(Assembly.Load("P2.Domain.Repositories"))
                .Where(t => t.Name.EndsWith("Repository"))
                .AsImplementedInterfaces()
                .InstancePerLifetimeScope();

            builder.RegisterAssemblyTypes(Assembly.Load("P2.Application"))
                .Where(t => t.Name.EndsWith("AppService"))
                .AsImplementedInterfaces()
                .InstancePerLifetimeScope();

            builder.RegisterType(Assembly.Load("P2.Domain.Repositories").GetType("P2.Domain.Repositories.EntityFramework.EntityFrameworkRepositoryContext"))
                .As(Assembly.Load("P2.Domain").GetType("P2.Domain.IRepositories.IRepositoryContext")).InstancePerLifetimeScope();
        }
    }
}